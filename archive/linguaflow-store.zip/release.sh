#!/bin/bash
# LinguaFlow release script
# Usage: ./release.sh
#
# What it does:
#   1. Reads current version from manifest.json
#   2. Packs the CRX
#   3. Updates updates.xml with the new version
#   4. Copies CRX + XML to the GitHub Pages repo
#   5. Commits and pushes to GitHub Pages

set -e

EXTENSION_DIR="$(cd "$(dirname "$0")" && pwd)"
PAGES_REPO="$EXTENSION_DIR/../linguaflow-update"
PEM_FILE="$(cd "$EXTENSION_DIR/.." && pwd)/linguaflow.pem"
CRX_FILE="$(cd "$EXTENSION_DIR/.." && pwd)/linguaflow.crx"

VERSION=$(grep '"version"' "$EXTENSION_DIR/manifest.json" | head -1 | sed 's/.*: *"\([^"]*\)".*/\1/')
echo "==> Version: $VERSION"

# Pack CRX — remove old file first so a silent failure is caught
rm -f "$CRX_FILE"
echo "==> Packing CRX..."
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --pack-extension="$EXTENSION_DIR" \
  --pack-extension-key="$PEM_FILE" || true
sleep 1
if [ ! -f "$CRX_FILE" ]; then
  echo "    ERROR: CRX not found at $CRX_FILE — Chrome pack failed"
  exit 1
fi
echo "    CRX ready: $CRX_FILE"

# Update XML
echo "==> Updating updates.xml..."
cat > "$EXTENSION_DIR/updates.xml" <<EOF
<?xml version='1.0' encoding='UTF-8'?>
<gupdate xmlns='http://www.google.com/update2/response' protocol='2.0'>
  <app appid='oacaigphokdkkcihnjcmfbhccimjnank'>
    <updatecheck codebase='https://LemonTree-Love.github.io/linguaflow-update/linguaflow.crx' version='$VERSION' />
  </app>
</gupdate>
EOF

# Copy to GitHub Pages repo
if [ ! -d "$PAGES_REPO" ]; then
  echo "==> Pages repo not found, creating: $PAGES_REPO"
  mkdir -p "$PAGES_REPO"
  cd "$PAGES_REPO"
  git init
  git checkout -b main
  echo "# LinguaFlow Update" > README.md
  git add README.md
  git commit -m "init"
  git remote add origin "https://github.com/LemonTree-Love/linguaflow-update.git"
  cd "$EXTENSION_DIR"
fi

cp "$CRX_FILE" "$PAGES_REPO/linguaflow.crx"
cp "$EXTENSION_DIR/updates.xml" "$PAGES_REPO/updates.xml"

# Archive versioned CRX backup
mkdir -p "$PAGES_REPO/archive"
cp "$CRX_FILE" "$PAGES_REPO/archive/linguaflow-v${VERSION}.crx"

cd "$PAGES_REPO"
git add linguaflow.crx updates.xml archive/
git commit -m "release v$VERSION"
git push -u origin main

echo ""
echo "==> Done! v$VERSION published."
echo "    XML:  https://LemonTree-Love.github.io/linguaflow-update/updates.xml"
echo "    CRX:  https://LemonTree-Love.github.io/linguaflow-update/linguaflow.crx"
