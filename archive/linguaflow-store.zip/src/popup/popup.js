import { getVocabulary, getSettings, saveSettings, activeSourceLangs } from '../lib/storage.js';
import { isDue } from '../lib/fsrs.js';
import { cardsToCSV } from '../lib/anki-export.js';
import { getSyncFolderInfo, syncNow, reauthorize } from '../lib/sync.js';

const $ = (id) => document.getElementById(id);
const DAY_MS = 24 * 60 * 60 * 1000;

function setText(id, text) {
  const el = $(id);
  if (el) el.textContent = text;
}

function setActionLabel(id, text) {
  const el = $(id);
  const label = el?.querySelector('.action-label');
  if (label) label.textContent = text;
  else if (el) el.textContent = text;
}

async function applyPopupGlass() {
  const settings = await getSettings();
  const g = settings.glass || {};
  const s = document.documentElement.style;
  s.setProperty('--popup-a', (g.popupOpacity ?? 24) / 100);
  s.setProperty('--popup-blur', (g.popupBlur ?? 46) + 'px');
  s.setProperty('--popup-nav-a', (g.popupNavOpacity ?? 4) / 100);
}

async function renderGlassBackdrop() {
  const backdrop = $('glassBackdrop');
  const windowBackdrop = $('windowBackdrop');
  if (!backdrop && !windowBackdrop) return;

  const { popupBg } = await chrome.storage.local.get('popupBg');
  let imageUrl = popupBg || null;

  if (!imageUrl && chrome.tabs?.captureVisibleTab) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      imageUrl = await chrome.tabs.captureVisibleTab(tab?.windowId, {
        format: 'jpeg',
        quality: 35
      });
    } catch {}
  }

  if (!imageUrl) return;
  if (windowBackdrop) {
    windowBackdrop.style.backgroundImage = `linear-gradient(rgba(6, 9, 8, .28), rgba(6, 9, 8, .42)), url("${imageUrl}")`;
  }
  if (backdrop) {
    backdrop.style.backgroundImage = `linear-gradient(rgba(6, 9, 8, .30), rgba(6, 9, 8, .44)), url("${imageUrl}")`;
  }
}

function formatNextReview(cards, dueCount, now) {
  if (!cards.length) return 'No cards yet';
  if (dueCount > 0) return 'Ready now';
  const next = cards
    .filter(c => (c.level || 1) < 5 && c.due)
    .sort((a, b) => (a.due || 0) - (b.due || 0))[0];
  if (!next) return 'All clear';
  const diff = Math.max(0, (next.due || now) - now);
  if (diff < 60 * 60 * 1000) return `${Math.max(1, Math.ceil(diff / 60000))}m`;
  if (diff < DAY_MS) return `${Math.ceil(diff / (60 * 60 * 1000))}h`;
  return `${Math.ceil(diff / DAY_MS)} days`;
}

function renderListMessage(text) {
  const list = $('recent-list');
  list.innerHTML = '';
  const li = document.createElement('li');
  li.className = 'empty';
  li.textContent = text;
  list.append(li);
}

function calcStreak(cards) {
  const dates = new Set();
  for (const c of cards) {
    if (c.createdAt) {
      const d = new Date(c.createdAt);
      dates.add(`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`);
    }
    if (c.lastReview) {
      const d = new Date(c.lastReview);
      dates.add(`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`);
    }
  }
  const day = new Date();
  const key = (d) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  let streak = 0;
  if (dates.has(key(day))) {
    streak = 1;
  } else {
    day.setDate(day.getDate() - 1);
    if (!dates.has(key(day))) return 0;
    streak = 1;
  }
  day.setDate(day.getDate() - 1);
  while (dates.has(key(day))) {
    streak++;
    day.setDate(day.getDate() - 1);
  }
  return streak;
}

async function refresh() {
  const [vocab, settings] = await Promise.all([getVocabulary(), getSettings()]);
  const langs = new Set(activeSourceLangs(settings));
  const all = Object.values(vocab).filter(c => langs.has(c.lang));
  const now = Date.now();
  const dueCount = all.filter(c => (c.level || 1) < 5 && isDue(c, now)).length;
  $('s-due').textContent = dueCount;
  $('s-total').textContent = all.length;
  const todayStart = new Date(now);
  todayStart.setHours(0, 0, 0, 0);
  const todayCount = all.filter(c => (c.createdAt || 0) >= todayStart.getTime()).length;
  setText('savedToday', todayCount);
  setText('savedTodayText', `${todayCount} ${todayCount === 1 ? 'word' : 'words'}`);
  setText('readyFlag', settings.enabled !== false ? 'ON' : 'OFF');
  setText('nextReviewText', formatNextReview(all, dueCount, now));

  const streak = calcStreak(all);
  const streakEl = $('streakCount');
  streakEl.textContent = streak > 0 ? `${streak}` : '0';
  if (streak > 0) streakEl.dataset.fire = '';
  else delete streakEl.dataset.fire;

  const goal = settings.dailyGoal || 10;
  const pct = Math.min(100, Math.round(todayCount / goal * 100));
  $('goalFill').style.width = pct + '%';
  $('goalText').textContent = todayCount >= goal ? `${todayCount} — done!` : `${todayCount} / ${goal}`;
  $('goalBar').classList.toggle('complete', todayCount >= goal);
  for (const lvl of [1, 2, 3, 4, 5]) {
    $('s-lvl' + lvl).textContent = all.filter(c => (c.level || 1) === lvl).length;
  }

  const recent = [...all].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 8);
  const list = $('recent-list');
  list.innerHTML = '';
  if (recent.length === 0) {
    renderListMessage('No words saved yet. Select any text on a webpage to begin.');
  } else {
    for (const c of recent) {
      const li = document.createElement('li');
      const w = document.createElement('span'); w.className = 'word'; w.textContent = c.word;
      const t = document.createElement('span'); t.className = 'trans'; t.textContent = c.translation || '';
      li.append(w, t);
      list.append(li);
    }
  }

  $('startReview').disabled = dueCount === 0;
}

$('startReview').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'openReview' });
  window.close();
});

$('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());
$('openOptions2').addEventListener('click', () => chrome.runtime.openOptionsPage());

$('openWordlist').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('src/wordlist/wordlist.html') });
  window.close();
});

$('openStats').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('src/stats/stats.html') });
  window.close();
});

$('clozeBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'toggleCloze' });
    const label = $('clozeBtn').querySelector('.action-label');
    const icon = $('clozeBtn').querySelector('.dock-icon');
    if (label) label.textContent = res?.on ? 'Exit' : 'Cloze';
    if (icon) icon.textContent = res?.on ? '×' : '✎';
  } catch { /* tab can't receive — no-op */ }
});

// Clicking any level stat opens the wordlist filtered to that level.
for (const btn of document.querySelectorAll('.stat-lvl')) {
  btn.addEventListener('click', () => {
    const lvl = btn.dataset.lvl;
    chrome.tabs.create({ url: chrome.runtime.getURL(`src/wordlist/wordlist.html#level=${lvl}`) });
    window.close();
  });
}

async function renderPower() {
  const s = await getSettings();
  const btn = $('enableBtn');
  const on = s.enabled !== false;
  btn.classList.toggle('on', on);
  btn.classList.toggle('off', !on);
  btn.title = on ? 'LinguaFlow is ON — click to disable' : 'LinguaFlow is OFF — click to enable';
  setText('readyFlag', on ? 'ON' : 'OFF');
}
$('enableBtn').addEventListener('click', async () => {
  const s = await getSettings();
  const next = !(s.enabled !== false);  // toggle
  await saveSettings({ enabled: next });
  await renderPower();
});
renderPower();

async function renderTtsBtn() {
  const s = await getSettings();
  const btn = $('ttsBtn');
  const on = !!s.tts?.enabled;
  btn.classList.toggle('on', on);
  btn.classList.toggle('off', !on);
  btn.textContent = on ? '🔊' : '🔇';
  btn.title = on ? 'Auto-pronounce ON — click to mute' : 'Auto-pronounce OFF — click to unmute';
}
$('ttsBtn').addEventListener('click', async () => {
  const s = await getSettings();
  const next = !s.tts?.enabled;
  s.tts = { ...(s.tts || {}), enabled: next };
  await saveSettings({ tts: s.tts });
  await renderTtsBtn();
});
renderTtsBtn();

async function renderSyncChip() {
  const chip = $('syncBtn');
  const settings = await getSettings();
  const backend = settings.syncBackend || 'off';
  if (backend === 'off') { chip.hidden = true; return; }
  chip.hidden = false;
  const { lastSyncAt } = await chrome.storage.local.get('lastSyncAt');

  if (backend === 'icloud') {
    const info = await getSyncFolderInfo();
    if (!info) { chip.hidden = true; return; }
    if (info.permission !== 'granted') {
      chip.className = 'icon-action sync-chip err';
      chip.textContent = '⚠ Reconnect';
      chip.title = 'Click to reauthorize iCloud folder access';
      return;
    }
  }
  chip.className = 'icon-action sync-chip ok';
  chip.textContent = lastSyncAt ? `✓ ${agoShort(lastSyncAt)}` : 'Sync';
  chip.title = lastSyncAt
    ? `Last synced ${new Date(lastSyncAt).toLocaleString()} (${backend})`
    : `Click to sync (${backend})`;
}

function agoShort(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return s + 's';
  if (s < 3600) return Math.floor(s / 60) + 'm';
  if (s < 86400) return Math.floor(s / 3600) + 'h';
  return Math.floor(s / 86400) + 'd';
}

async function doSync(silent = false) {
  const chip = $('syncBtn');
  chip.className = 'icon-action sync-chip busy';
  chip.textContent = 'Syncing';
  let res = await syncNow();
  if (!res.ok && res.error === 'permission') {
    const state = await reauthorize();
    if (state === 'granted') res = await syncNow();
  }
  if (!silent && res.ok) refresh();
  await renderSyncChip();
}

$('syncBtn').addEventListener('click', () => doSync(false));

// Auto-sync on popup open if a backend is configured.
(async () => {
  const settings = await getSettings();
  const backend = settings.syncBackend || 'off';
  if (backend === 'off' || !settings.autoSync) {
    renderSyncChip();
    return;
  }
  if (backend === 'icloud') {
    const info = await getSyncFolderInfo();
    if (info && info.permission === 'granted') return doSync(true);
    renderSyncChip();
    return;
  }
  // webdav — just try
  doSync(true);
})();

// ---- Analyze this page ----
let analyzeMode = false;
$('analyzeBtn').addEventListener('click', async () => {
  if (analyzeMode) {
    analyzeMode = false;
    document.body.classList.remove('analysis-mode');
    $('recent-title').textContent = 'Recent words';
    setActionLabel('analyzeBtn', 'Analyze');
    refresh();
    return;
  }
  analyzeMode = true;
  document.body.classList.add('analysis-mode');
  $('recent-title').textContent = 'Top unknown words on this page';
  setActionLabel('analyzeBtn', 'Back');
  const list = $('recent-list');
  renderListMessage('Analyzing...');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'analyzePageFrequency' });
    renderFreq(res?.words || [], tab.id);
  } catch (e) {
    renderListMessage(`Cannot analyze this page (${e.message})`);
  }
});

function renderFreq(words, tabId) {
  const list = $('recent-list');
  list.innerHTML = '';
  if (!words.length) {
    renderListMessage('Nothing to learn on this page - all words are already known or saved.');
    return;
  }
  for (const w of words) {
    const li = document.createElement('li');
    li.className = 'freq';
    const wordEl = document.createElement('span'); wordEl.className = 'word'; wordEl.textContent = w.word;
    const cnt = document.createElement('span'); cnt.className = 'count'; cnt.textContent = '×' + w.count;
    const save = document.createElement('button'); save.className = 'save'; save.textContent = '+ Save';
    if (w.level > 0) { save.classList.add('saved'); save.textContent = `L${w.level}`; }
    save.onclick = async () => {
      if (save.classList.contains('saved')) return;
      save.disabled = true; save.textContent = '…';
      const res = await chrome.tabs.sendMessage(tabId, { type: 'quickSaveWord', word: w.word });
      if (res?.ok) { save.classList.add('saved'); save.textContent = 'L1'; }
      else { save.disabled = false; save.textContent = 'Retry'; }
    };
    li.append(wordEl, cnt, save);
    list.append(li);
  }
}

async function renderPageHost() {
  const host = $('pageHost');
  if (!host) return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return;
    const url = new URL(tab.url);
    if (url.protocol === 'chrome:' || url.protocol === 'chrome-extension:') {
      host.textContent = url.protocol + '//' + (url.hostname || url.pathname.split('/')[0]);
      return;
    }
    host.textContent = url.hostname || 'Current page';
  } catch {
    host.textContent = 'Current page';
  }
}

$('exportCsv').addEventListener('click', async () => {
  const [vocab, settings] = await Promise.all([getVocabulary(), getSettings()]);
  const langs = new Set(activeSourceLangs(settings));
  const cards = Object.values(vocab).filter(c => langs.has(c.lang));
  if (!cards.length) return;
  const csv = cardsToCSV(cards);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const stamp = [...langs].join('-');
  a.download = `linguaflow-${stamp}-${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

renderPageHost();
applyPopupGlass();
renderGlassBackdrop();
refresh();
