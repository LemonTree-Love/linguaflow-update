import { getVocabulary, saveCard, getSettings } from '../lib/storage.js';
import { FSRS, pickDueCards } from '../lib/fsrs.js';
import { LANGUAGES, ttsLocale } from '../lib/languages.js';

const $ = (id) => document.getElementById(id);

let settings, fsrs, queue = [], index = 0, total = 0, current = null, revealed = false, isCloze = false;

async function boot() {
  settings = await getSettings();
  fsrs = new FSRS({
    weights: settings.fsrs.weights,
    requestRetention: settings.fsrs.requestRetention,
    maximumInterval: settings.fsrs.maximumInterval
  });
  const vocab = await getVocabulary();
  const activeLangs = new Set([settings.sourceLang, ...(settings.extraSourceLangs || [])]);
  const mine = Object.fromEntries(
    Object.entries(vocab).filter(([, c]) => activeLangs.has(c.lang) && (c.level || 1) < 5)
  );
  queue = pickDueCards(mine);
  total = queue.length;
  if (total === 0) {
    $('empty').hidden = false;
    $('card').hidden = true;
    return;
  }
  $('card').hidden = false;
  showCurrent();
}

function makeCloze(sentence, word) {
  const wl = word.toLowerCase();
  const sl = sentence.toLowerCase();
  const idx = sl.indexOf(wl);
  if (idx < 0) return null;
  const before = sentence.slice(0, idx);
  const after = sentence.slice(idx + word.length);
  return { before, after, blank: '______' };
}

function showCurrent() {
  current = queue[index];
  revealed = false;
  isCloze = false;
  $('back').hidden = true;
  $('revealBtn').hidden = false;
  $('c-cloze').hidden = true;
  $('c-cloze-answer').hidden = true;
  $('c-word').hidden = false;

  const ctx = current.sentence || current.context || '';
  const canCloze = ctx.length > current.word.length + 5 && ctx.toLowerCase().includes(current.word.toLowerCase());
  if (canCloze && Math.random() < 0.35) {
    const c = makeCloze(ctx, current.word);
    if (c) {
      isCloze = true;
      $('c-word').hidden = true;
      const clozeEl = $('c-cloze');
      clozeEl.hidden = false;
      clozeEl.innerHTML = '';
      clozeEl.append(
        document.createTextNode(c.before),
        Object.assign(document.createElement('span'), { className: 'blank', textContent: c.blank }),
        document.createTextNode(c.after)
      );
    }
  }

  if (!isCloze) {
    $('c-word').textContent = current.word;
  }

  $('c-translation').textContent = current.translation || '';
  $('c-context').textContent = isCloze ? '' : (current.context || '');
  $('c-state').textContent = `${current.state} · rep ${current.reps || 0} · lapses ${current.lapses || 0}`;
  updateProgress();
  updatePredictedIntervals();
}

function updateProgress() {
  $('progress-label').textContent = `${index} / ${total}`;
  $('progress-fill').style.width = `${total ? (index / total) * 100 : 0}%`;
}

function updatePredictedIntervals() {
  for (const r of [1, 2, 3, 4]) {
    const preview = fsrs.review(current, r);
    $('i-' + r).textContent = formatInterval(preview.interval);
  }
}

function formatInterval(days) {
  if (days < 1) return '<1d';
  if (days < 30) return days + 'd';
  if (days < 365) return (days / 30).toFixed(1) + 'mo';
  return (days / 365).toFixed(1) + 'y';
}

function reveal() {
  if (revealed) return;
  revealed = true;
  $('back').hidden = false;
  $('revealBtn').hidden = true;
  if (isCloze) {
    const ans = $('c-cloze-answer');
    ans.hidden = false;
    ans.textContent = current.word;
    const blank = $('c-cloze').querySelector('.blank');
    if (blank) { blank.textContent = current.word; blank.classList.add('revealed'); }
  }
  if (settings.tts?.enabled) speak(current.word);
}

async function rate(rating) {
  if (!revealed) return;
  const updated = fsrs.review(current, rating);
  await saveCard(updated);
  index += 1;
  if (index >= total) {
    $('empty').hidden = false;
    $('card').hidden = true;
    updateProgress();
    return;
  }
  showCurrent();
}

function skip() {
  index += 1;
  if (index >= total) { $('empty').hidden = false; $('card').hidden = true; updateProgress(); return; }
  showCurrent();
}

function speak(text) {
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = ttsLocale(current?.lang || settings.sourceLang);
    u.rate = settings.tts.rate;
    speechSynthesis.speak(u);
  } catch (e) { /* noop */ }
}

$('revealBtn').addEventListener('click', reveal);
$('c-tts').addEventListener('click', () => speak(current?.word || ''));
$('c-skip').addEventListener('click', skip);
for (const btn of document.querySelectorAll('.rate')) {
  btn.addEventListener('click', () => rate(Number(btn.dataset.rating)));
}
$('toPopup').addEventListener('click', () => window.close());

document.addEventListener('keydown', (e) => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  if (e.code === 'Space' || e.key === 'Enter') { e.preventDefault(); if (!revealed) reveal(); return; }
  if (['1','2','3','4'].includes(e.key)) { e.preventDefault(); rate(Number(e.key)); }
});

boot();
