import { getVocabulary, getSettings, activeSourceLangs } from '../lib/storage.js';

const $ = (id) => document.getElementById(id);
const LEVEL_NAMES = ['', 'New', 'Familiar', 'Recog.', 'Almost', 'Mastered'];

async function boot() {
  const [vocab, settings] = await Promise.all([getVocabulary(), getSettings()]);
  const langs = new Set(activeSourceLangs(settings));
  const all = Object.values(vocab).filter(c => langs.has(c.lang));
  $('total').textContent = all.length;

  renderHeatmap(all);
  renderLevels(all);
  renderDailyChart(all);
  renderCloud(all);
  renderStragglers(all);
}

function renderHeatmap(cards) {
  const grid = $('heatmap');
  grid.innerHTML = '';
  const DAYS = 91;
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const counts = {};
  for (const c of cards) {
    if (!c.createdAt) continue;
    const d = new Date(c.createdAt);
    const key = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
    counts[key] = (counts[key] || 0) + 1;
  }
  for (const c of cards) {
    if (!c.lastReview) continue;
    const d = new Date(c.lastReview);
    const key = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
    counts[key] = (counts[key] || 0) + 0.5;
  }
  const vals = Object.values(counts);
  const maxVal = Math.max(...vals, 1);
  const q = (v) => {
    if (!v) return 0;
    if (v <= maxVal * 0.25) return 1;
    if (v <= maxVal * 0.5) return 2;
    if (v <= maxVal * 0.75) return 3;
    return 4;
  };

  const startDay = new Date(today);
  startDay.setDate(startDay.getDate() - DAYS + 1);
  const offset = (startDay.getDay() + 6) % 7;
  for (let i = 0; i < offset; i++) {
    const cell = document.createElement('span');
    cell.className = 'hm-cell empty';
    grid.append(cell);
  }

  let streak = 0;
  const check = new Date(today);
  const dateKey = (d) => `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
  if (counts[dateKey(check)]) {
    streak = 1;
    check.setDate(check.getDate() - 1);
  } else {
    check.setDate(check.getDate() - 1);
    if (counts[dateKey(check)]) { streak = 1; check.setDate(check.getDate() - 1); }
  }
  while (counts[dateKey(check)]) { streak++; check.setDate(check.getDate() - 1); }
  const badge = $('streakBadge');
  badge.textContent = streak > 0 ? `🔥 ${streak} day streak` : '';

  for (let i = 0; i < DAYS; i++) {
    const d = new Date(startDay);
    d.setDate(d.getDate() + i);
    const key = dateKey(d);
    const v = counts[key] || 0;
    const cell = document.createElement('span');
    cell.className = `hm-cell q${q(v)}`;
    cell.title = `${d.toLocaleDateString()} — ${Math.round(v)} activities`;
    grid.append(cell);
  }
}

function renderLevels(cards) {
  const wrap = $('levels');
  wrap.innerHTML = '';
  const counts = [0, 0, 0, 0, 0, 0]; // index 1..5
  for (const c of cards) counts[c.level || 1]++;
  const max = Math.max(...counts.slice(1), 1);
  for (let lvl = 1; lvl <= 5; lvl++) {
    const n = counts[lvl];
    const pct = (n / max * 100).toFixed(0);
    const row = document.createElement('div');
    row.className = 'level-row';
    row.innerHTML = `
      <span class="label">${lvl} · ${LEVEL_NAMES[lvl]}</span>
      <div class="track"><div class="bar lvl${lvl}" style="width:${Math.max(pct, 4)}%">${n || ''}</div></div>
      <span class="num">${n}</span>
    `;
    wrap.append(row);
  }
}

function renderDailyChart(cards) {
  const svg = $('line-chart');
  const DAYS = 30;
  const now = new Date();
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const buckets = new Array(DAYS).fill(0);
  for (const c of cards) {
    const d = new Date(c.createdAt || 0);
    const dayIdx = Math.floor((dayStart - new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()) / 86400000);
    if (dayIdx >= 0 && dayIdx < DAYS) buckets[DAYS - 1 - dayIdx]++;
  }
  const total = buckets.reduce((a, b) => a + b, 0);
  $('chart-total').textContent = `${total} words added in the last ${DAYS} days`;

  const W = 520, H = 140, P = 26;
  const maxV = Math.max(...buckets, 1);
  const stepX = (W - P * 2) / (DAYS - 1);
  const scaleY = (v) => H - P - (v / maxV) * (H - P * 2);

  const pts = buckets.map((v, i) => `${(P + i * stepX).toFixed(1)},${scaleY(v).toFixed(1)}`);
  const path = 'M ' + pts.join(' L ');
  const area = `M ${P},${H - P} L ` + pts.join(' L ') + ` L ${W - P},${H - P} Z`;

  svg.innerHTML = `
    <path class="area" d="${area}" />
    <path class="line" d="${path}" />
    ${buckets.map((v, i) => v ? `<circle class="dot" cx="${(P + i * stepX).toFixed(1)}" cy="${scaleY(v).toFixed(1)}" r="2" />` : '').join('')}
    <line class="axis" x1="${P}" y1="${H - P}" x2="${W - P}" y2="${H - P}" />
    <text x="${P}" y="${H - 6}" text-anchor="start">${DAYS}d ago</text>
    <text x="${W - P}" y="${H - 6}" text-anchor="end">today</text>
    <text x="${P - 4}" y="${scaleY(maxV) + 4}" text-anchor="end">${maxV}</text>
  `;
}

function renderCloud(cards) {
  const cloud = $('cloud');
  cloud.innerHTML = '';
  // Sort by created date descending, cap at 200 words
  const sorted = [...cards].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 200);
  for (const c of sorted) {
    const lvl = c.level || 1;
    const size = Math.round(30 - (lvl - 1) * 4); // L1=30px, L5=14px
    const span = document.createElement('span');
    span.className = `w lvl${lvl}`;
    span.style.fontSize = size + 'px';
    span.textContent = c.word;
    span.title = `${c.word} · ${c.translation || ''} · L${lvl}`;
    cloud.append(span);
  }
  if (!sorted.length) cloud.innerHTML = '<span style="color:var(--muted)">No words yet. Select any text on a webpage to start learning.</span>';
}

function renderStragglers(cards) {
  const list = $('stragglers');
  list.innerHTML = '';
  const now = Date.now();
  const stragglers = cards
    .filter(c => (c.level || 1) <= 2 && c.createdAt)
    .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0))
    .slice(0, 30);
  if (!stragglers.length) {
    list.innerHTML = '<li style="grid-column:1/-1;color:var(--muted)">Nothing lingering. Good work.</li>';
    return;
  }
  for (const c of stragglers) {
    const days = Math.floor((now - c.createdAt) / 86400000);
    const li = document.createElement('li');
    li.innerHTML = `<span><b>${esc(c.word)}</b> — ${esc(c.translation || '')}</span><span class="days">${days}d · L${c.level||1}</span>`;
    list.append(li);
  }
}

function esc(s) { return String(s || '').replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }

boot();
