import { getSettings, saveSettings, clearVocabulary, getVocabulary, saveCard, newCard } from '../lib/storage.js';
import { LANGUAGES } from '../lib/languages.js';
import { PROVIDER_LIST, CUSTOM_RECIPES, DEFAULT_PROMPTS, parseExtraBody } from '../lib/translators.js';
import { pickSyncFolder, getSyncFolderInfo, forgetSyncFolder, reauthorize, syncNow, syncUpload, syncDownload, webdavTest, gistTest } from '../lib/sync.js';
import { FSRS } from '../lib/fsrs.js';
import { VOICE_DEFAULTS, VOICE_CHOICES } from '../lib/tts.js';
import { applyI18n, getLang, setLang, t } from '../lib/i18n.js';

const $ = (id) => document.getElementById(id);
const asArray = (value) => Array.isArray(value) ? value : [];
let settings;

// Keep option-page boot resilient: each major panel hydrates itself inside a
// guarded step, so Provider / TTS / Sync failures surface locally instead of
// stopping the rest of the settings UI from rendering.
async function runBootStep(label, panels, fn) {
  try {
    await fn();
    return true;
  } catch (err) {
    console.error(`[LinguaFlow options] ${label} init failed:`, err);
    showBootStepError(panels, label, err);
    return false;
  }
}

function showBootStepError(panels, label, err) {
  const panelIds = Array.isArray(panels) ? panels : [panels];
  for (const id of panelIds) {
    const panel = $(id);
    if (!panel) continue;
    const box = document.createElement('div');
    box.className = 'boot-error';
    box.textContent = `${label} 初始化失败：${err?.message || String(err)}`;
    panel.prepend(box);
  }
}

function fillLanguages() {
  for (const sel of [$('sourceLang'), $('nativeLang')]) {
    sel.innerHTML = LANGUAGES.map(l => `<option value="${l.code}">${l.name} (${l.code})</option>`).join('');
  }
}

// Re-render the Also-recognize checklist. Called on boot and whenever the
// primary language changes (so it stays out of the extras list).
function renderExtraLangChecklist(primary, selectedExtras, onChange) {
  const wrap = document.getElementById('extraSourceLangs');
  if (!wrap) return;
  wrap.innerHTML = '';
  const selected = new Set(Array.isArray(selectedExtras) ? selectedExtras : []);
  for (const l of LANGUAGES) {
    if (l.code === primary) continue;          // can't double-list the primary
    const id = `extra-${l.code}`;
    const row = document.createElement('label');
    row.className = 'lang-chk';
    row.innerHTML = `<input type="checkbox" id="${id}" value="${l.code}" ${selected.has(l.code) ? 'checked' : ''} /><span>${l.name} <span class="code">(${l.code})</span></span>`;
    row.querySelector('input').addEventListener('change', (e) => {
      onChange(e.target.value, e.target.checked);
    });
    wrap.append(row);
  }
}

function fillProviders() {
  $('translator').innerHTML = PROVIDER_LIST.map(p => `<option value="${p.id}">${p.label}</option>`).join('');
}

// ---- Custom-API profile manager ------------------------------------
// Separate from the "active profile" (which translator requests use): user
// can be editing Profile B's form while Profile A is still the active one.
let editingProfileId = '';

function getEditingProfile() {
  const profiles = Array.isArray(settings.customApiProfiles) ? settings.customApiProfiles : [];
  return profiles.find(p => p.id === editingProfileId) || null;
}

function syncActiveIntoCustomApi() {
  const profiles = Array.isArray(settings.customApiProfiles) ? settings.customApiProfiles : [];
  const active = profiles.find(p => p.id === settings.customApiActiveId) || profiles[0];
  if (!active) {
    settings.customApi = { endpoint: '', model: '', key: '', extraBody: '' };
    return;
  }
  settings.customApi = {
    endpoint: active.endpoint || '',
    model:    active.model || '',
    key:      active.apiKey || '',
    extraBody: active.extraBody || ''
  };
  settings.temperature = active.temperature ?? 1;
  settings.skipTemperature = !!active.skipTemperature;
}

async function persistProfiles() {
  syncActiveIntoCustomApi();
  settings = await saveSettings({
    customApiProfiles: settings.customApiProfiles,
    customApiActiveId: settings.customApiActiveId,
    customApiRotation: settings.customApiRotation,
    customApi: settings.customApi
  });
}

function renderProfileUI() {
  const profiles = Array.isArray(settings.customApiProfiles) ? settings.customApiProfiles : [];
  const activeSelect = $('profile-active');
  if (activeSelect) {
    activeSelect.innerHTML = profiles.length
      ? profiles.map(p => `<option value="${p.id}"${p.id === settings.customApiActiveId ? ' selected' : ''}>${escapeAttr(p.name || 'Unnamed')}</option>`).join('')
      : '<option value="">(no profile)</option>';
    activeSelect.disabled = profiles.length === 0;
  }
  const rotEl = $('profile-rotation');
  if (rotEl) rotEl.checked = !!settings.customApiRotation;

  const chips = $('profile-chips');
  if (chips) {
    chips.innerHTML = '';
    for (const p of profiles) {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'profile-chip' + (p.id === editingProfileId ? ' editing' : '') + (p.id === settings.customApiActiveId ? ' active' : '');
      const tags = [];
      if (p.id === settings.customApiActiveId) tags.push('●激活');
      if (p.inRotation) tags.push('↻轮询');
      chip.innerHTML = `<span class="name">${escapeAttr(p.name || 'Unnamed')}</span>${tags.length ? `<span class="tags">${tags.join(' ')}</span>` : ''}`;
      chip.addEventListener('click', () => { editingProfileId = p.id; renderProfileUI(); });
      chips.append(chip);
    }
  }

  const editor   = $('profile-editor');
  const emptyMsg = $('profile-empty-msg');
  const editing  = getEditingProfile();
  if (editor) editor.hidden = !editing;
  if (emptyMsg) emptyMsg.hidden = profiles.length > 0;
  if (editing) {
    $('custom-name').value     = editing.name || '';
    $('custom-endpoint').value = editing.endpoint || '';
    $('custom-model').value    = editing.model || '';
    $('custom-key').value      = editing.apiKey || '';
    $('custom-extra').value    = editing.extraBody || '';
    $('custom-in-rotation').checked = !!editing.inRotation;
    $('custom-temperature').value = editing.temperature ?? 1;
    $('custom-temperature-val').textContent = Number(editing.temperature ?? 1).toFixed(2);
    $('custom-skip-temperature').checked = !!editing.skipTemperature;
  }
}

function escapeAttr(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]));
}

function wireCustomProfiles() {
  // Initial editing target = active profile.
  editingProfileId = settings.customApiActiveId || (asArray(settings.customApiProfiles)[0]?.id) || '';
  renderProfileUI();

  const activeSel = $('profile-active');
  activeSel?.addEventListener('change', async (e) => {
    settings.customApiActiveId = e.target.value;
    editingProfileId = settings.customApiActiveId;
    await persistProfiles();
    renderProfileUI();
    toast('已切换激活档案');
  });
  $('profile-rotation')?.addEventListener('change', async (e) => {
    settings.customApiRotation = e.target.checked;
    await persistProfiles();
    toast();
  });
  $('profile-add')?.addEventListener('click', async () => {
    const id = 'p_' + Math.random().toString(36).slice(2, 9);
    settings.customApiProfiles = [...asArray(settings.customApiProfiles), {
      id, name: 'New profile', endpoint: '', apiKey: '', model: '',
      temperature: 1, skipTemperature: false, extraBody: '', inRotation: false
    }];
    if (!settings.customApiActiveId) settings.customApiActiveId = id;
    editingProfileId = id;
    await persistProfiles();
    renderProfileUI();
    toast('新档案已创建');
    $('custom-name').focus();
  });
  $('profile-delete')?.addEventListener('click', async () => {
    const p = getEditingProfile();
    if (!p) return;
    if (!confirm(`删除档案 "${p.name}"? 此操作不可撤销。`)) return;
    settings.customApiProfiles = asArray(settings.customApiProfiles).filter(x => x.id !== p.id);
    if (settings.customApiActiveId === p.id) {
      settings.customApiActiveId = settings.customApiProfiles[0]?.id || '';
    }
    editingProfileId = settings.customApiActiveId;
    await persistProfiles();
    renderProfileUI();
    toast('已删除');
  });
}

function renderKeyInputs() {
  const wrap = $('keyInputs');
  if (!wrap) return;
  wrap.innerHTML = '';
  const needs = PROVIDER_LIST.find(p => p.id === settings.translator)?.needsKey;
  const apiKeys = settings.apiKeys && typeof settings.apiKeys === 'object' && !Array.isArray(settings.apiKeys)
    ? settings.apiKeys
    : {};
  const rows = [
    { id: 'deepseek', label: 'DeepSeek API key', placeholder: 'sk-...', docUrl: 'https://platform.deepseek.com/' },
    { id: 'openai',   label: 'OpenAI API key',   placeholder: 'sk-...', docUrl: 'https://platform.openai.com/api-keys' },
    { id: 'qwen',     label: 'Qwen (DashScope) API key', placeholder: 'sk-...', docUrl: 'https://bailian.console.aliyun.com/' },
    { id: 'gemini',   label: 'Google Gemini / Gemma API key', placeholder: 'AIza...', docUrl: 'https://aistudio.google.com/apikey' },
    { id: 'claude',   label: 'Anthropic Claude API key', placeholder: 'sk-ant-...', docUrl: 'https://console.anthropic.com/settings/keys' },
    { id: 'deepl',    label: 'DeepL auth key(s)', placeholder: 'xxxx:fx, yyyy:fx — 逗号分隔多个 key 自动轮询', docUrl: 'https://www.deepl.com/pro-api' }
  ];
  for (const r of rows) {
    const row = document.createElement('div');
    row.className = 'key-row';
    const required = needs === r.id;
    row.innerHTML = `
      <label>${r.label}${required ? ' <span class="required-marker">*</span>' : ''}
        <input type="password" id="key-${r.id}" placeholder="${r.placeholder}" autocomplete="off" />
      </label>
      <div class="hint">Get a key at <a href="${r.docUrl}" target="_blank" rel="noopener">${new URL(r.docUrl).host}</a>. Stored locally, never synced.</div>
    `;
    if (r.id === 'deepl') {
      const toggle = document.createElement('label');
      toggle.className = 'inline';
      toggle.style.marginTop = '6px';
      toggle.innerHTML = `<input type="checkbox" id="deepl-rotation" /> <span>参与轮询(DeepL key 和自定义档案一起轮流使用)</span>`;
      row.append(toggle);
    }
    wrap.append(row);
    row.querySelector('input').value = apiKeys[r.id] || '';
    row.querySelector('input').addEventListener('change', async (e) => {
      settings.apiKeys = settings.apiKeys && typeof settings.apiKeys === 'object' && !Array.isArray(settings.apiKeys)
        ? settings.apiKeys
        : {};
      settings.apiKeys[r.id] = e.target.value;
      await saveSettings({ apiKeys: settings.apiKeys });
      toast();
    });
    if (r.id === 'deepl') {
      const cb = row.querySelector('#deepl-rotation');
      cb.checked = !!settings.deeplRotation;
      cb.addEventListener('change', async (e) => {
        settings.deeplRotation = e.target.checked;
        await saveSettings({ deeplRotation: settings.deeplRotation });
        toast();
      });
    }
  }
  // Custom pane shows only when provider === 'custom'
  $('customApiPane').hidden = settings.translator !== 'custom';
}

function initPanelNav() {
  const buttons = [...document.querySelectorAll('.nav-item[data-panel]')];
  const panels = [...document.querySelectorAll('section[id]')];
  if (!buttons.length || !panels.length) return;

  const panelIds = new Set(panels.map(panel => panel.id));
  const savedPanel = localStorage.getItem('linguaflow-options-panel');
  const initialPanel = panelIds.has(savedPanel) ? savedPanel : buttons[0].dataset.panel;

  const showPanel = (id) => {
    if (!panelIds.has(id)) return;
    for (const button of buttons) {
      const active = button.dataset.panel === id;
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    }
    for (const panel of panels) {
      const active = panel.id === id;
      panel.hidden = !active;
      panel.classList.toggle('active', active);
    }
    const activeBtn = buttons.find(b => b.dataset.panel === id);
    $('activePanelTitle').textContent = activeBtn?.textContent || 'Settings';
    localStorage.setItem('linguaflow-options-panel', id);
    document.querySelector('.settings-main')?.scrollTo(0, 0);
  };

  for (const button of buttons) {
    button.addEventListener('click', () => showPanel(button.dataset.panel));
  }
  showPanel(initialPanel);

  // Language toggle
  const langBtn = $('langToggle');
  const refreshLangBtn = () => { langBtn.textContent = getLang() === 'zh' ? 'EN' : '中文'; };
  refreshLangBtn();
  applyI18n();
  // Re-sync header title after i18n
  const curPanel = localStorage.getItem('linguaflow-options-panel') || initialPanel;
  const curBtn = buttons.find(b => b.dataset.panel === curPanel);
  if (curBtn) $('activePanelTitle').textContent = curBtn.textContent;

  langBtn.addEventListener('click', () => {
    setLang(getLang() === 'zh' ? 'en' : 'zh');
    applyI18n();
    refreshLangBtn();
    const activeId = localStorage.getItem('linguaflow-options-panel') || initialPanel;
    const btn = buttons.find(b => b.dataset.panel === activeId);
    if (btn) $('activePanelTitle').textContent = btn.textContent;
  });

  // Collapsible sidebar groups
  const groups = [...document.querySelectorAll('.nav-group')];
  const STORAGE_KEY = 'linguaflow-collapsed-groups';
  const saved = (() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch { return []; }
  })();

  for (let i = 0; i < groups.length; i++) {
    const group = groups[i];
    const title = group.querySelector('.nav-group-title');
    if (!title) continue;

    const groupButtons = [...group.querySelectorAll('.nav-item[data-panel]')];
    const containsActive = groupButtons.some(b => b.dataset.panel === initialPanel);
    if (saved.includes(i) && !containsActive) group.classList.add('collapsed');

    title.addEventListener('click', () => {
      group.classList.toggle('collapsed');
      const collapsed = groups.map((g, idx) => g.classList.contains('collapsed') ? idx : -1).filter(x => x >= 0);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(collapsed));
    });
  }
}

async function boot() {
  initPanelNav();
  fillLanguages();
  fillProviders();
  settings = await getSettings();

  const bindEl = (id, handler) => {
    const el = $(id);
    if (!el) {
      console.warn(`[LinguaFlow options] Missing #${id}; skipping change binding.`);
      return;
    }
    el.addEventListener('change', async (e) => {
      await handler(e);
      settings = await getSettings();
      toast();
    });
  };

  let onExtraToggle = async (code, checked) => {
    const cur = new Set(asArray(settings.extraSourceLangs));
    if (checked) cur.add(code); else cur.delete(code);
    cur.delete(settings.sourceLang);    // primary can't simultaneously be an extra
    settings.extraSourceLangs = [...cur];
    await saveSettings({ extraSourceLangs: settings.extraSourceLangs });
    toast();
  };

  await runBootStep('语言设置', 'languages', async () => {
    $('sourceLang').value = settings.sourceLang;
    $('nativeLang').value = settings.nativeLang;
    renderExtraLangChecklist(settings.sourceLang, settings.extraSourceLangs, onExtraToggle);
  });

  await runBootStep('翻译服务基础配置', 'provider', async () => {
    $('translator').value = settings.translator;
    $('deepseekModel').value = settings.deepseekModel || '';
    $('openaiModel').value   = settings.openaiModel || '';
    $('qwenModel').value     = settings.qwenModel || '';
    $('geminiModel').value   = settings.geminiModel || '';
    $('claudeModel').value   = settings.claudeModel || '';
    $('aiContext').checked   = settings.aiContext !== false;
    const scope = settings.aiContextScope || 'sentence';
    ($(scope === 'paragraph' ? 'scopeParagraph' : 'scopeSentence') || {}).checked = true;
    $('aiContextScopeRow').style.display = settings.aiContext !== false ? '' : 'none';
    wireCustomProfiles();
  });

  await runBootStep('AI 提示词', 'prompts', async () => {
    const promptConfigs = [
      { key: 'wordTranslation', el: 'prompt-wt',  resetEl: 'prompt-wt-reset' },
      { key: 'wordExplain2',    el: 'prompt-w2',  resetEl: 'prompt-w2-reset' },
      { key: 'etymology',       el: 'prompt-ety', resetEl: 'prompt-ety-reset' },
      { key: 'sentenceTranslation', el: 'prompt-st', resetEl: 'prompt-st-reset' },
      { key: 'youtubeCaption',  el: 'prompt-yt',  resetEl: 'prompt-yt-reset' }
    ];
    for (const { key, el, resetEl } of promptConfigs) {
      const stored = settings.aiPrompts?.[key] ||
        (key === 'wordTranslation' ? settings.aiPromptOverride : '') || '';
      $(el).value = stored || DEFAULT_PROMPTS[key];
      $(el).addEventListener('change', async (e) => {
        const v = e.target.value;
        // Store empty when equal to default (keeps storage clean)
        const store = (v.trim() && v !== DEFAULT_PROMPTS[key]) ? v : '';
        settings.aiPrompts = { ...settings.aiPrompts, [key]: store };
        await saveSettings({ aiPrompts: settings.aiPrompts, aiPromptOverride: '' });
        toast(store ? `Custom prompt saved ✓` : `Prompt reset to default ✓`);
      });
      $(resetEl).addEventListener('click', async () => {
        $(el).value = DEFAULT_PROMPTS[key];
        settings.aiPrompts = { ...settings.aiPrompts, [key]: '' };
        await saveSettings({ aiPrompts: settings.aiPrompts });
        toast('Prompt reset to default ✓');
      });
    }
    const scEl = $('sentence-context');
    scEl.checked = settings.sentenceContext !== false;
    scEl.addEventListener('change', async (e) => {
      settings.sentenceContext = e.target.checked;
      await saveSettings({ sentenceContext: e.target.checked });
      toast(e.target.checked ? 'AI 智能上下文已开启 ✓' : 'AI 智能上下文已关闭');
    });
  });

  await runBootStep('自定义 API recipes', 'provider', async () => {
    const rec = $('custom-recipes');
    rec.innerHTML = '';
    for (const r of CUSTOM_RECIPES) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'ghost'; b.textContent = r.label;
      b.onclick = async () => {
        const p = getEditingProfile();
        if (!p) { toast('先创建或选择一个档案'); return; }
        p.endpoint = r.endpoint;
        p.model = r.model;
        if (!p.name || p.name === 'Default' || p.name === 'New profile') p.name = r.label;
        $('custom-endpoint').value = p.endpoint;
        $('custom-model').value    = p.model;
        $('custom-name').value     = p.name;
        await persistProfiles();
        renderProfileUI();
        toast(`Loaded: ${r.label}`);
      };
      rec.append(b);
    }
  });
  await runBootStep('交互与高亮', ['interaction', 'youtube'], async () => {
    $('highlightMode').value = settings.highlightMode || 'unknown';
    $('ignoreList').value = asArray(settings.ignoreList).join(', ');
    $('showOnSelection').checked = !!settings.showOnSelection;
    $('youtubeCaption').checked = settings.youtubeCaption !== false;
    $('youtubeCaptionFix').checked = !!settings.youtubeCaptionFix;
    $('youtubeBionic').checked = !!settings.youtubeBionic;
    $('bionicReading').checked = !!settings.bionicReading;
    $('dailyGoal').value = settings.dailyGoal || 10;
  });

  // Per-provider "Refresh voice list" cache (keyed by provider) — filled on
  // demand when the user hits the 🔄 button to pull the full live list.
  const liveVoicesCache = { 'azure': null, 'google-cloud': null };

  // Wrap the entire TTS-panel hydration so a bug there can't stop
  // renderKeyInputs / applyBackendPanes from running (which had been happening
  // silently on some profiles and left the 翻译服务 / 云端同步 panels empty).
  await runBootStep('TTS 面板', 'tts', async () => {
    $('ttsEnabled').checked = !!settings.tts.enabled;
    $('ttsRate').value = settings.tts.rate;
    $('ttsRateVal').textContent = Number(settings.tts.rate).toFixed(2) + '×';
    const ttsProviderEl = $('ttsProvider');
    if (ttsProviderEl) ttsProviderEl.value = settings.tts.provider || 'browser';
    const setIf = (id, v) => { const el = $(id); if (el) el.value = v; };
    setIf('tts-google-key',   settings.tts.google?.apiKey || '');
    setIf('tts-azure-key',    settings.tts.azure?.apiKey  || '');
    setIf('tts-azure-region', settings.tts.azure?.region  || 'eastus');
    setIf('tts-openai-voice', settings.tts.openai?.voice  || 'alloy');
    refreshTtsPanes();
    renderTtsVoiceOverrides();
    // Seed test-lang dropdown with the user's active source languages.
    const testLangSel = $('tts-test-lang');
    if (testLangSel) {
      const activeLangs = [settings.sourceLang, ...asArray(settings.extraSourceLangs)].filter(Boolean);
      testLangSel.innerHTML = activeLangs.map(code => {
        const info = LANGUAGES.find(l => l.code === code);
        return `<option value="${code}">${info ? info.name : code}</option>`;
      }).join('');
    }
  });

  await runBootStep('复习参数', 'fsrs', async () => {
    $('requestRetention').value = settings.fsrs.requestRetention;
    $('retentionVal').textContent = Math.round(settings.fsrs.requestRetention * 100) + '%';
    $('maximumInterval').value = settings.fsrs.maximumInterval ?? 36500;
    $('fsrsWeights').value = Array.isArray(settings.fsrs.weights) && settings.fsrs.weights.length === 19
      ? settings.fsrs.weights.join(', ')
      : '';
  });

  await runBootStep('API Key 输入区', 'provider', async () => {
    renderKeyInputs();
  });

  bindEl('sourceLang', async (e) => {
    settings.sourceLang = e.target.value;
    // The newly-primary can't simultaneously be an extra — drop + re-render.
    settings.extraSourceLangs = asArray(settings.extraSourceLangs).filter(l => l !== settings.sourceLang);
    await saveSettings({ sourceLang: settings.sourceLang, extraSourceLangs: settings.extraSourceLangs });
    renderExtraLangChecklist(settings.sourceLang, settings.extraSourceLangs, onExtraToggle);
  });
  bindEl('nativeLang', async (e) => { settings.nativeLang = e.target.value; await saveSettings({ nativeLang: settings.nativeLang }); });
  bindEl('translator', async (e) => { settings.translator = e.target.value; await saveSettings({ translator: settings.translator }); renderKeyInputs(); });
  bindEl('deepseekModel', async (e) => { await saveSettings({ deepseekModel: e.target.value }); });
  bindEl('openaiModel',   async (e) => { await saveSettings({ openaiModel: e.target.value }); });
  bindEl('qwenModel',     async (e) => { await saveSettings({ qwenModel: e.target.value }); });
  bindEl('geminiModel',   async (e) => { await saveSettings({ geminiModel: e.target.value }); });
  bindEl('claudeModel',   async (e) => { await saveSettings({ claudeModel: e.target.value }); });
  bindEl('aiContext',     async (e) => {
    await saveSettings({ aiContext: e.target.checked });
    $('aiContextScopeRow').style.display = e.target.checked ? '' : 'none';
  });
  for (const radio of document.querySelectorAll('input[name="aiContextScope"]')) {
    radio.addEventListener('change', async (e) => {
      await saveSettings({ aiContextScope: e.target.value });
    });
  }

  // Custom-API editor fields write back into the currently-edited profile.
  for (const id of ['custom-name', 'custom-endpoint', 'custom-model', 'custom-key', 'custom-extra']) {
    $(id).addEventListener('change', async () => {
      const p = getEditingProfile();
      if (!p) return;
      p.name     = $('custom-name').value.trim() || 'Unnamed';
      p.endpoint = $('custom-endpoint').value.trim();
      p.model    = $('custom-model').value.trim();
      p.apiKey   = $('custom-key').value;
      p.extraBody= $('custom-extra').value;
      await persistProfiles();
      renderProfileUI();
      toast();
    });
  }
  $('custom-in-rotation').addEventListener('change', async (e) => {
    const p = getEditingProfile();
    if (!p) return;
    p.inRotation = e.target.checked;
    await persistProfiles();
    renderProfileUI();
    toast();
  });
  $('custom-temperature').addEventListener('input', (e) => {
    $('custom-temperature-val').textContent = Number(e.target.value).toFixed(2);
  });
  $('custom-temperature').addEventListener('change', async (e) => {
    const p = getEditingProfile();
    if (!p) return;
    p.temperature = parseFloat(e.target.value);
    await persistProfiles();
    toast();
  });
  $('custom-skip-temperature').addEventListener('change', async (e) => {
    const p = getEditingProfile();
    if (!p) return;
    p.skipTemperature = e.target.checked;
    await persistProfiles();
    toast();
  });

  $('profile-test')?.addEventListener('click', async () => {
    const p = getEditingProfile();
    const status = $('profile-test-status');
    if (!p) { status.textContent = '请先选择一个档案'; status.className = 'hint err'; return; }
    if (!p.endpoint || !p.apiKey) { status.textContent = '✗ Endpoint 或 API key 为空'; status.className = 'hint err'; return; }
    status.textContent = '连接中…'; status.className = 'hint';
    const t0 = performance.now();
    try {
      const extra = parseExtraBody(p.extraBody);
      const body = {
        model: p.model || 'gpt-4o-mini',
        messages: [{ role: 'user', content: 'Hi' }],
        max_tokens: 5, stream: false,
        ...extra
      };
      if (!p.skipTemperature) body.temperature = p.temperature ?? 1;
      const res = await fetch(p.endpoint.trim(), {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${p.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const ms = Math.round(performance.now() - t0);
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        status.textContent = `✗ HTTP ${res.status} (${ms}ms) — ${text.slice(0, 120)}`;
        status.className = 'hint err';
        return;
      }
      const data = await res.json();
      const reply = data?.choices?.[0]?.message?.content?.trim() || '';
      const model = data?.model || p.model || '?';
      status.textContent = `✓ 连通 (${ms}ms) · 模型: ${model}${reply ? ' · 回复: ' + reply.slice(0, 40) : ''}`;
      status.className = 'hint ok';
    } catch (e) {
      const ms = Math.round(performance.now() - t0);
      status.textContent = `✗ ${e.message} (${ms}ms)`;
      status.className = 'hint err';
    }
  });

  bindEl('highlightMode', async (e) => { settings.highlightMode = e.target.value; await saveSettings({ highlightMode: settings.highlightMode }); });
  {
    let ignoreTimer;
    const saveIgnore = async () => {
      const list = $('ignoreList').value.split(/[,\n]+/).map(w => w.trim()).filter(Boolean);
      settings.ignoreList = list;
      await saveSettings({ ignoreList: list });
      toast();
    };
    $('ignoreList').addEventListener('input', () => {
      clearTimeout(ignoreTimer);
      ignoreTimer = setTimeout(saveIgnore, 600);
    });
    $('ignoreList').addEventListener('change', () => {
      clearTimeout(ignoreTimer);
      saveIgnore();
    });

    $('ignoreSearch').addEventListener('input', () => {
      const q = $('ignoreSearch').value.trim().toLowerCase();
      const box = $('ignoreResults');
      if (!q) { box.style.display = 'none'; box.innerHTML = ''; return; }
      const list = ($('ignoreList').value || '').split(/[,\n]+/).map(w => w.trim()).filter(Boolean);
      const hits = list.filter(w => w.toLowerCase().includes(q));
      if (!hits.length) {
        box.style.display = 'block';
        box.innerHTML = '<span style="color:rgba(255,255,255,.5);font-size:14px">未找到匹配项</span>';
        return;
      }
      box.style.display = 'block';
      box.innerHTML = '';
      for (const word of hits) {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;margin:3px 0;background:rgba(255,255,255,.08);border-radius:8px;font-size:14px;color:rgba(255,255,255,.92)';
        const label = document.createElement('span');
        label.textContent = word;
        const btn = document.createElement('button');
        btn.textContent = '移除';
        btn.style.cssText = 'padding:4px 14px;font-size:13px;border:1px solid #e74c3c;color:#e74c3c;background:transparent;border-radius:6px;cursor:pointer';
        btn.onclick = () => {
          if (!confirm(`确定要将「${word}」从忽略词表中移除吗？`)) return;
          const cur = ($('ignoreList').value || '').split(/[,\n]+/).map(w => w.trim()).filter(Boolean);
          const updated = cur.filter(w => w.toLowerCase() !== word.toLowerCase());
          $('ignoreList').value = updated.join(', ');
          settings.ignoreList = updated;
          saveSettings({ ignoreList: updated });
          $('ignoreSearch').dispatchEvent(new Event('input'));
          toast();
        };
        row.append(label, btn);
        box.append(row);
      }
    });
  }
  bindEl('showOnSelection', async (e) => { await saveSettings({ showOnSelection: e.target.checked }); });
  bindEl('youtubeCaption', async (e) => { await saveSettings({ youtubeCaption: e.target.checked }); });
  bindEl('youtubeCaptionFix', async (e) => { await saveSettings({ youtubeCaptionFix: e.target.checked }); });
  bindEl('youtubeBionic', async (e) => { await saveSettings({ youtubeBionic: e.target.checked }); });
  bindEl('bionicReading', async (e) => { await saveSettings({ bionicReading: e.target.checked }); });
  bindEl('dailyGoal', async (e) => { await saveSettings({ dailyGoal: Math.max(1, parseInt(e.target.value) || 10) }); });

  // ---- Glass customization ----
  const glass = settings.glass || {};
  $('glassSidebar').value = glass.sidebarOpacity ?? 52;
  $('glassHeader').value = glass.headerOpacity ?? 75;
  $('glassBlur').value = glass.blur ?? 40;
  applyGlass(glass);

  for (const [id, key] of [['glassSidebar', 'sidebarOpacity'], ['glassHeader', 'headerOpacity'], ['glassBlur', 'blur']]) {
    $(id).addEventListener('input', (e) => {
      applyGlass({ ...settings.glass, [key]: parseInt(e.target.value) });
    });
    $(id).addEventListener('change', async (e) => {
      settings.glass = { ...(settings.glass || {}), [key]: parseInt(e.target.value) };
      await saveSettings({ glass: settings.glass });
      toast();
    });
  }

  // ---- Popup glass customization ----
  $('glassPopup').value = glass.popupOpacity ?? 24;
  $('glassPopupNav').value = glass.popupNavOpacity ?? 4;
  $('glassPopupBlur').value = glass.popupBlur ?? 46;
  applyPopupGlassPreview(glass);

  for (const [id, key] of [['glassPopup', 'popupOpacity'], ['glassPopupNav', 'popupNavOpacity'], ['glassPopupBlur', 'popupBlur']]) {
    $(id).addEventListener('input', (e) => {
      applyPopupGlassPreview({ ...settings.glass, [key]: parseInt(e.target.value) });
    });
    $(id).addEventListener('change', async (e) => {
      settings.glass = { ...(settings.glass || {}), [key]: parseInt(e.target.value) };
      await saveSettings({ glass: settings.glass });
      toast();
    });
  }

  // ---- Tooltip glass customization ----
  $('glassTooltip').value = glass.tooltipOpacity ?? 92;
  $('glassTooltipBlur').value = glass.tooltipBlur ?? 16;
  applyTooltipGlassPreview(glass);

  for (const [id, key] of [['glassTooltip', 'tooltipOpacity'], ['glassTooltipBlur', 'tooltipBlur']]) {
    $(id).addEventListener('input', (e) => {
      applyTooltipGlassPreview({ ...settings.glass, [key]: parseInt(e.target.value) });
    });
    $(id).addEventListener('change', async (e) => {
      settings.glass = { ...(settings.glass || {}), [key]: parseInt(e.target.value) };
      await saveSettings({ glass: settings.glass });
      toast();
    });
  }
  bindEl('ttsEnabled', async (e) => { settings.tts.enabled = e.target.checked; await saveSettings({ tts: settings.tts }); });

  $('ttsRate').addEventListener('input', (e) => { $('ttsRateVal').textContent = Number(e.target.value).toFixed(2) + '×'; });
  $('ttsRate').addEventListener('change', async (e) => { settings.tts.rate = parseFloat(e.target.value); await saveSettings({ tts: settings.tts }); toast(); });

  // --- TTS provider + per-provider config ------------------------------
  $('ttsProvider').addEventListener('change', async (e) => {
    settings.tts.provider = e.target.value;
    await saveSettings({ tts: settings.tts });
    refreshTtsPanes();
    renderTtsVoiceOverrides();
    toast();
  });
  $('tts-google-key').addEventListener('change', async (e) => {
    settings.tts.google = { ...(settings.tts.google || {}), apiKey: e.target.value.trim() };
    await saveSettings({ tts: settings.tts }); toast();
  });
  for (const id of ['tts-azure-key', 'tts-azure-region']) {
    $(id).addEventListener('change', async () => {
      settings.tts.azure = {
        ...(settings.tts.azure || {}),
        apiKey: $('tts-azure-key').value.trim(),
        region: $('tts-azure-region').value.trim() || 'eastus'
      };
      await saveSettings({ tts: settings.tts }); toast();
    });
  }
  $('tts-openai-voice').addEventListener('change', async (e) => {
    settings.tts.openai = { ...(settings.tts.openai || {}), voice: e.target.value };
    await saveSettings({ tts: settings.tts }); toast();
  });

  $('tts-test-btn').addEventListener('click', async () => {
    const status = $('tts-test-status');
    const text = $('tts-test-input').value.trim() || (
      $('tts-test-lang').value === 'ja' ? 'こんにちは、世界。' :
      $('tts-test-lang').value === 'zh' ? '你好，世界。' :
      'Hello, world.'
    );
    const lang = $('tts-test-lang').value || settings.sourceLang || 'en';
    status.textContent = '...'; status.className = 'hint';
    try {
      if ((settings.tts.provider || 'browser') === 'browser') {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = (LANGUAGES.find(l => l.code === lang)?.tts) || 'en-US';
        u.rate = settings.tts.rate || 1;
        speechSynthesis.speak(u);
        status.textContent = '✓ 播放中 (browser)'; status.className = 'hint ok';
        return;
      }
      const res = await chrome.runtime.sendMessage({ type: 'ttsSynthesize', text, lang });
      if (!res?.ok) { status.textContent = '✗ ' + (res?.error || 'failed'); status.className = 'hint err'; return; }
      const bin = atob(res.audioBase64);
      const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      const url = URL.createObjectURL(new Blob([arr], { type: res.mime || 'audio/mpeg' }));
      const a = new Audio(url);
      if ((settings.tts.provider || 'browser') === 'google-free') a.playbackRate = settings.tts.rate || 1;
      a.onended = () => URL.revokeObjectURL(url);
      await a.play();
      status.textContent = `✓ 播放中 (${settings.tts.provider}, ${Math.round(bin.length / 1024)} KB)`;
      status.className = 'hint ok';
    } catch (e) {
      status.textContent = '✗ ' + e.message; status.className = 'hint err';
    }
  });

  function refreshTtsPanes() {
    const p = $('ttsProvider').value;
    $('tts-google-pane').hidden = p !== 'google-cloud';
    $('tts-azure-pane').hidden  = p !== 'azure';
    $('tts-openai-pane').hidden = p !== 'openai';
    $('tts-voice-overrides').hidden = !(p === 'google-cloud' || p === 'azure');
  }

  function renderTtsVoiceOverrides() {
    const p = settings.tts.provider || 'browser';
    const wrap = $('tts-voice-list');
    wrap.innerHTML = '';
    if (p !== 'google-cloud' && p !== 'azure') return;

    const active = [settings.sourceLang, ...asArray(settings.extraSourceLangs)].filter(Boolean);
    const defaults = VOICE_DEFAULTS[p] || {};
    const curated = VOICE_CHOICES[p] || {};
    const live = liveVoicesCache[p] || [];

    // Top bar: refresh button + status.
    const bar = document.createElement('div');
    bar.className = 'buttons';
    bar.style.cssText = 'margin-bottom:10px;gap:10px;align-items:center';
    bar.innerHTML = `
      <button type="button" id="tts-voice-refresh" class="ghost">🔄 从 API 拉取全部声线</button>
      <span id="tts-voice-refresh-status" class="hint" style="margin:0"></span>
    `;
    wrap.append(bar);

    for (const code of active) {
      const info = LANGUAGES.find(l => l.code === code);
      const saved = settings.tts.voicesByLang?.[code] || '';
      const defaultVoice = defaults[code] || '';
      const curatedList = curated[code] || [];
      const liveList = live.filter(v => v.lang === code);
      // Merge curated + live, dedup by voice name, keep curated labels first.
      const seen = new Set(curatedList.map(v => v.name));
      const merged = [...curatedList];
      for (const v of liveList) if (!seen.has(v.name)) { seen.add(v.name); merged.push(v); }

      const row = document.createElement('div');
      row.className = 'tts-voice-row';
      row.innerHTML = `
        <span class="lang-col">${info?.name || code} <code>(${code})</code></span>
        <select class="tts-voice-select" data-lang="${code}" style="flex:1">
          <option value="">— 使用 provider 默认 ${defaultVoice ? '(' + defaultVoice + ')' : ''} —</option>
          ${merged.map(v => `<option value="${v.name}" ${v.name === saved ? 'selected' : ''}>${v.label}</option>`).join('')}
          <option value="__custom__" ${saved && !merged.some(v => v.name === saved) ? 'selected' : ''}>自定义…(手动输入 voice name)</option>
        </select>
        <input type="text" class="tts-voice-custom" data-lang="${code}" placeholder="e.g. en-US-AvaNeural" value="${saved && !merged.some(v => v.name === saved) ? saved : ''}" style="flex:1;display:${saved && !merged.some(v => v.name === saved) ? 'block' : 'none'}" />
        <button type="button" class="ghost tts-voice-test" data-lang="${code}" title="试听此声线">▶</button>
      `;
      wrap.append(row);
    }

    // Wire up selects / custom inputs / test buttons.
    wrap.querySelectorAll('.tts-voice-select').forEach((sel) => {
      sel.addEventListener('change', async (e) => {
        const code = e.target.dataset.lang;
        const row = e.target.closest('.tts-voice-row');
        const customInput = row.querySelector('.tts-voice-custom');
        const cur = { ...(settings.tts.voicesByLang || {}) };
        if (e.target.value === '__custom__') {
          customInput.style.display = 'block';
          customInput.focus();
          return;
        }
        customInput.style.display = 'none';
        customInput.value = '';
        if (e.target.value) cur[code] = e.target.value;
        else delete cur[code];
        settings.tts.voicesByLang = cur;
        await saveSettings({ tts: settings.tts });
        toast();
      });
    });
    wrap.querySelectorAll('.tts-voice-custom').forEach((inp) => {
      inp.addEventListener('change', async (e) => {
        const code = e.target.dataset.lang;
        const val = e.target.value.trim();
        const cur = { ...(settings.tts.voicesByLang || {}) };
        if (val) cur[code] = val; else delete cur[code];
        settings.tts.voicesByLang = cur;
        await saveSettings({ tts: settings.tts });
        toast();
      });
    });
    wrap.querySelectorAll('.tts-voice-test').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const code = btn.dataset.lang;
        const sample = code === 'ja' ? 'こんにちは、世界。'
                     : code === 'zh' || code === 'zh-TW' ? '你好，世界。'
                     : code === 'ko' ? '안녕하세요, 세계.'
                     : 'Hello, world.';
        const status = $('tts-voice-refresh-status');
        status.textContent = '…'; status.className = 'hint';
        try {
          const res = await chrome.runtime.sendMessage({ type: 'ttsSynthesize', text: sample, lang: code });
          if (!res?.ok) { status.textContent = '✗ ' + (res?.error || 'failed'); status.className = 'hint err'; return; }
          const bin = atob(res.audioBase64);
          const arr = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
          const url = URL.createObjectURL(new Blob([arr], { type: res.mime || 'audio/mpeg' }));
          const a = new Audio(url);
          a.onended = () => URL.revokeObjectURL(url);
          a.play();
          status.textContent = '✓ 播放中'; status.className = 'hint ok';
        } catch (e) {
          status.textContent = '✗ ' + e.message; status.className = 'hint err';
        }
      });
    });

    $('tts-voice-refresh').addEventListener('click', async () => {
      const status = $('tts-voice-refresh-status');
      status.textContent = '拉取中…'; status.className = 'hint';
      try {
        const { listVoices } = await import('../lib/tts.js');
        const all = await listVoices(p, settings);
        liveVoicesCache[p] = all;
        status.textContent = `✓ 拉到 ${all.length} 条声线,已合并到下拉`;
        status.className = 'hint ok';
        renderTtsVoiceOverrides();
      } catch (e) {
        status.textContent = '✗ ' + e.message; status.className = 'hint err';
      }
    });
  }
  $('requestRetention').addEventListener('input', (e) => { $('retentionVal').textContent = Math.round(e.target.value * 100) + '%'; });
  $('requestRetention').addEventListener('change', async (e) => { settings.fsrs.requestRetention = parseFloat(e.target.value); await saveSettings({ fsrs: settings.fsrs }); toast(); });

  // --- FSRS: maximum interval -----------------------------------------
  $('maximumInterval').addEventListener('change', async (e) => {
    const n = Math.round(Number(e.target.value));
    if (!Number.isFinite(n) || n < 1) { e.target.value = settings.fsrs.maximumInterval ?? 36500; return; }
    const capped = Math.min(Math.max(n, 1), 36500);
    e.target.value = capped;
    settings.fsrs.maximumInterval = capped;
    await saveSettings({ fsrs: settings.fsrs });
    toast();
  });

  // --- FSRS: custom 19-weight parameter vector ------------------------
  const parseWeights = (raw) => {
    const nums = raw.split(/[\s,;]+/).filter(Boolean).map(Number);
    if (nums.length !== 19) return { err: `需要 19 个数字 (当前 ${nums.length} 个)` };
    if (nums.some(n => !Number.isFinite(n))) return { err: '含有非数字' };
    // Bounds from fsrs-rs clamp ranges (loose — we just guard against insane values).
    for (let i = 0; i < 19; i++) {
      if (nums[i] < -100 || nums[i] > 100) return { err: `第 ${i + 1} 个数字超出 [-100,100]` };
    }
    return { nums };
  };
  $('fsrsWeightsSave').addEventListener('click', async () => {
    const raw = $('fsrsWeights').value.trim();
    const status = $('fsrsWeightsStatus');
    if (!raw) {
      settings.fsrs.weights = null;
      await saveSettings({ fsrs: settings.fsrs });
      status.textContent = '已清空 — 回退到 FSRS v5 默认权重 ✓';
      status.className = 'hint ok';
      toast();
      return;
    }
    const { nums, err } = parseWeights(raw);
    if (err) { status.textContent = '✗ ' + err; status.className = 'hint err'; return; }
    settings.fsrs.weights = nums;
    await saveSettings({ fsrs: settings.fsrs });
    status.textContent = '✓ 已保存 19 个自定义权重';
    status.className = 'hint ok';
    $('fsrsWeights').value = nums.join(', ');
    toast();
  });
  $('fsrsWeightsReset').addEventListener('click', async () => {
    $('fsrsWeights').value = '';
    settings.fsrs.weights = null;
    await saveSettings({ fsrs: settings.fsrs });
    $('fsrsWeightsStatus').textContent = '已恢复为默认 (留空即可继承 FSRS v5 默认) ✓';
    $('fsrsWeightsStatus').className = 'hint ok';
    toast();
  });

  // --- FSRS: reschedule all cards with the current parameters ----------
  $('fsrsReschedule').addEventListener('click', async () => {
    const status = $('fsrsRescheduleStatus');
    const vocab = await getVocabulary();
    const cards = Object.values(vocab);
    if (!cards.length) { status.textContent = '词库为空'; return; }
    if (!confirm(`将用当前 FSRS 参数重算 ${cards.length} 张卡片的下次复习时间。不会修改 stability/difficulty/学习进度。继续吗?`)) return;
    const fsrs = new FSRS({
      weights: settings.fsrs.weights,
      requestRetention: settings.fsrs.requestRetention,
      maximumInterval: settings.fsrs.maximumInterval
    });
    const now = Date.now();
    const DAY_MS = 24 * 60 * 60 * 1000;
    let changed = 0;
    for (const c of cards) {
      if (!c.stability || c.stability <= 0) continue;          // new/unreviewed — skip
      if ((c.level || 1) >= 5) continue;                        // mastered — keep pushed-out due
      const newInterval = fsrs.nextInterval(c.stability);
      if (newInterval === c.interval) continue;
      c.interval = newInterval;
      c.due = (c.lastReview || now) + newInterval * DAY_MS;
      c._updatedAt = now;
      changed++;
    }
    await chrome.storage.local.set({ vocabulary: vocab });
    status.textContent = `✓ 已重排 ${changed} / ${cards.length} 张卡片 (未复习过的新词和已掌握的词被跳过)`;
    status.className = 'hint ok';
    toast(`重排完成 ${changed} 张 ✓`);
  });

  $('exportJson').addEventListener('click', async () => {
    const vocab = await getVocabulary();
    const blob = new Blob([JSON.stringify({ version: 1, settings, vocabulary: vocab }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `linguaflow-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });

  $('importJson').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', async (e) => {
    const file = e.target.files[0]; if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!data.vocabulary) throw new Error('Invalid backup: missing vocabulary.');
      await chrome.storage.local.set({ vocabulary: data.vocabulary });
      if (data.settings) await saveSettings(data.settings);
      toast('Imported ' + Object.keys(data.vocabulary).length + ' cards ✓');
    } catch (err) { alert('Import failed: ' + err.message); }
  });

  $('clearVocab').addEventListener('click', async () => {
    if (!confirm('Delete all saved vocabulary? This cannot be undone.')) return;
    await clearVocabulary();
    toast('Vocabulary cleared ✓');
  });

  // Cleanup: find cards whose word only appears as a substring (not a whole
  // word) in its own saved context — these are almost always Bionic-split
  // fragments like "mich" (from "Michael") or "Amer" (from "America").
  let cleanupCandidates = [];
  const isLikelyFragment = (card) => {
    const word = (card.word || '').toLowerCase().trim();
    const ctx  = (card.context || '').toLowerCase();
    if (!word || !ctx) return false;
    if (word.length > 8) return false; // Real words longer than this are rarely half-word fragments
    const esc = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const whole = new RegExp(`(^|[^A-Za-z\\u00C0-\\u024F])${esc}($|[^A-Za-z\\u00C0-\\u024F])`);
    if (whole.test(ctx)) return false;      // appears as a whole word → legit
    return ctx.includes(word);               // only as substring → fragment
  };
  $('cleanupScan').addEventListener('click', async () => {
    const vocab = await getVocabulary();
    const cards = Object.values(vocab);
    cleanupCandidates = cards.filter(isLikelyFragment);
    const preview = $('cleanupPreview');
    const goBtn = $('cleanupGo');
    if (!cleanupCandidates.length) {
      preview.textContent = '✓ 未发现可疑碎片(共扫描 ' + cards.length + ' 张卡片)';
      goBtn.hidden = true;
      return;
    }
    const sample = cleanupCandidates.slice(0, 30).map(c => c.word).join('  ·  ');
    const more = cleanupCandidates.length > 30 ? `  …(+${cleanupCandidates.length - 30} 个)` : '';
    preview.textContent = `候选 ${cleanupCandidates.length} 个 / 共 ${cards.length} 张卡片: ${sample}${more}`;
    goBtn.hidden = false;
    goBtn.textContent = `删除全部 ${cleanupCandidates.length} 个候选`;
  });
  $('cleanupGo').addEventListener('click', async () => {
    if (!cleanupCandidates.length) return;
    if (!confirm(`将永久删除 ${cleanupCandidates.length} 个候选词条。无法撤销,确定吗?`)) return;
    const vocab = await getVocabulary();
    for (const c of cleanupCandidates) delete vocab[c.id];
    await chrome.storage.local.set({ vocabulary: vocab });
    const n = cleanupCandidates.length;
    cleanupCandidates = [];
    $('cleanupPreview').textContent = `已删除 ${n} 个碎片 ✓`;
    $('cleanupGo').hidden = true;
    toast(`清理完成: ${n} 个 ✓`);
  });

  // ---- TXT import ----
  $('txtLang').innerHTML = LANGUAGES.map(l => `<option value="${l.code}">${l.name} (${l.code})</option>`).join('');
  $('txtLang').value = settings.sourceLang;

  let txtPayload = '';
  const parseTxt = () => {
    if (!txtPayload) return [];
    const sep = document.querySelector('input[name="txt-sep"]:checked')?.value || 'newline';
    const rx = sep === 'newline' ? /\r?\n/ : sep === 'tab' ? /\t/ : /,/;
    return txtPayload.split(rx).map(s => s.trim()).filter(Boolean);
  };
  const refreshTxtPreview = () => {
    const words = parseTxt();
    if (!words.length) {
      $('txtPreview').textContent = 'No file selected yet.';
      $('txtImportGo').disabled = true;
      return;
    }
    const head = words.slice(0, 10).join('  ·  ');
    $('txtPreview').textContent = `${words.length} word(s) detected: ${head}${words.length > 10 ? ` … (+${words.length - 10} more)` : ''}`;
    $('txtImportGo').disabled = false;
  };
  $('txtFile').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (!f) { txtPayload = ''; refreshTxtPreview(); return; }
    txtPayload = await f.text();
    refreshTxtPreview();
  });
  for (const r of document.querySelectorAll('input[name="txt-sep"]')) {
    r.addEventListener('change', refreshTxtPreview);
  }
  $('txtImportClear').addEventListener('click', () => {
    txtPayload = ''; $('txtFile').value = ''; refreshTxtPreview(); $('txtImportStatus').textContent = '';
  });
  $('txtImportGo').addEventListener('click', async () => {
    const words = parseTxt();
    if (!words.length) return;
    const lang = $('txtLang').value;
    const level = Number($('txtLevel').value) || 1;
    const existingPolicy = document.querySelector('input[name="txt-existing"]:checked')?.value || 'skip';
    $('txtImportGo').disabled = true;
    $('txtImportStatus').textContent = `Importing…`;
    const { vocabulary = {} } = await chrome.storage.local.get('vocabulary');
    let added = 0, updated = 0, skipped = 0;
    const farFuture = Date.now() + 10 * 365 * 24 * 60 * 60 * 1000;
    for (const w of words) {
      const card = newCard({ word: w, translation: '', lang, level });
      const existing = vocabulary[card.id];
      if (existing) {
        if (existingPolicy === 'skip') { skipped++; continue; }
        if (existingPolicy === 'merge') {
          const previousLevel = existing.level || 1;
          const now = Date.now();
          existing.level = level;
          existing._updatedAt = now;
          if (level >= 5) { existing.state = 'review'; existing.due = farFuture; }
          else if (previousLevel >= 5 || !existing.due || existing.due > now + 365 * 24 * 60 * 60 * 1000) {
            existing.due = now;
          }
          vocabulary[card.id] = existing;
          updated++;
          continue;
        }
        // 'replace' — fall through to full overwrite
      }
      vocabulary[card.id] = card;
      added++;
    }
    // Single batched write → fast import (no per-word round-trip).
    await chrome.storage.local.set({ vocabulary });
    $('txtImportStatus').textContent = `✓ Done — added ${added}, updated ${updated}, skipped ${skipped}`;
    $('txtImportGo').disabled = false;
    toast(`Imported: +${added}, ~${updated}, skip ${skipped}`);
  });
  refreshTxtPreview();

  // ---- Anki section ----
  $('ankiEnabled').checked = !!settings.anki?.enabled;
  $('ankiDeckName').value = settings.anki?.deckName || 'LinguaFlow';
  $('ankiMinLevel').value = settings.anki?.minLevel ?? 1;
  $('ankiMaxLevel').value = settings.anki?.maxLevel ?? 4;
  $('ankiTriggerCount').value = settings.anki?.triggerCount ?? 10;
  $('ankiTriggerMinutes').value = settings.anki?.triggerMinutes ?? 30;
  $('ankiTags').value = settings.anki?.tags || '';

  const saveAnki = async (patch) => {
    settings.anki = { ...(settings.anki || {}), ...patch };
    await saveSettings({ anki: settings.anki });
    toast();
  };
  $('ankiEnabled').addEventListener('change', (e) => saveAnki({ enabled: e.target.checked }));
  $('ankiDeckName').addEventListener('change', (e) => saveAnki({ deckName: e.target.value.trim() || 'LinguaFlow' }));
  $('ankiMinLevel').addEventListener('change', (e) => saveAnki({ minLevel: Number(e.target.value) }));
  $('ankiMaxLevel').addEventListener('change', (e) => saveAnki({ maxLevel: Number(e.target.value) }));
  $('ankiTriggerCount').addEventListener('change', (e) => saveAnki({ triggerCount: Math.max(0, Number(e.target.value) || 0) }));
  $('ankiTriggerMinutes').addEventListener('change', (e) => saveAnki({ triggerMinutes: Math.max(0, Number(e.target.value) || 0) }));
  $('ankiTags').addEventListener('change', (e) => saveAnki({ tags: e.target.value }));

  $('ankiTest').addEventListener('click', async () => {
    const status = $('ankiStatus');
    status.textContent = '连接中…'; status.className = 'hint';
    try {
      const { testConnection, countPending } = await import('../lib/anki.js');
      const version = await testConnection();
      const vocab = await getVocabulary();
      const pending = countPending(vocab, settings.anki || {});
      status.textContent = `✓ 已连接 AnkiConnect v${version} · 待导出 ${pending} 张`;
      status.className = 'hint ok';
    } catch (e) {
      status.textContent = `✗ ${e.message.includes('Failed to fetch') ? 'Anki 未运行或 AnkiConnect 未安装' : e.message}`;
      status.className = 'hint err';
    }
  });

  $('ankiExportNow').addEventListener('click', async () => {
    const status = $('ankiStatus');
    status.textContent = '导出中…'; status.className = 'hint';
    try {
      const { exportPending } = await import('../lib/anki.js');
      const res = await exportPending();
      if (!res.ok) {
        status.textContent = `✗ ${res.error === 'disabled' ? '请先启用 AnkiConnect' : res.error}`;
        status.className = 'hint err';
        return;
      }
      const parts = [`✓ 新增 ${res.exported} 张`];
      if (res.skipped) parts.push(`跳过 ${res.skipped} 张(Anki 已有)`);
      if (!res.exported && !res.skipped) parts[0] = '✓ 没有待导出的卡片';
      status.textContent = parts.join(', ');
      status.className = 'hint ok';
      if (res.exported) toast(`Anki +${res.exported} 张 ✓`);
    } catch (e) {
      status.textContent = `✗ ${e.message.includes('Failed to fetch') ? 'Anki 未运行或 AnkiConnect 未安装' : e.message}`;
      status.className = 'hint err';
    }
  });

  // ---- Sync section ----
  // Sync touches optional browser APIs and remote-provider fields, so it is a
  // separate boot step: WebDAV/Gist/iCloud failures should not blank Provider.
  await runBootStep('云端同步', 'sync', async () => {
    $('syncBackend').value = settings.syncBackend || 'off';
    $('syncScope').value   = settings.syncScope || 'full';
    $('autoSync').checked  = !!settings.autoSync;
    $('webdav-url').value  = settings.webdav?.url || '';
    $('webdav-user').value = settings.webdav?.user || '';
    $('webdav-pass').value = settings.webdav?.pass || '';
    $('gist-token').value  = settings.gist?.token || '';
    if (settings.gist?.id) {
      $('gist-id-row').hidden = false;
      $('gist-id-display').textContent = settings.gist.id;
      $('gist-id-link').href = 'https://gist.github.com/' + settings.gist.id;
    }
    applyBackendPanes();
    await refreshSyncUI();

    $('syncBackend').addEventListener('change', async (e) => {
      settings.syncBackend = e.target.value;
      await saveSettings({ syncBackend: settings.syncBackend });
      applyBackendPanes();
      await refreshSyncUI();
      toast();
    });
    $('syncScope').addEventListener('change', async (e) => {
      settings.syncScope = e.target.value;
      await saveSettings({ syncScope: settings.syncScope });
      toast();
    });

    $('pickFolder').addEventListener('click', async () => {
      try {
        const info = await pickSyncFolder();
        settings.autoSync = true;
        settings.syncBackend = 'icloud';
        await saveSettings({ autoSync: true, syncBackend: 'icloud' });
        $('autoSync').checked = true;
        $('syncBackend').value = 'icloud';
        applyBackendPanes();
        toast('Folder picked: ' + info.name + ' — auto-sync on');
        await refreshSyncUI();
        await doSync();
      } catch (err) {
        if (err.name !== 'AbortError') alert('Could not pick folder: ' + err.message);
      }
    });

    $('syncNow').addEventListener('click', () => doSync(false));

    $('syncUpload').addEventListener('click', async () => {
      if (!confirm('确认上传？此设备的数据将覆盖云端存档。')) return;
      await doSyncDirectional(syncUpload, '上传完成');
    });
    $('syncDownload').addEventListener('click', async () => {
      if (!confirm('确认下载？云端存档将覆盖此设备的数据（设备专属设置保留）。')) return;
      await doSyncDirectional(syncDownload, '下载完成');
    });

    $('forgetFolder').addEventListener('click', async () => {
      if (!confirm('Disconnect sync folder? Vocabulary stays on this Mac.')) return;
      await forgetSyncFolder();
      await saveSettings({ autoSync: false });
      settings.autoSync = false;
      $('autoSync').checked = false;
      toast('Disconnected');
      await refreshSyncUI();
    });

    $('autoSync').addEventListener('change', async (e) => {
      settings.autoSync = e.target.checked;
      await saveSettings({ autoSync: settings.autoSync });
      toast();
    });

    // WebDAV fields are device-only credentials; persist them locally on edit
    // without marking the rest of syncable settings as changed.
    const saveWebdav = async () => {
      settings.webdav = {
        url:  $('webdav-url').value.trim(),
        user: $('webdav-user').value.trim(),
        pass: $('webdav-pass').value
      };
      settings = await saveSettings({ webdav: settings.webdav });
    };
    for (const id of ['webdav-url', 'webdav-user', 'webdav-pass']) {
      $(id).addEventListener('change', async () => { await saveWebdav(); toast(); });
    }

    $('webdav-test').addEventListener('click', async () => {
      await saveWebdav();
      const statusEl = $('webdav-status');
      statusEl.className = 'hint';
      statusEl.textContent = 'Testing…';
      try {
        const res = await webdavTest(settings);
        if (res.ok) {
          statusEl.className = 'hint ok';
          statusEl.textContent = res.created
            ? '✓ Connected, folder auto-created.'
            : '✓ Connected.';
          // Auto-enable auto-sync on successful first test.
          if (!settings.autoSync) {
            settings.autoSync = true;
            await saveSettings({ autoSync: true });
            $('autoSync').checked = true;
          }
        } else {
          statusEl.className = 'hint err';
          statusEl.textContent = '⚠ ' + res.error;
        }
      } catch (err) {
        statusEl.className = 'hint err';
        statusEl.textContent = '⚠ ' + err.message;
      }
    });

    // Gist uses a local PAT and optional discovered gist id; both stay
    // device-only like WebDAV credentials.
    $('gist-token').addEventListener('change', async () => {
      settings.gist = { ...(settings.gist || {}), token: $('gist-token').value.trim() };
      settings = await saveSettings({ gist: settings.gist });
      toast();
    });
    $('gist-test').addEventListener('click', async () => {
      settings.gist = { ...(settings.gist || {}), token: $('gist-token').value.trim() };
      settings = await saveSettings({ gist: settings.gist });
      const statusEl = $('gist-status');
      statusEl.className = 'hint';
      statusEl.textContent = 'Testing…';
      try {
        const res = await gistTest(settings);
        if (res.ok) {
          statusEl.className = 'hint ok';
          statusEl.textContent = res.gistExists
            ? '✓ Connected. Gist found.'
            : '✓ Token valid. A new private gist will be created on first sync.';
          if (!settings.autoSync) {
            settings.autoSync = true;
            await saveSettings({ autoSync: true });
            $('autoSync').checked = true;
          }
        } else {
          statusEl.className = 'hint err';
          statusEl.textContent = '⚠ ' + res.error;
        }
      } catch (err) {
        statusEl.className = 'hint err';
        statusEl.textContent = '⚠ ' + err.message;
      }
    });

    // Auto-sync on vocab changes (debounced, only while this page is open).
    let syncDebounce;
    let syncing = false;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || (!changes.vocabulary && !changes.settings)) return;
      if (changes.lastSyncAt) return;
      if (syncing) return;
      if (!settings.autoSync || settings.syncBackend === 'off') return;
      clearTimeout(syncDebounce);
      syncDebounce = setTimeout(async () => {
        const { lastSyncAt } = await chrome.storage.local.get('lastSyncAt');
        if (Date.now() - (lastSyncAt || 0) < 15000) return;
        doSync(true);
      }, 15000);
    });

    function applyBackendPanes() {
      const b = settings.syncBackend || 'off';
      $('icloud-pane').hidden = b !== 'icloud';
      $('webdav-pane').hidden = b !== 'webdav';
      $('gist-pane').hidden   = b !== 'gist';
      $('sync-footer').hidden  = b === 'off';
      $('autoSyncWrap').hidden = b === 'off';
    }

    async function doSync(silent = false) {
      if (syncing) return;
      const footer = $('sync-last');
      const statusEl = $('sync-status'); // iCloud-specific but safe to set
      syncing = true;
      if (footer) footer.textContent = 'Syncing…';
      try {
        let res = await syncNow();
        if (!res.ok && res.error === 'permission') {
          const state = await reauthorize();
          if (state === 'granted') res = await syncNow();
        }
        if (res.ok) {
          const txt = `Synced ${formatAgo(res.at)} · ${res.total} words (↓${Math.max(res.pulled,0)} ↑${Math.max(res.pushed,0)}) · 忽略词${res.ignoreCount || 0}个`;
          if (footer) footer.textContent = txt;
          if (statusEl && !statusEl.closest('[hidden]')) statusEl.textContent = txt;
          if (!silent) toast('Synced ✓');
          settings = await getSettings();
          $('ignoreList').value = asArray(settings.ignoreList).join(', ');
          if (settings.gist?.id) {
            $('gist-id-row').hidden = false;
            $('gist-id-display').textContent = settings.gist.id;
            $('gist-id-link').href = 'https://gist.github.com/' + settings.gist.id;
          }
        } else if (res.error === 'off') {
          if (footer) footer.textContent = '';
        } else if (res.error === 'no-folder') {
          if (footer) footer.textContent = 'Pick a folder to begin';
        } else if (res.error === 'webdav-config') {
          if (footer) footer.textContent = 'Fill in WebDAV URL / user / password';
        } else if (res.error === 'gist-config') {
          if (footer) footer.textContent = 'Enter a GitHub PAT to begin';
        } else {
          if (footer) footer.textContent = 'Sync failed: ' + (res.error || 'unknown');
        }
      } catch (err) {
        if (footer) footer.textContent = 'Sync failed: ' + err.message;
      } finally {
        syncing = false;
        await refreshSyncUI(true);
      }
    }

    async function doSyncDirectional(fn, label) {
      if (syncing) return;
      const footer = $('sync-last');
      syncing = true;
      if (footer) footer.textContent = label + '中…';
      try {
        let res = await fn();
        if (!res.ok && res.error === 'permission') {
          const state = await reauthorize();
          if (state === 'granted') res = await fn();
        }
        if (res.ok) {
          footer.textContent = `${label} · ${res.total} 词 · 忽略词${res.ignoreCount || 0}个 · ${formatAgo(res.at)}`;
          toast(label + ' ✓');
          settings = await getSettings();
          $('ignoreList').value = asArray(settings.ignoreList).join(', ');
        } else if (res.error === 'no-remote-data') {
          footer.textContent = '云端无数据';
        } else {
          footer.textContent = label + '失败: ' + (res.error || 'unknown');
        }
      } catch (err) {
        footer.textContent = label + '失败: ' + err.message;
      } finally {
        syncing = false;
        await refreshSyncUI(true);
      }
    }

    async function refreshSyncUI(skipFooter = false) {
      const backend = settings.syncBackend || 'off';
      const { lastSyncAt } = await chrome.storage.local.get('lastSyncAt');
      const footer = $('sync-last');
      if (footer && !skipFooter) {
        footer.textContent = backend === 'off' ? ''
          : lastSyncAt ? 'Last synced ' + formatAgo(lastSyncAt)
          : 'Never synced yet.';
      }

      if (backend !== 'icloud') return;
      const info = await getSyncFolderInfo();
      const folderEl = $('sync-folder');
      const statusEl = $('sync-status');
      const pick = $('pickFolder'), forget = $('forgetFolder');
      if (!info) {
        folderEl.textContent = 'Not configured';
        folderEl.classList.remove('active', 'warn');
        forget.disabled = true;
        pick.textContent = 'Choose folder…';
        statusEl.textContent = '';
        return;
      }
      folderEl.textContent = '📂 ' + info.name;
      folderEl.classList.toggle('active', info.permission === 'granted');
      folderEl.classList.toggle('warn', info.permission !== 'granted');
      forget.disabled = false;
      pick.textContent = 'Change folder…';
      if (info.permission !== 'granted') {
        statusEl.textContent = 'Permission needed — click "Sync now" to grant.';
      } else {
        statusEl.textContent = '';
      }
    }
  });
}

function formatAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return s + 's ago';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  return new Date(ts).toLocaleString();
}

let toastTimer;
function toast(msg = 'Saved ✓') {
  const el = $('savedToast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1500);
}

// ---- Glass effect ----
function applyGlass(g) {
  const s = document.documentElement.style;
  const sidebar = (g.sidebarOpacity ?? 52) / 100;
  const header = (g.headerOpacity ?? 75) / 100;
  const blur = (g.blur ?? 40);
  s.setProperty('--user-sidebar-a', sidebar);
  s.setProperty('--user-header-a', header);
  s.setProperty('--user-blur', blur + 'px');
  $('glassSidebarVal').textContent = Math.round(sidebar * 100) + '%';
  $('glassHeaderVal').textContent = Math.round(header * 100) + '%';
  $('glassBlurVal').textContent = blur + 'px';
}

function applyPopupGlassPreview(g) {
  $('glassPopupVal').textContent = (g.popupOpacity ?? 24) + '%';
  $('glassPopupNavVal').textContent = (g.popupNavOpacity ?? 4) + '%';
  $('glassPopupBlurVal').textContent = (g.popupBlur ?? 46) + 'px';
}

function applyTooltipGlassPreview(g) {
  $('glassTooltipVal').textContent = (g.tooltipOpacity ?? 92) + '%';
  $('glassTooltipBlurVal').textContent = (g.tooltipBlur ?? 16) + 'px';
}

// ---- Custom background image ----
async function loadBgImage() {
  const { settingsBg } = await chrome.storage.local.get('settingsBg');
  const layer = $('bgLayer');
  if (settingsBg) {
    layer.style.backgroundImage = `url("${settingsBg}")`;
    layer.hidden = false;
    document.body.classList.add('has-bg-image');
    $('bgClearBtn').hidden = false;
    $('bgStatus').textContent = 'Background set';
  }
}

function resizeImage(file, maxW = 1920) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxW / img.width);
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      c.getContext('2d').drawImage(img, 0, 0, w, h);
      resolve(c.toDataURL('image/jpeg', 0.7));
    };
    img.src = URL.createObjectURL(file);
  });
}

$('bgPickBtn').addEventListener('click', () => $('bgFileInput').click());
$('bgFileInput').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  $('bgStatus').textContent = 'Processing...';
  try {
    const dataUrl = await resizeImage(file);
    await chrome.storage.local.set({ settingsBg: dataUrl });
    $('bgLayer').style.backgroundImage = `url("${dataUrl}")`;
    $('bgLayer').hidden = false;
    document.body.classList.add('has-bg-image');
    $('bgClearBtn').hidden = false;
    $('bgStatus').textContent = 'Done';
    toast();
  } catch (err) {
    $('bgStatus').textContent = 'Failed: ' + err.message;
  }
  e.target.value = '';
});
$('bgClearBtn').addEventListener('click', async () => {
  await chrome.storage.local.remove('settingsBg');
  $('bgLayer').style.backgroundImage = '';
  $('bgLayer').hidden = true;
  document.body.classList.remove('has-bg-image');
  $('bgClearBtn').hidden = true;
  $('bgStatus').textContent = '';
  toast();
});
loadBgImage();

// ---- Popup background image ----
async function loadPopupBg() {
  const { popupBg } = await chrome.storage.local.get('popupBg');
  if (popupBg) {
    $('popupBgClearBtn').hidden = false;
    $('popupBgStatus').textContent = 'Background set';
  }
}

$('popupBgPickBtn').addEventListener('click', () => $('popupBgFileInput').click());
$('popupBgFileInput').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  $('popupBgStatus').textContent = 'Processing...';
  try {
    const dataUrl = await resizeImage(file, 720);
    await chrome.storage.local.set({ popupBg: dataUrl });
    $('popupBgClearBtn').hidden = false;
    $('popupBgStatus').textContent = 'Done';
    toast();
  } catch (err) {
    $('popupBgStatus').textContent = 'Failed: ' + err.message;
  }
  e.target.value = '';
});
$('popupBgClearBtn').addEventListener('click', async () => {
  await chrome.storage.local.remove('popupBg');
  $('popupBgClearBtn').hidden = true;
  $('popupBgStatus').textContent = '';
  toast();
});
loadPopupBg();

// Surface boot errors visibly — otherwise a silent throw mid-boot leaves half
// the form unrendered (missing API-key inputs, WebDAV pane stays hidden, etc.)
// with no hint why.
boot().catch((err) => {
  console.error('[LinguaFlow options boot failed]', err);
  const banner = document.createElement('div');
  banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;padding:12px 18px;background:#dc2626;color:#fff;font:13px/1.4 ui-monospace,Menlo,monospace;white-space:pre-wrap;box-shadow:0 2px 12px rgba(0,0,0,.35)';
  banner.textContent = '⚠ LinguaFlow Options 初始化失败(部分面板可能缺少控件):\n' +
                       (err?.message || String(err)) + '\n' +
                       (err?.stack ? err.stack.split('\n').slice(0, 3).join('\n') : '');
  document.body.prepend(banner);
});
