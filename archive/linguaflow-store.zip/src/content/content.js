// LinguaFlow content script (classic script, no ES modules).
// - Shows a tooltip with translation when the user selects text.
// - Highlights already-saved vocabulary on the page.

(() => {
  if (window.__linguaflowLoaded) return;
  window.__linguaflowLoaded = true;

  // Keep noisy word-hit diagnostics opt-in. This content script runs on every
  // page, so production console logging makes normal browsing feel broken.
  const DEBUG_WORD_HIT = false;
  const debugLog = (...args) => { if (DEBUG_WORD_HIT) console.debug(...args); };

  const LATIN_LANG_CODES = new Set(['en','fr','de','es','it','pt','vi','id','nl','sv','no','da','fi','pl','ro','cs','sk','hu','tr']);
  // CJK languages — use Intl.Segmenter for word boundaries instead of Latin regex.
  const CJK_LANGS = new Set(['ja','zh','zh-TW','ko']);
  const LEVEL_LABELS = { 1: 'New', 2: 'Familiar', 3: 'Recognized', 4: 'Almost mastered', 5: 'Fully mastered' };
  const KNOWN_LEVEL = 5; // cards at or above this level are not highlighted and skipped in review
  // Common English stop words — skipped in "all-unknown" highlight mode.
  const STOP_WORDS_EN = new Set((
    "a about above across after against all almost along already also although always am among an and another any anyone anything are aren't around as at be became because been before being below between both but by came can cannot can't come could couldn't did didn't do does doesn't doing done don't down during each either else even ever every for from further get gets got had hadn't has hasn't have haven't having he he'd he'll he's her here here's hers herself him himself his how however i i'd i'll i'm i've if in into is isn't it it's its itself just let let's like made make many may me might more most mr mrs much must my myself near never new next no nor not now of off often on once one only or other others our ours ourselves out over own quite rather really said same saw say says see seen she she'd she'll she's should shouldn't since so some someone something sometimes somewhere soon still such take taken than that that's the their theirs them themselves then there there's these they they'd they'll they're they've this those though through thus to together too toward under until up upon us use used very was wasn't way we we'd we'll we're we've well went were weren't what what's when when's where where's which while who who's whom whose why will with within without won't would wouldn't yes yet you you'd you'll you're you've your yours yourself"
  ).split(/\s+/));
  // Japanese particles, copulas, demonstratives, and high-frequency function
  // words. Skipped in unknown-highlight mode so the page isn't drowned in は/が/の.
  const STOP_WORDS_JA = new Set((
    "は が を に で と も や の へ か な よ ね わ さ し て って でも けど まで から より ば ても だけ ほど " +
    "だ です ます ました でした である じゃ では でしょう しょう " +
    "する した して される されて している " +
    "いる いて いた ある あって あった なる なった " +
    "これ それ あれ どれ ここ そこ あそこ この その あの どの " +
    "もの こと ため よう ところ とき ほう " +
    "わたし 私 ぼく 僕 あなた 彼 彼女 " +
    "ん っ ー"
  ).split(/\s+/).filter(Boolean));
  function isJunkToken(s) {
    if (!s) return true;
    const t = s.trim();
    if (/^[\d.,:\-\/+()\s]+$/.test(t)) return true;
    if (!/\s/.test(t) && /\d/.test(t) && /[a-zA-Z]/.test(t)) return true;
    if (t.length > 2 && /^(.)\1+$/i.test(t)) return true;
    return false;
  }

  const segmenterCache = {};
  function getWordSegmenter(lang) {
    if (segmenterCache[lang] !== undefined) return segmenterCache[lang];
    try { segmenterCache[lang] = new Intl.Segmenter(lang, { granularity: 'word' }); }
    catch (e) { segmenterCache[lang] = null; }
    return segmenterCache[lang];
  }

  function normalizeStringArray(value) {
    if (Array.isArray(value)) return value.map(v => String(v).trim()).filter(Boolean);
    if (typeof value === 'string') return value.split(/[,\n]+/).map(v => v.trim()).filter(Boolean);
    if (value && typeof value === 'object') {
      return Object.entries(value)
        .filter(([, enabled]) => !!enabled)
        .map(([key]) => String(key).trim())
        .filter(Boolean);
    }
    return [];
  }

  // Active source languages: primary + extras. Content scripts read raw
  // storage, so normalize legacy/corrupt shapes here too.
  function activeSourceLangs() {
    const arr = [];
    const push = (l) => { if (l && !arr.includes(l)) arr.push(l); };
    push(settings.sourceLang);
    for (const l of normalizeStringArray(settings.extraSourceLangs)) push(l);
    return arr;
  }
  const anyActive = (pred) => activeSourceLangs().some(pred);
  const anyActiveCJK = () => anyActive(l => CJK_LANGS.has(l));
  const anyActiveLatin = () => anyActive(l => LATIN_LANG_CODES.has(l));

  // Page-level language detection — reads <html lang> first (authoritative on
  // well-tagged sites: baidu.com, aliyun.com, wikipedia, etc.), then falls
  // back to scanning the body for kana/hangul/han/latin to disambiguate.
  // Cached on first call; switching SPA routes resets it via the main
  // MutationObserver path if the tab changes location.
  let _pageLangCache = null;
  function pageLanguage() {
    if (_pageLangCache) return _pageLangCache;
    const htmlLang = (document.documentElement?.lang || '').toLowerCase();
    const norm = (v) => (_pageLangCache = v);
    if (htmlLang.startsWith('zh-tw') || htmlLang.startsWith('zh-hant')) return norm('zh-TW');
    if (htmlLang.startsWith('zh')) return norm('zh');
    if (htmlLang.startsWith('ja')) return norm('ja');
    if (htmlLang.startsWith('ko')) return norm('ko');
    if (htmlLang && htmlLang.length >= 2) return norm(htmlLang.slice(0, 2));
    const txt = (document.body?.innerText || '').slice(0, 4000);
    if (/[\u3040-\u309F\u30A0-\u30FF]/.test(txt)) return norm('ja');
    if (/[\u4E00-\u9FFF]/.test(txt)) return norm('zh');
    if (/[\uAC00-\uD7AF]/.test(txt)) return norm('ko');
    return norm('en');
  }

  // Script-based language detection — decides which lang a clicked or selected
  // word should be saved under when multiple source langs are active. Uses
  // page-level language first (LingKuma-style), then context kana, then the
  // user's primary. Fixes the "体验 gets saved as ja" bug on pure-Chinese sites.
  function detectLangOf(word, contextText) {
    const active = activeSourceLangs();
    const primary = settings.sourceLang;
    const ctx = contextText || '';
    if (/[\u3040-\u309F\u30A0-\u30FF]/.test(word)) {       // hiragana or katakana
      return active.includes('ja') ? 'ja' : primary;
    }
    if (/[\u3400-\u4DBF\u4E00-\u9FFF]/.test(word)) {       // pure Han (no kana in word)
      const pageL = pageLanguage();
      // Page-level trumps per-token ambiguity.
      if (pageL === 'ja' && active.includes('ja')) return 'ja';
      if ((pageL === 'zh' || pageL === 'zh-TW') && (active.includes('zh') || active.includes('zh-TW'))) {
        return active.includes(pageL) ? pageL : (active.includes('zh') ? 'zh' : 'zh-TW');
      }
      if (active.includes('zh')) return 'zh';
      if (active.includes('zh-TW')) return 'zh-TW';
      // Last-chance ja: mixed page where a local paragraph has kana.
      if (active.includes('ja') && /[\u3040-\u309F\u30A0-\u30FF]/.test(ctx)) return 'ja';
      if (CJK_LANGS.has(primary)) return primary;
      return primary;
    }
    if (/[\uAC00-\uD7AF]/.test(word)) {                    // hangul
      return active.includes('ko') ? 'ko' : primary;
    }
    if (/[A-Za-z\u00C0-\u024F]/.test(word)) {              // Latin
      if (LATIN_LANG_CODES.has(primary)) return primary;
      return active.find(l => LATIN_LANG_CODES.has(l)) || primary;
    }
    return primary;
  }

  // Should the click handler consume this word (open tooltip + preventDefault)
  // or let it fall through to the page's native handler (e.g. a hyperlink)?
  // Returns false for words whose script doesn't belong to any active source
  // lang — clicking "体验" on a pure-Chinese page (user has en+ja active) must
  // NOT block the link navigation.
  function wordMatchesActiveScript(word, contextText) {
    const active = activeSourceLangs();
    const jaActive = active.includes('ja');
    const zhActive = active.includes('zh') || active.includes('zh-TW');
    const koActive = active.includes('ko');
    const anyLatinActive = active.some(l => LATIN_LANG_CODES.has(l));
    const hasKana   = /[\u3040-\u309F\u30A0-\u30FF]/.test(word);
    const hasHangul = /[\uAC00-\uD7AF]/.test(word);
    const hasHan    = /[\u3400-\u4DBF\u4E00-\u9FFF]/.test(word) && !hasKana;
    const isLatin   = /^[A-Za-z\u00C0-\u024F\u0400-\u04FF\-\u2010\u2011\u2013'\u2018\u2019]+$/.test(word);
    if (hasKana)   return jaActive;
    if (hasHangul) return koActive;
    if (hasHan) {
      const pageL = pageLanguage();
      if (pageL === 'ja')   return jaActive;
      if (pageL === 'zh' || pageL === 'zh-TW') return zhActive;
      // Page level not clearly CJK (or mixed): fall back to context/local kana.
      if (zhActive) return true;
      if (jaActive && /[\u3040-\u309F\u30A0-\u30FF]/.test(contextText || '')) return true;
      return false;
    }
    if (isLatin) return anyLatinActive;
    return anyLatinActive; // mixed alphanum (e.g. "Qwen3.6") — treat as latin-ish
  }
  const TTS_LOCALE = {
    en:'en-US', zh:'zh-CN', 'zh-TW':'zh-TW', ja:'ja-JP', ko:'ko-KR',
    fr:'fr-FR', de:'de-DE', es:'es-ES', it:'it-IT', pt:'pt-PT',
    ru:'ru-RU', ar:'ar-SA', hi:'hi-IN', th:'th-TH', vi:'vi-VN', id:'id-ID'
  };

  let settings = { enabled:true, sourceLang:'en', nativeLang:'zh', showOnSelection:true, hoverMode:false, highlightMode:'unknown', tts:{enabled:true, rate:1} };
  let vocabByWord = new Map();   // lowercased word -> card
  let vocabById   = new Map();
  let knownSet    = new Set();   // lowercased words user has marked known
  let ignoreSet   = new Set();
  let extensionDead = false;     // set when chrome.* throws "context invalidated"

  function isAlive() {
    try { return !!chrome?.runtime?.id; } catch { return false; }
  }
  function markExtensionDead() {
    if (extensionDead) return;
    extensionDead = true;
    console.warn('[LinguaFlow] extension was reloaded; this page is using an orphaned script. Refresh to reconnect.');
    try { showStaleBanner(); } catch {}
  }
  function showStaleBanner() {
    if (document.getElementById('linguaflow-stale-banner')) return;
    const b = document.createElement('div');
    b.id = 'linguaflow-stale-banner';
    b.textContent = 'LinguaFlow was reloaded — refresh this tab (⌘R) to reconnect ·';
    const x = document.createElement('button');
    x.textContent = '×';
    x.onclick = () => b.remove();
    Object.assign(b.style, {
      all: 'initial', position: 'fixed', top: '0', left: '0', right: '0',
      zIndex: '2147483646', padding: '8px 16px', textAlign: 'center',
      background: 'rgba(220, 38, 38, 0.95)', color: '#fff',
      font: '13px/1.3 -apple-system, system-ui, sans-serif',
      boxShadow: '0 2px 6px rgba(0,0,0,0.2)'
    });
    Object.assign(x.style, {
      all: 'initial', marginLeft: '12px', background: 'rgba(255,255,255,0.25)',
      color: '#fff', border: '0', padding: '2px 8px', borderRadius: '4px',
      fontSize: '14px', cursor: 'pointer', fontFamily: 'inherit'
    });
    b.appendChild(x);
    (document.body || document.documentElement).appendChild(b);
  }
  // Try a streaming port connection; fall back to a plain sendMessage if the
  // port dies before any data arrives (iOS / WebKit-based browsers often don't
  // support long-lived ports even when regular sendMessage works).
  function streamTranslate({ text, sentence, from, onUpdate }) {
    return new Promise((resolve) => {
      if (extensionDead || !isAlive()) {
        markExtensionDead();
        fallbackOneShot(text, sentence, from).then(resolve);
        return;
      }
      let port;
      try { port = chrome.runtime.connect({ name: 'lf-translate-stream' }); }
      catch (e) { fallbackOneShot(text, sentence, from).then(resolve); return; }
      let done = false;
      let gotMessage = false;
      const finish = (payload) => {
        if (done) return;
        done = true;
        try { port.disconnect(); } catch {}
        resolve(payload);
      };
      port.onMessage.addListener((msg) => {
        gotMessage = true;
        if (msg.type === 'chunk') {
          try { onUpdate && onUpdate(parsePartialJson(msg.buffer)); } catch {}
        } else if (msg.type === 'complete') {
          finish({ ok: true, ...msg.result });
        } else if (msg.type === 'error') {
          finish({ ok: false, error: msg.message });
        }
      });
      port.onDisconnect.addListener(async () => {
        void chrome.runtime.lastError;
        if (!gotMessage && !done) {
          finish(await fallbackOneShot(text, sentence, from));
        } else {
          finish({ ok: false, error: 'disconnected' });
        }
      });
      try { port.postMessage({ type: 'translate', text, sentence, from }); }
      catch (e) {
        fallbackOneShot(text, sentence, from).then((r) => finish(r));
      }
    });
  }

  async function fallbackOneShot(text, sentence, from) {
    const r = await safeSendMessage({ type: 'translate', text, sentence, from });
    if (r && r.ok) return r;
    // SendMessage also failed (typical on iOS WebKit browsers where MV3
    // service workers are poorly supported). Fetch directly from the content
    // script as a last resort.
    return await directTranslate(text, sentence, from);
  }

  // Anthropic Claude dispatch for mobile fallback (different request schema).
  async function directClaudeTranslate(text, sentence, from, to, s) {
    const key = (s.apiKeys || {}).claude?.trim();
    if (!key) return { ok: false, error: 'Claude API key missing (set in Options)' };
    const model = s.claudeModel || 'claude-3-5-haiku-latest';
    const promptTpl = s.aiPromptOverride ||
      `Analyse the {from} word in its sentence. Reply ONLY with JSON in {to}:
{"translation":"","note":"","pos":"","inflection":"","phrase":"","phraseMeaning":""}`;
    const system = promptTpl.replaceAll('{from}', from).replaceAll('{to}', to) +
      '\nRespond with the JSON object only, no prose before or after.';
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': key,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify({
          model, max_tokens: 400, system,
          messages: [{ role: 'user', content: `WORD: ${text}\nSENTENCE: ${sentence}` }]
        })
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        return { ok: false, error: `claude ${res.status}: ${body.slice(0,150)}` };
      }
      const data = await res.json();
      const content = data?.content?.[0]?.text || '{}';
      let parsed = null;
      try { parsed = JSON.parse(content); }
      catch {
        const mm = content.match(/\{[\s\S]*\}/);
        if (mm) { try { parsed = JSON.parse(mm[0]); } catch {} }
      }
      if (!parsed) return { ok: false, error: 'Claude returned non-JSON' };
      return {
        ok: true,
        translation:   String(parsed.translation || '').trim(),
        pos:           String(parsed.pos || '').trim(),
        inflection:    String(parsed.inflection || '').trim(),
        phrase:        String(parsed.phrase || '').trim(),
        phraseMeaning: String(parsed.phraseMeaning || '').trim(),
        note:          String(parsed.note || '').trim(),
        provider: 'claude-direct', aiContext: true, alternatives: []
      };
    } catch (e) { return { ok: false, error: 'direct-fetch-failed: ' + e.message }; }
  }

  // Fetch translation straight from the content script. Needed on mobile
  // browsers where chrome.runtime messaging to the service worker doesn't work.
  async function directTranslate(text, sentence, overrideFrom) {
    let s = {};
    try {
      const r = await chrome.storage.local.get('settings');
      s = r?.settings || {};
    } catch { s = {}; }
    const provider = s.translator || 'mymemory';
    const from = overrideFrom || s.sourceLang || 'en';
    const to   = s.nativeLang || 'zh';
    const useContext = sentence && s.aiContext !== false &&
      ['deepseek', 'openai', 'qwen', 'gemini', 'claude', 'custom'].includes(provider);

    if (!useContext) {
      // Free fallback — MyMemory doesn't require a key.
      try {
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${from}|${to}`;
        const res = await fetch(url);
        if (!res.ok) return { ok: false, error: `MyMemory ${res.status}` };
        const data = await res.json();
        return {
          ok: true,
          translation: String(data?.responseData?.translatedText || '').trim(),
          provider: 'mymemory-direct',
          alternatives: []
        };
      } catch (e) {
        return { ok: false, error: 'direct-fetch-failed: ' + e.message };
      }
    }

    let endpoint, model, key, extraBody = {};
    const keys = s.apiKeys || {};
    if (provider === 'deepseek') {
      endpoint = 'https://api.deepseek.com/chat/completions';
      model    = s.deepseekModel || 'deepseek-chat';
      key      = keys.deepseek?.trim();
    } else if (provider === 'openai') {
      endpoint = 'https://api.openai.com/v1/chat/completions';
      model    = s.openaiModel || 'gpt-4o-mini';
      key      = keys.openai?.trim();
    } else if (provider === 'qwen') {
      endpoint = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions';
      model    = s.qwenModel || 'qwen-plus';
      key      = keys.qwen?.trim();
    } else if (provider === 'gemini') {
      endpoint = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions';
      model    = s.geminiModel || 'gemini-2.5-flash';
      key      = keys.gemini?.trim();
    } else if (provider === 'claude') {
      // Anthropic native API uses different schema — dispatch separately below.
      return await directClaudeTranslate(text, sentence, from, to, s);
    } else { // custom
      endpoint = (s.customApi?.endpoint || '').trim();
      model    = (s.customApi?.model || '').trim() || 'gpt-4o-mini';
      key      = (s.customApi?.key || '').trim();
      try {
        const raw = s.customApi?.extraBody;
        if (raw) extraBody = raw.trim().startsWith('{')
          ? JSON.parse(raw) : Object.fromEntries(raw.split(/\r?\n/).map(l => {
              const m = l.match(/^\s*([A-Za-z_][\w]*)\s*=\s*(.+?)\s*$/);
              if (!m) return null;
              let v = m[2]; try { v = JSON.parse(v); } catch {}
              return [m[1], v];
            }).filter(Boolean));
      } catch { extraBody = {}; }
    }
    if (!endpoint || !key) {
      return { ok: false, error: `${provider} endpoint/key missing (set in Options)` };
    }

    const promptTpl = s.aiPromptOverride ||
      `Analyse the {from} word in its sentence. Reply ONLY with JSON in {to}, no markdown, no prose:
{"translation":"","note":"","pos":"","inflection":"","phrase":"","phraseMeaning":""}
- translation: word's core meaning in {to}, ≤6 chars (OUTPUT THIS FIRST)
- note: ≤30-char {to} sentence on the word's role/sense here
- pos: n|v|adj|adv|prep|conj|pron|det|interj
- inflection: pl|past|gerund|comparative or ""
- phrase: notable collocation from sentence containing the word, else ""
- phraseMeaning: phrase in {to} (else "")
Be fast.`;
    const system = promptTpl.replaceAll('{from}', from).replaceAll('{to}', to);

    try {
      const body = {
        model,
        messages: [
          { role: 'system', content: system },
          { role: 'user',   content: `WORD: ${text}\nSENTENCE: ${sentence}` }
        ],
        temperature: 0.2,
        response_format: { type: 'json_object' },
        ...extraBody
      };
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        return { ok: false, error: `${provider} ${res.status}: ${body.slice(0, 150)}` };
      }
      const data = await res.json();
      const content = data?.choices?.[0]?.message?.content || '{}';
      let parsed = null;
      try { parsed = JSON.parse(content); }
      catch {
        const m = content.match(/```(?:json)?\s*([\s\S]+?)\s*```/);
        if (m) { try { parsed = JSON.parse(m[1]); } catch {} }
      }
      if (!parsed || typeof parsed !== 'object') {
        return { ok: false, error: 'Invalid JSON from LLM' };
      }
      return {
        ok: true,
        translation:   String(parsed.translation || '').trim(),
        pos:           String(parsed.pos || '').trim(),
        inflection:    String(parsed.inflection || '').trim(),
        phrase:        String(parsed.phrase || '').trim(),
        phraseMeaning: String(parsed.phraseMeaning || '').trim(),
        note:          String(parsed.note || '').trim(),
        provider:      provider + '-direct',
        aiContext:     true,
        alternatives:  []
      };
    } catch (e) {
      return { ok: false, error: 'direct-fetch-failed: ' + e.message };
    }
  }

  async function directSentenceTranslate(sentence, overrideFrom, paragraph, terms) {
    let s = {};
    try { const r = await chrome.storage.local.get('settings'); s = r?.settings || {}; } catch { s = {}; }
    const provider = s.translator || 'mymemory';
    if (!['deepseek', 'openai', 'qwen', 'gemini', 'claude', 'custom'].includes(provider)) {
      return { ok: false, error: 'Sentence translation requires an LLM provider.' };
    }
    const from = overrideFrom || s.sourceLang || 'en';
    const to = s.nativeLang || 'zh';
    const useCtx = s.sentenceContext !== false && paragraph && paragraph.length > sentence.length + 10;
    const termSuffix = terms ? '\n\nUse these known translations for vocabulary consistency: ' + terms : '';
    let system, userMsg;
    if (useCtx) {
      const tpl = s.aiPrompts?.sentenceTranslationContext ||
        'You are given a {from} paragraph for context, and a target sentence marked with【】. Translate ONLY the marked sentence into natural {to}. Return ONLY the translation, no markers, no explanation, no original text.';
      system = tpl.replaceAll('{from}', from).replaceAll('{to}', to) + termSuffix;
      userMsg = paragraph.replace(sentence, '【' + sentence + '】');
    } else {
      const tpl = s.aiPrompts?.sentenceTranslation ||
        'Translate the following {from} sentence into natural {to}. Return ONLY the translation, no explanation, no original text, no quotation marks.';
      system = tpl.replaceAll('{from}', from).replaceAll('{to}', to) + termSuffix;
      userMsg = sentence;
    }
    if (provider === 'claude') {
      const key = (s.apiKeys || {}).claude?.trim();
      if (!key) return { ok: false, error: 'Claude API key missing' };
      const model = s.claudeModel || 'claude-3-5-haiku-latest';
      try {
        const res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
          body: JSON.stringify({ model, max_tokens: 1000, system, messages: [{ role: 'user', content: userMsg }] })
        });
        if (!res.ok) { const b = await res.text().catch(() => ''); return { ok: false, error: `claude ${res.status}: ${b.slice(0,150)}` }; }
        const data = await res.json();
        return { ok: true, translation: (data?.content?.[0]?.text || '').trim() };
      } catch (e) { return { ok: false, error: 'direct-fetch: ' + e.message }; }
    }
    let endpoint, model, key, extraBody = {};
    const keys = s.apiKeys || {};
    if (provider === 'deepseek') { endpoint = 'https://api.deepseek.com/chat/completions'; model = s.deepseekModel || 'deepseek-chat'; key = keys.deepseek?.trim(); }
    else if (provider === 'openai') { endpoint = 'https://api.openai.com/v1/chat/completions'; model = s.openaiModel || 'gpt-4o-mini'; key = keys.openai?.trim(); }
    else if (provider === 'qwen') { endpoint = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions'; model = s.qwenModel || 'qwen-plus'; key = keys.qwen?.trim(); }
    else if (provider === 'gemini') { endpoint = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'; model = s.geminiModel || 'gemini-2.5-flash'; key = keys.gemini?.trim(); }
    else {
      endpoint = (s.customApi?.endpoint || '').trim(); model = (s.customApi?.model || '').trim() || 'gpt-4o-mini'; key = (s.customApi?.key || '').trim();
      try { const raw = s.customApi?.extraBody; if (raw) extraBody = raw.trim().startsWith('{') ? JSON.parse(raw) : Object.fromEntries(raw.split(/\r?\n/).map(l => { const m = l.match(/^\s*([A-Za-z_][\w]*)\s*=\s*(.+?)\s*$/); if (!m) return null; let v = m[2]; try { v = JSON.parse(v); } catch {} return [m[1], v]; }).filter(Boolean)); } catch { extraBody = {}; }
    }
    if (!endpoint || !key) return { ok: false, error: `${provider} endpoint/key missing` };
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages: [{ role: 'system', content: system }, { role: 'user', content: userMsg }], temperature: 0.3, ...extraBody })
      });
      if (!res.ok) { const b = await res.text().catch(() => ''); return { ok: false, error: `${res.status}: ${b.slice(0,150)}` }; }
      const data = await res.json();
      return { ok: true, translation: (data?.choices?.[0]?.message?.content || '').trim() };
    } catch (e) { return { ok: false, error: 'direct-fetch: ' + e.message }; }
  }

  // Parse fields out of an in-progress JSON buffer (tolerates unclosed strings).
  function parsePartialJson(buffer) {
    const pull = (k) => {
      const rx = new RegExp(`"${k}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)(?:"|$)`);
      const m = buffer.match(rx);
      if (!m) return '';
      return m[1].replace(/\\"/g, '"').replace(/\\n/g, '\n').replace(/\\\\/g, '\\');
    };
    return {
      translation:   pull('translation'),
      note:          pull('note'),
      pos:           pull('pos'),
      inflection:    pull('inflection'),
      phrase:        pull('phrase'),
      phraseMeaning: pull('phraseMeaning'),
      aiContext: true
    };
  }

  // ============================================================
  // Local data layer — all operations write to chrome.storage directly.
  // Mirrors what the service worker does, so this path works even on
  // platforms where MV3 SWs don't run (iOS Gear / WebKit).
  // Both SW and content script listen to storage changes; `lastSyncAt`
  // is used as a coordination timestamp so only one side actually
  // hits the remote for each change.
  // ============================================================

  function _cardId(word, lang) {
    const norm = word.trim().toLowerCase();
    const b64 = btoa(unescape(encodeURIComponent(norm))).replace(/[=+/]/g, '');
    return `w_${lang}_${b64.slice(0, 24)}`;
  }

  function _newCard({ word, translation, lang, context, source }) {
    const now = Date.now();
    return {
      id: _cardId(word, lang),
      word: word.trim(),
      translation: translation || '',
      lang, context: context || '', source: source || '',
      createdAt: now, level: 1,
      stability: 0, difficulty: 0, state: 'new',
      due: now, lastReview: null, reps: 0, lapses: 0, interval: 0,
      _updatedAt: now
    };
  }

  async function localSaveCard({ word, translation, context, source, pos, inflection, phrase, phraseMeaning, note }) {
    if (!isAlive()) { markExtensionDead(); return null; }
    try {
      const { vocabulary = {} } = await chrome.storage.local.get('vocabulary');
      // With multi-lang active, pick the card's lang by script. Context helps
      // disambiguate pure-Han words (zh vs ja) when both might be active.
      const lang = detectLangOf(word, context);
      const fresh = _newCard({ word, translation, lang, context, source });
      const existing = vocabulary[fresh.id];
      // Merge AI-context fields (pos/inflection/phrase/phraseMeaning/note) so the
      // second tap on the same word can render the full tooltip immediately.
      const ai = { pos, inflection, phrase, phraseMeaning, note };
      const card = existing ? {
        ...existing,
        translation: translation || existing.translation,
        context: context || existing.context,
        source: source || existing.source,
        pos: pos || existing.pos,
        inflection: inflection || existing.inflection,
        phrase: phrase || existing.phrase,
        phraseMeaning: phraseMeaning || existing.phraseMeaning,
        note: note || existing.note,
        _updatedAt: Date.now()
      } : { ...fresh, ...ai };
      vocabulary[card.id] = card;
      await safeStorageSet({ vocabulary });
      return card;
    } catch (e) {
      console.warn('[LinguaFlow] localSaveCard failed:', e);
      return null;
    }
  }

  async function localSetLevel(id, level) {
    if (!isAlive()) { markExtensionDead(); return null; }
    try {
      const { vocabulary = {} } = await chrome.storage.local.get('vocabulary');
      const card = vocabulary[id];
      if (!card) return null;
      const previousLevel = card.level || 1;
      const nextLevel = Math.max(1, Math.min(5, Number(level) || 1));
      const now = Date.now();
      card.level = nextLevel;
      card._updatedAt = now;
      if (card.level >= KNOWN_LEVEL) {
        card.state = 'review';
        card.due = now + 10 * 365 * 24 * 60 * 60 * 1000;
      } else if (previousLevel >= KNOWN_LEVEL || !card.due || card.due > now + 365 * 24 * 60 * 60 * 1000) {
        card.due = now;
      }
      await safeStorageSet({ vocabulary });
      return card;
    } catch (e) { return null; }
  }

  async function localSaveSentence({ sentence, translation, context, source }) {
    if (!isAlive()) { markExtensionDead(); return null; }
    try {
      const lang = detectLangOf(sentence);
      const now = Date.now();
      // Hash-based id so the same sentence doesn't get duplicated.
      const h = btoa(unescape(encodeURIComponent(sentence.trim().toLowerCase())))
        .replace(/[=+/]/g, '').slice(0, 32);
      const id = `s_${lang}_${h}`;
      const { vocabulary = {} } = await chrome.storage.local.get('vocabulary');
      const existing = vocabulary[id];
      const card = existing ? { ...existing, translation: translation || existing.translation,
        _updatedAt: now } : {
        id, type: 'sentence',
        word: sentence.trim(),  // displayed on both wordlist and review front
        sentence: sentence.trim(),
        translation: translation || '',
        lang, context: context || '', source: source || '',
        createdAt: now, _updatedAt: now, level: 1,
        stability: 0, difficulty: 0, state: 'new',
        due: now, lastReview: null, reps: 0, lapses: 0, interval: 0
      };
      vocabulary[id] = card;
      await safeStorageSet({ vocabulary });
      return card;
    } catch (e) {
      console.warn('[LinguaFlow] localSaveSentence failed:', e);
      return null;
    }
  }

  async function localDeleteCard(id) {
    if (!isAlive()) { markExtensionDead(); return false; }
    try {
      const { vocabulary = {} } = await chrome.storage.local.get('vocabulary');
      if (!vocabulary[id]) return false;
      delete vocabulary[id];
      await safeStorageSet({ vocabulary });
      return true;
    } catch (e) { return false; }
  }

  async function localMarkKnown(word) {
    if (!isAlive()) { markExtensionDead(); return false; }
    try {
      const { knownWords = {} } = await chrome.storage.local.get('knownWords');
      const lang = detectLangOf(word);
      if (!knownWords[lang]) knownWords[lang] = {};
      knownWords[lang][word.trim().toLowerCase()] = Date.now();
      await safeStorageSet({ knownWords });
      return true;
    } catch (e) { return false; }
  }

  // ---- WebDAV sync from content script ----
  // Mirrors sync.js merge logic so iOS (Gear Browser, no SW) gets full sync.
  const _DEVICE_ONLY_KEYS = new Set(['syncBackend', 'webdav', 'gist', 'autoSync', 'syncScope']);
  const _SECRET_KEYS = new Set(['apiKeys', 'customApi']);

  function _mergeVocab(local, remote) {
    const out = { ...(local || {}) };
    const t = c => Math.max(c?.lastReview || 0, c?.createdAt || 0, c?._updatedAt || 0);
    for (const [id, rc] of Object.entries(remote || {})) {
      if (!out[id] || t(rc) > t(out[id])) out[id] = rc;
    }
    return out;
  }

  function _stripForSync(settings, scope) {
    const out = { ...settings };
    for (const k of _DEVICE_ONLY_KEYS) delete out[k];
    if (scope === 'no-keys') {
      delete out.apiKeys;
      delete out.customApi;
      if (Array.isArray(out.customApiProfiles))
        out.customApiProfiles = out.customApiProfiles.map(p => ({ ...p, apiKey: '' }));
    }
    return out;
  }

  function _mergeSettingsInto(local, remote, remoteTs, scope) {
    const merged = { ...local };
    for (const [k, v] of Object.entries(remote)) {
      if (_DEVICE_ONLY_KEYS.has(k)) continue;
      if (scope === 'no-keys' && _SECRET_KEYS.has(k)) continue;
      if (scope === 'no-keys' && k === 'customApiProfiles' && Array.isArray(v)) {
        const lp = Array.isArray(local.customApiProfiles) ? local.customApiProfiles : [];
        merged.customApiProfiles = v.map(rp => {
          const match = lp.find(p => p.id === rp.id);
          return { ...rp, apiKey: match?.apiKey || rp.apiKey || '' };
        });
        continue;
      }
      merged[k] = v;
    }
    merged._settingsUpdatedAt = remoteTs;
    return merged;
  }

  let _syncing = false;
  const _cardTime = c => Math.max(c?.lastReview || 0, c?.createdAt || 0, c?._updatedAt || 0);

  async function localWebdavSync() {
    if (_syncing) return { skipped: true, reason: 'in-flight' };
    _syncing = true;
    try {
      const r = await chrome.storage.local.get(['settings', 'lastSyncAt', 'vocabulary', 'settingsBg', 'popupBg']);
      const s = r.settings || {};
      if (Date.now() - (r.lastSyncAt || 0) < 15000) return { skipped: true, reason: 'recent-sync' };
      if (s.syncBackend !== 'webdav' || !s.autoSync) return { skipped: true, reason: 'off' };
      const w = s.webdav || {};
      if (!w.url || !w.user || !w.pass) return { skipped: true, reason: 'no-creds' };

      const scope = s.syncScope || 'full';
      const base = w.url.trim().replace(/\/+$/, '');
      const fileUrl = base + '/linguaflow-vocab.json';
      const auth = 'Basic ' + btoa(unescape(encodeURIComponent(`${w.user}:${w.pass}`)));
      const headers = { 'Authorization': auth };

      // GET remote
      let remoteFile = null;
      try {
        const res = await fetch(fileUrl, { method: 'GET', headers });
        if (res.status === 404) remoteFile = null;
        else if (!res.ok) return { skipped: true, reason: `GET ${res.status}` };
        else {
          const text = await res.text();
          try { remoteFile = text ? JSON.parse(text) : null; } catch {}
        }
      } catch (e) { return { skipped: true, reason: 'get-failed' }; }

      // Merge vocabulary
      const localVocab = r.vocabulary || {};
      const remoteVocab = remoteFile?.vocabulary || {};
      const merged = _mergeVocab(localVocab, remoteVocab);
      const now = Date.now();

      const remoteSettings = remoteFile?.settings || null;
      const remoteTs = remoteFile?._settingsUpdatedAt || 0;
      const localTs = s._settingsUpdatedAt || 0;

      // Skip PUT if local has nothing new to push
      let needsPut = !remoteFile;
      if (!needsPut && Object.keys(merged).length > Object.keys(remoteVocab).length) needsPut = true;
      if (!needsPut) {
        for (const [id, lc] of Object.entries(localVocab)) {
          const rc = remoteVocab[id];
          if (rc && _cardTime(lc) > _cardTime(rc)) { needsPut = true; break; }
        }
      }
      if (!needsPut && scope !== 'vocab-only' && localTs > remoteTs) needsPut = true;

      if (needsPut) {
        const payload = { version: 1, syncedAt: now, vocabulary: merged };

        if (scope !== 'vocab-only') {
          let mergedSettings;
          if (remoteTs > localTs && remoteSettings) {
            mergedSettings = _mergeSettingsInto(s, remoteSettings, remoteTs, scope);
          } else {
            mergedSettings = s;
          }
          payload.settings = _stripForSync(mergedSettings, scope);
          payload._settingsUpdatedAt = Math.max(localTs, remoteTs);

          const remoteNewer = remoteTs > localTs;
          const remoteBg = remoteFile?.settingsBg ?? null;
          const remotePopupBg = remoteFile?.popupBg ?? null;
          payload.settingsBg = remoteNewer ? (remoteBg ?? r.settingsBg ?? null) : (r.settingsBg ?? remoteBg ?? null);
          payload.popupBg = remoteNewer ? (remotePopupBg ?? r.popupBg ?? null) : (r.popupBg ?? remotePopupBg ?? null);
        } else if (remoteFile?.settings) {
          payload.settings = remoteFile.settings;
          payload._settingsUpdatedAt = remoteTs;
          if (remoteFile.settingsBg) payload.settingsBg = remoteFile.settingsBg;
          if (remoteFile.popupBg) payload.popupBg = remoteFile.popupBg;
        }

        const body = JSON.stringify(payload, null, 2);
        const putHdrs = { ...headers, 'Content-Type': 'application/json; charset=utf-8' };
        try {
          let res = await fetch(fileUrl, { method: 'PUT', headers: putHdrs, body });
          if (res.status === 404 || res.status === 409) {
            try { await fetch(base, { method: 'MKCOL', headers }); } catch {}
            res = await fetch(fileUrl, { method: 'PUT', headers: putHdrs, body });
          }
          if (!res.ok) return { skipped: true, reason: `PUT ${res.status}` };
        } catch (e) { return { skipped: true, reason: 'put-failed' }; }
      }

      // Update local storage
      const localPatch = { vocabulary: merged, lastSyncAt: now };
      if (scope !== 'vocab-only' && remoteTs > localTs && remoteSettings) {
        localPatch.settings = _mergeSettingsInto(s, remoteSettings, remoteTs, scope);
        if (remoteFile.settingsBg) localPatch.settingsBg = remoteFile.settingsBg;
        if (remoteFile.popupBg) localPatch.popupBg = remoteFile.popupBg;
      }
      await safeStorageSet(localPatch);
      return { ok: true, at: now };
    } finally { _syncing = false; }
  }

  // ---- GitHub Gist sync from content script ----

  async function localGistSync() {
    if (_syncing) return { skipped: true, reason: 'in-flight' };
    _syncing = true;
    try {
      const r = await chrome.storage.local.get(['settings', 'lastSyncAt', 'vocabulary', 'settingsBg', 'popupBg']);
      const s = r.settings || {};
      if (Date.now() - (r.lastSyncAt || 0) < 15000) return { skipped: true, reason: 'recent-sync' };
      if (s.syncBackend !== 'gist' || !s.autoSync) return { skipped: true, reason: 'off' };
      const g = s.gist || {};
      if (!g.token) return { skipped: true, reason: 'no-token' };

      const scope = s.syncScope || 'full';
      const gistHdrs = {
        'Authorization': 'Bearer ' + g.token,
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28'
      };
      const GIST_API = 'https://api.github.com/gists';

      // GET remote
      let remoteFile = null;
      if (g.id) {
        try {
          const res = await fetch(`${GIST_API}/${g.id}`, { headers: gistHdrs });
          if (res.status === 404) remoteFile = null;
          else if (res.status === 401) return { skipped: true, reason: 'auth-failed' };
          else if (!res.ok) return { skipped: true, reason: `GET ${res.status}` };
          else {
            const gist = await res.json();
            const f = gist.files?.['linguaflow-vocab.json'];
            let raw = f?.content;
            if (f?.truncated && f?.raw_url) {
              try { raw = await (await fetch(f.raw_url, { headers: gistHdrs })).text(); } catch {}
            }
            try { remoteFile = raw ? JSON.parse(raw) : null; } catch {}
          }
        } catch (e) { return { skipped: true, reason: 'get-failed' }; }
      }

      // Merge vocabulary
      const localVocab = r.vocabulary || {};
      const remoteVocab = remoteFile?.vocabulary || {};
      const merged = _mergeVocab(localVocab, remoteVocab);
      const now = Date.now();

      const remoteSettings = remoteFile?.settings || null;
      const remoteTs = remoteFile?._settingsUpdatedAt || 0;
      const localTs = s._settingsUpdatedAt || 0;

      // Skip PUT if local has nothing new
      let needsPut = !g.id || !remoteFile;
      if (!needsPut && Object.keys(merged).length > Object.keys(remoteVocab).length) needsPut = true;
      if (!needsPut) {
        for (const [id, lc] of Object.entries(localVocab)) {
          const rc = remoteVocab[id];
          if (rc && _cardTime(lc) > _cardTime(rc)) { needsPut = true; break; }
        }
      }
      if (!needsPut && scope !== 'vocab-only' && localTs > remoteTs) needsPut = true;

      if (needsPut) {
        const payload = { version: 1, syncedAt: now, vocabulary: merged };

        if (scope !== 'vocab-only') {
          let mergedSettings;
          if (remoteTs > localTs && remoteSettings) {
            mergedSettings = _mergeSettingsInto(s, remoteSettings, remoteTs, scope);
          } else {
            mergedSettings = s;
          }
          payload.settings = _stripForSync(mergedSettings, scope);
          payload._settingsUpdatedAt = Math.max(localTs, remoteTs);
          const remoteNewer = remoteTs > localTs;
          payload.settingsBg = remoteNewer ? (remoteFile?.settingsBg ?? r.settingsBg ?? null) : (r.settingsBg ?? remoteFile?.settingsBg ?? null);
          payload.popupBg = remoteNewer ? (remoteFile?.popupBg ?? r.popupBg ?? null) : (r.popupBg ?? remoteFile?.popupBg ?? null);
        } else if (remoteFile?.settings) {
          payload.settings = remoteFile.settings;
          payload._settingsUpdatedAt = remoteTs;
          if (remoteFile.settingsBg) payload.settingsBg = remoteFile.settingsBg;
          if (remoteFile.popupBg) payload.popupBg = remoteFile.popupBg;
        }

        const fileContent = JSON.stringify(payload, null, 2);
        const body = JSON.stringify({ files: { 'linguaflow-vocab.json': { content: fileContent } } });

        try {
          let gistId = g.id;
          if (gistId) {
            const res = await fetch(`${GIST_API}/${gistId}`, {
              method: 'PATCH', headers: { ...gistHdrs, 'Content-Type': 'application/json' }, body
            });
            if (res.status === 404) gistId = null;
            else if (!res.ok) return { skipped: true, reason: `PATCH ${res.status}` };
          }
          if (!gistId) {
            const createBody = JSON.stringify({
              description: 'LinguaFlow vocabulary sync', public: false,
              files: { 'linguaflow-vocab.json': { content: fileContent } }
            });
            const res = await fetch(GIST_API, {
              method: 'POST', headers: { ...gistHdrs, 'Content-Type': 'application/json' }, body: createBody
            });
            if (!res.ok) return { skipped: true, reason: `POST ${res.status}` };
            const created = await res.json();
            const newSettings = { ...s, gist: { ...g, id: created.id } };
            await safeStorageSet({ settings: newSettings });
          }
        } catch (e) { return { skipped: true, reason: 'put-failed' }; }
      }

      // Update local storage
      const localPatch = { vocabulary: merged, lastSyncAt: now };
      if (scope !== 'vocab-only' && remoteTs > localTs && remoteSettings) {
        localPatch.settings = _mergeSettingsInto(s, remoteSettings, remoteTs, scope);
        if (remoteFile.settingsBg) localPatch.settingsBg = remoteFile.settingsBg;
        if (remoteFile.popupBg) localPatch.popupBg = remoteFile.popupBg;
      }
      await safeStorageSet(localPatch);
      return { ok: true, at: now };
    } finally { _syncing = false; }
  }

  let _autoSyncTimer = null;
  function scheduleLocalAutoSync() {
    if (_autoSyncTimer) clearTimeout(_autoSyncTimer);
    const delay = 15000 + Math.random() * 5000;
    _autoSyncTimer = setTimeout(async () => {
      _autoSyncTimer = null;
      const { settings: st = {} } = await chrome.storage.local.get('settings');
      if (st.syncBackend === 'gist') localGistSync();
      else localWebdavSync();
    }, delay);
  }

  async function safeSendMessage(msg) {
    if (extensionDead || !isAlive()) { markExtensionDead(); return null; }
    try {
      return await chrome.runtime.sendMessage(msg);
    } catch (e) {
      if (String(e?.message || e).includes('Extension context invalidated') ||
          String(e?.message || e).includes('message port closed')) {
        markExtensionDead();
        return null;
      }
      throw e;
    }
  }

  async function safeStorageSet(data) {
    try { await chrome.storage.local.set(data); return true; }
    catch (e) {
      if (e.message?.includes('context invalidated')) { markExtensionDead(); return false; }
      throw e;
    }
  }

  async function loadState() {
    if (!isAlive()) { markExtensionDead(); return; }
    let res;
    try {
      res = await chrome.storage.local.get(['settings', 'vocabulary', 'knownWords']);
    } catch (e) { markExtensionDead(); return; }
    const { settings: s, vocabulary, knownWords } = res;
    if (s) settings = { ...settings, ...s, tts: { ...settings.tts, ...(s.tts||{}) } };
    settings.extraSourceLangs = normalizeStringArray(settings.extraSourceLangs);
    settings.ignoreList = normalizeStringArray(settings.ignoreList);
    vocabByWord.clear(); vocabById.clear();
    const active = new Set(activeSourceLangs());
    if (vocabulary) {
      for (const card of Object.values(vocabulary)) {
        if (active.has(card.lang)) {
          vocabByWord.set(card.word.toLowerCase(), card);
          vocabById.set(card.id, card);
        }
      }
    }
    knownSet = new Set();
    if (knownWords) {
      for (const lang of active) {
        for (const w of Object.keys(knownWords[lang] || {})) knownSet.add(w);
      }
    }
    ignoreSet = new Set(normalizeStringArray(settings.ignoreList).flatMap(w => w.toLowerCase().split(/\s+/)).filter(Boolean));
  }

  // Smart storage listener: only full re-highlight when settings change.
  // For vocab/known changes we do targeted DOM updates to avoid page flicker.
  try { chrome.storage.onChanged.addListener((changes, area) => {
    if (!isAlive()) { markExtensionDead(); return; }
    if (area !== 'local') return;

    if (changes.settings) {
      const oldLang = settings.sourceLang;
      const oldExtras = normalizeStringArray(settings.extraSourceLangs).join(',');
      const oldMode = settings.highlightMode;
      const oldEnabled = settings.enabled !== false;
      const oldIgnore = normalizeStringArray(settings.ignoreList).join('\0');
      loadState().then(() => {
        updateTooltipCSS();
        const newEnabled = settings.enabled !== false;
        if (oldEnabled && !newEnabled) {
          removeHighlights();
          hideTip();
          removeBionic();
          return;
        }
        if (!oldEnabled && newEnabled) {
          scheduleHighlight();
          applyBionic();
          return;
        }
        // Bionic toggle
        if (settings.bionicReading) applyBionic(); else removeBionic();
        const newExtras = normalizeStringArray(settings.extraSourceLangs).join(',');
        const newIgnore = normalizeStringArray(settings.ignoreList).join('\0');
        if (oldLang !== settings.sourceLang || oldMode !== settings.highlightMode ||
            oldExtras !== newExtras || oldIgnore !== newIgnore) {
          removeHighlights();
          scheduleHighlight();
        }
        // Re-attach YouTube caption observer in case its toggle changed.
        attachCaptionObserver();
      });
      if (!changes.lastSyncAt) scheduleLocalAutoSync();
      return;
    }

    if (changes.vocabulary) handleVocabChange(changes.vocabulary);
    if (changes.knownWords) handleKnownChange(changes.knownWords);
    // Trigger coordinated auto-sync when data actually changes (not on our
    // own sync write — those bundle lastSyncAt, which we ignore here).
    if ((changes.vocabulary || changes.knownWords) && !changes.lastSyncAt) {
      scheduleLocalAutoSync();
    }
  }); } catch (e) { markExtensionDead(); }

  function handleVocabChange(change) {
    const active = new Set(activeSourceLangs());
    const newVocab = change.newValue || {};
    const oldVocab = change.oldValue || {};
    // Rebuild maps
    vocabByWord.clear(); vocabById.clear();
    for (const card of Object.values(newVocab)) {
      if (active.has(card.lang)) {
        vocabByWord.set(card.word.toLowerCase(), card);
        vocabById.set(card.id, card);
      }
    }
    const touched = new Set();
    for (const [id, c] of Object.entries(newVocab)) {
      if (!active.has(c.lang)) continue;
      const old = oldVocab[id];
      if (!old || old.level !== c.level || old.translation !== c.translation) {
        touched.add(c.word.toLowerCase());
      }
    }
    for (const [id, c] of Object.entries(oldVocab)) {
      if (!newVocab[id] && active.has(c.lang)) touched.add(c.word.toLowerCase());
    }
    touched.forEach(w => updateSpansForWord(w));
  }

  function handleKnownChange(change) {
    const active = activeSourceLangs();
    const newKnownAll = change.newValue || {};
    const oldKnownAll = change.oldValue || {};
    const union = (all) => { const s = new Set(); for (const l of active) for (const w of Object.keys(all[l] || {})) s.add(w); return s; };
    const newUnion = union(newKnownAll);
    const oldUnion = union(oldKnownAll);
    knownSet = newUnion;
    const touched = new Set();
    for (const w of newUnion) if (!oldUnion.has(w)) touched.add(w);
    for (const w of oldUnion) if (!newUnion.has(w)) touched.add(w);
    touched.forEach(w => updateSpansForWord(w));
  }

  const normHyphen = (s) => s.replace(/[‐‑–]/g, '-').replace(/['']/g, "'");

  function isWordIgnored(w) {
    if (ignoreSet.has(w)) return true;
    const h = normHyphen(w);
    if (ignoreSet.has(h)) return true;
    if (h.length < 2) return false;
    if (h.endsWith("'s") || h.endsWith("’s")) {
      const base = h.replace(/['']s$/, '');
      if (ignoreSet.has(base)) return true;
    }
    if (h.endsWith('ies')) {
      if (ignoreSet.has(h.slice(0, -3) + 'y')) return true;
    } else if (h.endsWith('y')) {
      if (ignoreSet.has(h.slice(0, -1) + 'ies')) return true;
    }
    if (h.endsWith('ves')) {
      const stem = h.slice(0, -3);
      if (ignoreSet.has(stem + 'f') || ignoreSet.has(stem + 'fe')) return true;
    } else if (h.endsWith('f')) {
      if (ignoreSet.has(h.slice(0, -1) + 'ves')) return true;
    } else if (h.endsWith('fe')) {
      if (ignoreSet.has(h.slice(0, -2) + 'ves')) return true;
    }
    if (h.endsWith('es')) {
      const stem = h.slice(0, -2);
      if (ignoreSet.has(stem)) return true;
      if (ignoreSet.has(stem + 'e')) return true;
    } else if (h.endsWith('s') && !h.endsWith('ss')) {
      if (ignoreSet.has(h.slice(0, -1))) return true;
    }
    if (!h.endsWith('s')) {
      if (ignoreSet.has(h + 's') || ignoreSet.has(h + 'es')) return true;
      if (h.endsWith('y') && ignoreSet.has(h.slice(0, -1) + 'ies')) return true;
      if ((h.endsWith('f') || h.endsWith('fe')) &&
          ignoreSet.has(h.replace(/fe?$/, 'ves'))) return true;
    }
    return false;
  }

  function updateSpansForWord(wordLower) {
    const wl = normHyphen(wordLower);
    const card = vocabByWord.get(wordLower) || vocabByWord.get(wl);
    const isKnownMap = knownSet.has(wordLower) || knownSet.has(wl);
    const isMastered = card && (card.level || 1) >= KNOWN_LEVEL;
    const isIgnored = isWordIgnored(wordLower);
    const compParts = wl.includes('-') ? new Set(wl.split('-')) : null;
    const spans = document.querySelectorAll('.linguaflow-highlight');
    let found = false;
    for (const span of spans) {
      const spanWord = normHyphen(span.dataset.lfWord?.toLowerCase() || span.textContent.toLowerCase());
      if (spanWord !== wl && !(compParts && compParts.has(spanWord))) continue;
      found = true;
      if (isIgnored || isKnownMap || isMastered) {
        const parent = span.parentNode;
        if (parent) {
          parent.replaceChild(document.createTextNode(span.textContent), span);
          parent.normalize();
        }
      } else if (card) {
        span.className = `linguaflow-highlight linguaflow-level-${card.level || 1}`;
        span.dataset.lfId = card.id;
      } else {
        span.className = 'linguaflow-highlight linguaflow-unknown';
        delete span.dataset.lfId;
      }
    }
    if (!found && !isIgnored && !isKnownMap && !isMastered) {
      scheduleHighlight();
    }
  }

  // ---- Shadow-DOM tooltip ----
  const host = document.createElement('div');
  host.id = 'linguaflow-host';
  host.style.cssText = 'all: initial; position: fixed; top: 0; left: 0; z-index: 2147483647;';
  const shadow = host.attachShadow({ mode: 'closed' });
  const style = document.createElement('style');
  function tooltipCSS() {
    const g = settings.glass || {};
    const a = (g.tooltipOpacity ?? 92) / 100;
    const blur = g.tooltipBlur ?? 16;
    return `
    :host { all: initial; }
    .tooltip {
      position: fixed; pointer-events: none;
      max-width: 380px; min-width: 238px;
      background: rgba(255, 255, 255, ${a}); color: #14201f;
      border: 1px solid #dfe7e4; border-radius: 8px;
      box-shadow: 0 16px 42px rgba(15,32,31,0.18);
      padding: 12px 14px;
      font: 14px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, "PingFang SC", "Hiragino Sans GB", sans-serif;
      opacity: 0; transform: translateY(4px);
      transition: opacity .12s ease, transform .12s ease;
      -webkit-backdrop-filter: blur(${blur}px) saturate(150%);
      backdrop-filter: blur(${blur}px) saturate(150%);
    }
    .tooltip.show { opacity: 1; transform: translateY(0); pointer-events: auto; }
    .head { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; cursor: grab; }
    .head:active { cursor: grabbing; }
    .tooltip.dragging { transition: none; user-select: none; }
    .head .word { font-weight: 760; font-size: 18px; flex: 1; word-break: break-word; }
    .head .iconbtn {
      width: 28px; height: 28px; background: #eef5f3; border: 1px solid #dfe7e4;
      cursor: pointer; font-size: 13px; padding: 0; border-radius: 8px;
      color: #66736f; font-family: inherit;
    }
    .head .iconbtn:hover { background: rgba(15,118,110,.10); border-color: #0f766e; color: #14201f; }
    .chip {
      font-size: 10px; padding: 2px 7px; border-radius: 8px;
      background: #eef5f3; color: #66736f; text-transform: uppercase; letter-spacing: 0;
    }
    .tags { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px; }
    .tag {
      font-size: 10px; padding: 2px 7px; border-radius: 6px;
      background: #eef5f3; color: #374151;
    }
    .tag.pos { color: #0f766e; background: rgba(15,118,110,.10); }
    .card {
      padding: 9px 11px; border-radius: 8px; margin-bottom: 6px;
      font-size: 14px; line-height: 1.45; word-break: break-word;
    }
    .card.dict { background: #eef5f3; color: #14201f; font-weight: 620; }
    .card.note {
      background: rgba(251,146,60,.16);
      border-left: 3px solid #fb923c;
      color: #7c2d12; font-size: 13px;
    }
    .card.etym {
      background: rgba(16,185,129,.12);
      border-left: 3px solid #10b981;
      color: #065f46; font-size: 12px; font-style: italic;
    }
    .card.etym::before { content: '🌳 '; }
    .card.alt2 {
      background: rgba(139,92,246,.12);
      border-left: 3px solid #8b5cf6;
      color: #4c1d95; font-size: 12px;
    }
    .card.alt2::before { content: '🔍 '; }
    .card.sent {
      background: rgba(59,130,246,.12);
      border-left: 3px solid #3b82f6;
      color: #1e3a5f; font-size: 13px; font-weight: 500;
    }
    .card.sent::before { content: '📖 '; }
    .sent-orig { font-size: 12px; opacity: 0.7; margin-bottom: 5px; font-style: italic; }
    .alts { font-size: 12px; color: #6b7280; margin-bottom: 8px; }
    .err { font-size: 11px; color: #dc2626; margin-top: 4px; }
    .lvlbar {
      display: flex; justify-content: center; align-items: center;
      gap: 6px; margin-top: 8px;
    }
    .lvlbar button {
      width: 32px; height: 32px; border-radius: 8px;
      border: 1px solid #dfe7e4; background: rgba(255, 255, 255, ${Math.min(1, a + 0.08)}); color: #14201f;
      font-size: 13px; cursor: pointer; padding: 0;
      font-family: inherit; display: inline-flex; align-items: center; justify-content: center;
      transition: background .12s, transform .08s;
    }
    .lvlbar button:hover { background: #eef5f3; transform: translateY(-1px); }
    .lvlbar button.x { color: #9ca3af; font-size: 15px; }
    .lvlbar button.v { color: #10b981; border-color: rgba(16,185,129,.4); }
    .lvlbar button.lvl[data-lvl="1"] { background: rgba(251,191,36,.32); }
    .lvlbar button.lvl[data-lvl="2"] { background: rgba(251,191,36,.18); }
    .lvlbar button.lvl[data-lvl="3"] { background: rgba(156,163,175,.28); color: #4b5563; }
    .lvlbar button.lvl[data-lvl="4"] { background: transparent; text-decoration: underline; }
    .lvlbar button.lvl.active { outline: 2px solid #0f766e; font-weight: 760; }
    .meta { font-size: 10px; color: #9ca3af; margin-top: 6px; display: flex; justify-content: space-between; }
    @media (prefers-color-scheme: dark) {
      .tooltip { background: rgba(31, 41, 55, ${a}); color: #f9fafb; border-color: #374151; }
      .head .iconbtn { background: #374151; border-color: #4b5563; color: #9ca3af; }
      .head .iconbtn:hover { background: #374151; color: #f9fafb; border-color: #2dd4bf; }
      .chip, .tag { background: #374151; color: #d1d5db; }
      .tag.pos { color: #5eead4; background: rgba(45,212,191,.16); }
      .card.dict { background: #374151; color: #f9fafb; }
      .card.note { background: rgba(251,146,60,.15); color: #fed7aa; }
      .card.etym { background: rgba(16,185,129,.15); color: #a7f3d0; }
      .card.alt2 { background: rgba(139,92,246,.18); color: #ddd6fe; }
      .card.sent { background: rgba(59,130,246,.18); color: #bfdbfe; }
      .lvlbar button { background: rgba(55, 65, 81, ${Math.min(1, a + 0.08)}); border-color: #4b5563; color: #f9fafb; }
      .lvlbar button:hover { background: #4b5563; }
      .alts { color: #9ca3af; }
    }
    `;
  }
  style.textContent = tooltipCSS();
  function updateTooltipCSS() { style.textContent = tooltipCSS(); }
  const tip = document.createElement('div');
  tip.className = 'tooltip';
  shadow.appendChild(style);
  shadow.appendChild(tip);

  let tooltipVisible = false;
  // Monotonic id — each tooltip open bumps it so late-arriving chunks from a
  // prior word's in-flight LLM stream can check `myId === tooltipRequestId`
  // and skip re-rendering a stale result over the current tooltip.
  let tooltipRequestId = 0;
  function showTip(x, y) {
    tip.classList.add('show');
    tooltipVisible = true;
    requestAnimationFrame(() => position(x, y));
  }
  function hideTip() {
    tip.classList.remove('show');
    tooltipVisible = false;
    tooltipRequestId++;
  }
  function position(x, y) {
    const r = tip.getBoundingClientRect();
    const vw = window.innerWidth, vh = window.innerHeight;
    let left = Math.min(Math.max(8, x + 12), vw - r.width - 8);
    let top  = y + 14;
    if (top + r.height > vh - 8) top = Math.max(8, y - r.height - 14);
    tip.style.left = left + 'px';
    tip.style.top  = top + 'px';
  }

  // --- Drag support ---
  let _dragState = null;
  tip.addEventListener('mousedown', (e) => {
    const headEl = e.target.closest('.head');
    if (!headEl || e.target.closest('.iconbtn')) return;
    e.preventDefault();
    const rect = tip.getBoundingClientRect();
    _dragState = { startX: e.clientX, startY: e.clientY, origLeft: rect.left, origTop: rect.top };
    tip.classList.add('dragging');
  });
  window.addEventListener('mousemove', (e) => {
    if (!_dragState) return;
    tip.style.left = (_dragState.origLeft + e.clientX - _dragState.startX) + 'px';
    tip.style.top  = (_dragState.origTop  + e.clientY - _dragState.startY) + 'px';
  });
  window.addEventListener('mouseup', () => {
    if (_dragState) { _dragState = null; tip.classList.remove('dragging'); }
  });

  function render(state) {
    tip.innerHTML = '';

    // --- Head: word + lang chip + TTS button ---
    const head = el('div', 'head');
    head.append(el('span', 'word', state.word));
    head.append(el('span', 'chip', (state.lang || settings.sourceLang || '').toUpperCase()));
    const tts = document.createElement('button');
    tts.className = 'iconbtn';
    tts.title = 'Pronounce';
    tts.textContent = '🔊';
    tts.onclick = (e) => { e.stopPropagation(); speak(state.word, state.lang); };
    head.append(tts);
    const cpy = document.createElement('button');
    cpy.className = 'iconbtn';
    cpy.title = 'Copy translation';
    cpy.textContent = '📋';
    cpy.onclick = (e) => { e.stopPropagation(); navigator.clipboard?.writeText(state.translation || ''); };
    head.append(cpy);
    if (state.linkHref) {
      const lnk = document.createElement('button');
      lnk.className = 'iconbtn';
      lnk.title = 'Open link';
      lnk.textContent = '🔗';
      lnk.onclick = (e) => { e.stopPropagation(); window.open(state.linkHref, '_blank'); };
      head.append(lnk);
    }
    // Etymology (LLM-only) — available whenever AI context is active.
    const isLLM = ['deepseek', 'openai', 'qwen', 'gemini', 'claude', 'custom'].includes(settings.translator);
    if (isLLM && !/\s/.test(state.word)) {
      const ety = document.createElement('button');
      ety.className = 'iconbtn';
      ety.title = 'Show etymology / word roots';
      ety.textContent = '🌳';
      ety.onclick = async (e) => {
        e.stopPropagation();
        if (state.etymology) { state.etymology = ''; render(state); return; }
        state.etymology = '…'; render(state);
        const res = await safeSendMessage({ type: 'etymology', word: state.word, from: state.lang });
        state.etymology = res?.ok ? res.etymology : ('⚠ ' + (res?.error || 'failed'));
        render(state);
      };
      head.append(ety);
      // 🔍 Secondary analysis — uses the "wordExplain2" prompt, free-form prose.
      const alt = document.createElement('button');
      alt.className = 'iconbtn';
      alt.title = 'Second opinion — alternate angle / grammar detail';
      alt.textContent = '🔍';
      alt.onclick = async (e) => {
        e.stopPropagation();
        if (state.altExplanation) { state.altExplanation = ''; render(state); return; }
        state.altExplanation = '…'; render(state);
        const sentence = state.context || state.word;
        const res = await safeSendMessage({ type: 'explainAlt', word: state.word, sentence, from: state.lang });
        state.altExplanation = res?.ok ? res.text : ('⚠ ' + (res?.error || 'failed'));
        render(state);
      };
      head.append(alt);
      const stBtn = document.createElement('button');
      stBtn.className = 'iconbtn';
      stBtn.title = 'Translate full sentence';
      stBtn.textContent = '📖';
      stBtn.onclick = async (e) => {
        e.stopPropagation();
        if (state.sentenceTranslation) { state.sentenceTranslation = ''; state.sentenceOriginal = ''; render(state); return; }
        const para = state.paragraph || '';
        const sentence = state.domSentence || state.sentence || state.word;
        if (!sentence || sentence === state.word) return;
        const sentKey = sentence.slice(0, 80).toLowerCase();
        const cached = _sentCache.get(sentKey);
        if (cached) { state.sentenceOriginal = sentence; state.sentenceTranslation = cached; render(state); return; }
        state.sentenceOriginal = sentence; state.sentenceTranslation = '…'; render(state);
        const useContext = settings.sentenceContext !== false && para.length > sentence.length + 10;
        const ctxPara = useContext ? para : undefined;
        const terms = _extractKnownTerms(sentence);
        let res = await safeSendMessage({
          type: 'sentenceTranslate', sentence, from: state.lang,
          paragraph: ctxPara, terms
        });
        if (!res || !res.ok) {
          res = await directSentenceTranslate(sentence, state.lang, ctxPara, terms);
        }
        const tr = res?.ok ? res.translation : ('⚠ ' + (res?.error || 'failed'));
        state.sentenceTranslation = tr;
        if (res?.ok) _sentCache.set(sentKey, tr);
        render(state);
      };
      head.append(stBtn);
    }
    // Sentence-mining button — only when selection is a phrase/sentence.
    if (state.word && state.word.length >= 15 && /\s/.test(state.word)) {
      const sent = document.createElement('button');
      sent.className = 'iconbtn';
      sent.title = 'Save as sentence card';
      sent.textContent = '💬';
      sent.onclick = async (e) => {
        e.stopPropagation();
        sent.disabled = true; sent.textContent = '⋯';
        const card = await localSaveSentence({
          sentence: state.word, translation: state.translation,
          context: state.context, source: location.href
        });
        if (card) { sent.textContent = '✅'; setTimeout(hideTip, 700); }
        else sent.textContent = '⚠';
      };
      head.append(sent);
    }
    tip.append(head);

    // --- Sentence translation (blue, first position) ---
    if (state.sentenceTranslation) {
      const sentDiv = document.createElement('div');
      sentDiv.className = 'card sent';
      if (state.sentenceOriginal) {
        const orig = document.createElement('div');
        orig.className = 'sent-orig';
        orig.textContent = state.sentenceOriginal;
        sentDiv.appendChild(orig);
      }
      const trDiv = document.createElement('div');
      trDiv.textContent = state.sentenceTranslation;
      sentDiv.appendChild(trDiv);
      tip.append(sentDiv);
    }

    // --- Tag row: pos / inflection ---
    if (state.pos || state.inflection) {
      const tags = el('div', 'tags');
      if (state.pos)        tags.append(tagEl('pos', state.pos));
      if (state.inflection) tags.append(tagEl('', state.inflection));
      tip.append(tags);
    }

    // --- Main translation card: phrase:meaning if present, else plain translation ---
    if (state.phrase && state.phraseMeaning) {
      tip.append(el('div', 'card dict', `${state.phrase}: ${state.phraseMeaning}`));
      if (state.translation && state.translation !== state.phraseMeaning) {
        tip.append(el('div', 'card dict', state.translation));
      }
    } else if (state.translation) {
      tip.append(el('div', 'card dict', state.translation));
    }

    // --- Contextual note (orange) ---
    if (state.note) tip.append(el('div', 'card note', state.note));

    // --- Etymology (green, on demand) ---
    if (state.etymology) tip.append(el('div', 'card etym', state.etymology));

    // --- Secondary analysis (purple, on demand) ---
    if (state.altExplanation) tip.append(el('div', 'card alt2', state.altExplanation));

    // --- Alternates (from non-AI providers) ---
    if (!state.aiContext && state.alternatives && state.alternatives.length) {
      tip.append(el('div', 'alts', 'Also: ' + state.alternatives.join(' · ')));
    }
    if (state.aiContextError) {
      tip.append(el('div', 'err', 'AI context failed: ' + state.aiContextError));
    }

    // --- Level action bar: × 1 2 3 4 ✓ ---
    const bar = el('div', 'lvlbar');
    const addBtn = (cls, label, title, fn) => {
      const b = document.createElement('button');
      b.className = cls;
      b.textContent = label;
      b.title = title;
      b.onclick = fn;
      bar.append(b);
      return b;
    };
    addBtn('x', '×',
      state.saved ? 'Reset to unknown (delete this card)' : 'Close',
      async () => {
        if (state.saved && state.card) {
          await localDeleteCard(state.card.id);
        }
        hideTip();
      }
    );
    for (const lvl of [1, 2, 3, 4]) {
      const active = state.card && (state.card.level || 1) === lvl;
      const btn = addBtn('lvl' + (active ? ' active' : ''), String(lvl),
        `Set level ${lvl} — ${LEVEL_LABELS[lvl]}`, async () => {
          if (state.card) {
            const card = await localSetLevel(state.card.id, lvl);
            if (card) { state.card = card; render(state); }
          } else {
            // Selection path without auto-save: create card, then set level.
            const card = await localSaveCard({ word: state.word, translation: state.translation, context: state.context });
            if (card && lvl !== 1) {
              const c2 = await localSetLevel(card.id, lvl);
              state.card = c2 || card;
            } else if (card) {
              state.card = card;
            }
            state.saved = !!state.card;
            render(state);
          }
        });
      btn.dataset.lvl = String(lvl);
    }
    addBtn('v', '✓', 'Fully mastered (level 5) — stop highlighting', async () => {
      if (state.card) {
        const card = await localSetLevel(state.card.id, 5);
        if (card) state.card = card;
      } else {
        const card = await localSaveCard({ word: state.word, translation: state.translation, context: state.context });
        if (card) await localSetLevel(card.id, 5);
      }
      hideTip();
    });
    addBtn('x', '🚫', 'Add to ignore list — never highlight or translate', async () => {
      const word = state.word.trim();
      if (!word) return;
      const cur = normalizeStringArray(settings.ignoreList);
      if (!cur.some(w => w.toLowerCase() === word.toLowerCase())) {
        cur.push(word);
        settings.ignoreList = cur;
        ignoreSet.add(word.toLowerCase());
        try { await chrome.storage.local.get('settings').then(r => {
          const s = r.settings || {};
          s.ignoreList = cur;
          s._settingsUpdatedAt = Date.now();
          return chrome.storage.local.set({ settings: s });
        }); } catch {}
      }
      hideTip();
      updateSpansForWord(word.toLowerCase());
    });
    tip.append(bar);

    const meta = el('div', 'meta');
    meta.append(el('span', '', state.provider ? `via ${state.provider}` : ''));
    meta.append(el('span', '', 'LinguaFlow'));
    tip.append(meta);
  }

  function tagEl(cls, text) {
    const t = document.createElement('span');
    t.className = 'tag' + (cls ? ' ' + cls : '');
    t.textContent = text;
    return t;
  }

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  // Copy translation fields from a message response into tooltip state.
  function applyTranslation(state, res) {
    state.translation = res.translation || '';
    state.alternatives = res.alternatives || [];
    state.provider = res.provider || '';
    state.aiContext = !!res.aiContext;
    state.pos = res.pos || '';
    state.inflection = res.inflection || '';
    state.phrase = res.phrase || '';
    state.phraseMeaning = res.phraseMeaning || '';
    state.note = res.note || '';
    if (res.aiContextError) state.aiContextError = res.aiContextError;
  }

  const _sentCache = new Map();

  function _extractKnownTerms(sentence) {
    const words = sentence.toLowerCase().match(/[a-zA-ZÀ-ɏ]{2,}/g) || [];
    const seen = new Set();
    const terms = [];
    for (const w of words) {
      if (seen.has(w)) continue;
      seen.add(w);
      const card = vocabByWord.get(w);
      if (card && card.translation && (card.level || 1) < 5) {
        terms.push(card.word + '=' + card.translation);
      }
      if (terms.length >= 15) break;
    }
    return terms.length ? terms.join(', ') : undefined;
  }

  function _getParagraphText(elOrNode) {
    const host = elOrNode?.closest?.('p, li, blockquote, td, h1, h2, h3, h4, h5, h6')
              || elOrNode?.closest?.('div')
              || elOrNode?.parentElement;
    if (!host) return '';
    return (host.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 1200);
  }

  function _getSentenceFromDOM(paraHost, targetEl, nodeOffset) {
    if (!paraHost || !targetEl) return '';
    const walker = document.createTreeWalker(paraHost, NodeFilter.SHOW_TEXT);
    const isTerm = (c) => /[.!?。！？…]/.test(c);
    let allText = '', targetStart = -1, node;
    while ((node = walker.nextNode())) {
      const t = node.textContent || '';
      if (targetStart < 0 && (targetEl.contains(node) || node === targetEl)) {
        targetStart = allText.length + (nodeOffset || 0);
      }
      allText += t;
    }
    if (targetStart < 0) return '';
    let start = 0;
    for (let i = targetStart - 1; i >= 0; i--) {
      if (isTerm(allText[i])) { start = i + 1; break; }
    }
    let end = allText.length;
    for (let i = targetStart; i < allText.length; i++) {
      if (isTerm(allText[i])) { end = i + 1; break; }
    }
    return allText.slice(start, end).replace(/\s+/g, ' ').trim();
  }

  function getSentenceAround(elOrNode, word, rawTextNode, nodeOffset) {
    const text = _getParagraphText(elOrNode);
    if (!text) return (word || '').trim();
    if (settings.aiContextScope === 'paragraph') return text.slice(0, 800);
    const paraHost = elOrNode?.closest?.('p, li, blockquote, td, h1, h2, h3, h4, h5, h6')
                  || elOrNode?.closest?.('div') || elOrNode?.parentElement;
    return (_getSentenceFromDOM(paraHost, rawTextNode || elOrNode, nodeOffset) || word || '').slice(0, 320);
  }

  let _ttsAudio = null;
  function speak(text, lang) {
    if (!settings.tts?.enabled) return;
    const resolved = lang || detectLangOf(text) || settings.sourceLang;
    const provider = settings.tts?.provider || 'browser';
    if (provider === 'browser') return speakBrowser(text, resolved);
    speakViaProvider(text, resolved);
  }
  function speakBrowser(text, lang) {
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = TTS_LOCALE[lang] || TTS_LOCALE[settings.sourceLang] || 'en-US';
      u.rate = settings.tts?.rate || 1;
      speechSynthesis.speak(u);
    } catch (e) { /* noop */ }
  }
  async function speakViaProvider(text, lang) {
    try {
      if (_ttsAudio) { try { _ttsAudio.pause(); } catch {} _ttsAudio = null; }
      const res = await safeSendMessage({ type: 'ttsSynthesize', text, lang });
      if (!res?.ok) {
        console.warn('[LinguaFlow] TTS provider failed, falling back to browser:', res?.error);
        return speakBrowser(text, lang);
      }
      const bin = atob(res.audioBase64);
      const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      const url = URL.createObjectURL(new Blob([arr], { type: res.mime || 'audio/mpeg' }));
      _ttsAudio = new Audio(url);
      // Google Translate (free) doesn't support rate server-side — bake it in client-side.
      // The paid providers (Google Cloud / Azure / OpenAI) already apply speakingRate
      // in the synthesis request, so we leave playbackRate at 1 for those.
      if ((settings.tts?.provider || 'browser') === 'google-free') {
        _ttsAudio.playbackRate = settings.tts?.rate || 1;
      }
      _ttsAudio.onended = () => { URL.revokeObjectURL(url); _ttsAudio = null; };
      await _ttsAudio.play();
    } catch (e) {
      console.warn('[LinguaFlow] TTS error, falling back to browser:', e);
      speakBrowser(text, lang);
    }
  }

  // ---- Selection handler ----
  let lastEvent = null;
  document.addEventListener('mouseup', (e) => {
    if (settings.enabled === false) return;
    if (!settings.showOnSelection) return;
    if (isInsideHost(e.target)) return;
    lastEvent = e;
    setTimeout(() => handleSelection(e), 10);
  });

  document.addEventListener('mousedown', (e) => {
    if (!tooltipVisible) return;
    if (isInsideHost(e.target)) return;
    if (e.target.closest && e.target.closest('.linguaflow-highlight')) return;
    hideTip();
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && tooltipVisible) hideTip();
  });

  function isInsideHost(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.id === 'linguaflow-host' || node.id === 'lf-review-host') return true;
    return !!node.closest?.('#linguaflow-host, #lf-review-host, #linguaflow-due-banner, #linguaflow-stale-banner');
  }

  async function handleSelection(e, overrideText = '') {
    const text = (overrideText || window.getSelection()?.toString() || '').trim();
    if (!text || text.length > 400) return;
    if (!/\s/.test(text) && isJunkToken(text)) return;
    if (isWordIgnored(text.toLowerCase())) return;
    const existing = vocabByWord.get(text.toLowerCase());
    const ctxText = getContext(e.target);
    const state = {
      word: text,
      lang: existing?.lang || detectLangOf(text, ctxText),
      translation: existing ? existing.translation : '…translating…',
      saved: !!existing,
      card: existing || null,
      context: ctxText,
      provider: existing ? 'saved' : ''
    };
    render(state);
    showTip(e.clientX, e.clientY);
    speak(text, state.lang);
    if (existing) return;
    try {
      const sentence = getSentenceAround(e.target, text);
      const res = await streamTranslate({
        text, sentence, from: state.lang,
        onUpdate: (partial) => {
          // Live-update tooltip as tokens arrive.
          if (partial.translation) state.translation = partial.translation;
          if (partial.note) state.note = partial.note;
          if (partial.pos) state.pos = partial.pos;
          if (partial.inflection) state.inflection = partial.inflection;
          if (partial.phrase) state.phrase = partial.phrase;
          if (partial.phraseMeaning) state.phraseMeaning = partial.phraseMeaning;
          state.aiContext = true;
          render(state);
        }
      });
      if (!res || !res.ok) {
        state.translation = res?.error || 'Translation failed';
      } else {
        applyTranslation(state, res);
      }
      render(state);
    } catch (err) {
      state.translation = 'Error: ' + err.message;
      render(state);
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'showTranslation' && msg.text) {
      const sel = window.getSelection();
      const rect = sel && sel.rangeCount ? sel.getRangeAt(0).getBoundingClientRect() : null;
      const fakeE = { clientX: rect?.left || 100, clientY: rect?.bottom || 100, target: document.body };
      handleSelection(fakeE, msg.text);
    }
  });

  // ---- Click anywhere on a word (highlighted or not) — single click opens tooltip ----
  // Highlighted spans get the same treatment. Plain text uses caretPositionFromPoint
  // to find the word under the cursor so users don't have to select it first.

  function isInteractive(el) {
    return el && el.closest && el.closest(
      'a[href], button, input, textarea, select, summary, [role="button"], [contenteditable="true"]'
    );
  }

  function wordAtPoint(x, y) {
    let node = null, offset = 0;
    if (document.caretPositionFromPoint) {
      const p = document.caretPositionFromPoint(x, y);
      if (p) { node = p.offsetNode; offset = p.offset; }
    } else if (document.caretRangeFromPoint) {
      const r = document.caretRangeFromPoint(x, y);
      if (r) { node = r.startContainer; offset = r.startOffset; }
    }
    const wordChar = /[A-Za-zÀ-ɏЀ-ӿ''’\-‐‑–]/;
    const INLINE_TAGS = new Set(['SPAN','B','STRONG','EM','I','MARK','ABBR','S','U','SUB','SUP','SMALL','CODE','FONT']);
    const isInline = (el) => el && el.nodeType === 1 && INLINE_TAGS.has(el.tagName);

    let skipPrecisionGuard = false;
    const clickedEl = document.elementFromPoint(x, y);
    debugLog('[LF] caretNode:', node?.nodeType, JSON.stringify(node?.nodeValue?.slice(0,30)), 'offset:', offset);
    debugLog('[LF] elementFromPoint:', clickedEl?.tagName, clickedEl?.className, clickedEl?.outerHTML?.slice(0,120));
    if (clickedEl && isInline(clickedEl) &&
        (!node || node.nodeType !== 3 || !clickedEl.contains(node))) {
      const walk = (el) => {
        for (const c of el.childNodes) {
          if (c.nodeType === 3 && /[A-Za-zÀ-ɏ]/.test(c.nodeValue)) return c;
          if (c.nodeType === 1 && INLINE_TAGS.has(c.tagName)) { const r = walk(c); if (r) return r; }
        }
        return null;
      };
      const textChild = walk(clickedEl);
      debugLog('[LF] fallback textChild:', textChild?.nodeValue);
      if (textChild) {
        node = textChild;
        const txt = node.nodeValue;
        let pos = 0;
        while (pos < txt.length && !wordChar.test(txt[pos])) pos++;
        offset = pos < txt.length ? pos + 1 : txt.length;
        skipPrecisionGuard = true;
      }
    }

    if (!node || node.nodeType !== 3) return null;
    if (!node.nodeValue) return null;
    // CJK path: use Intl.Segmenter since words have no whitespace boundaries.
    // Route by clicked character's script: Latin chars → leaf-walking path
    // (supports cross-node words like drop caps), CJK chars → segmenter path.
    const cjkActive = anyActiveCJK();
    if (cjkActive) {
      const ch = node.nodeValue[Math.min(offset, node.nodeValue.length - 1)] || '';
      if (!/[A-Za-zÀ-ɏ]/.test(ch))
        return wordAtPointCJK(node, offset, x, y);
    }

    let container = node.parentElement;
    while (container && isInline(container) && container.parentElement) {
      container = container.parentElement;
    }
    if (!container) return null;
    debugLog('[LF] container:', container.tagName, container.className);

    const leaves = [];
    const flattenInline = (el) => {
      for (const child of el.childNodes) {
        if (child.nodeType === 3) {
          if (child.nodeValue.trim()) leaves.push({ node: child });
          else leaves.push({ break: true });
        }
        else if (isInline(child)) { flattenInline(child); }
        else { leaves.push({ break: true }); }
      }
    };
    flattenInline(container);

    const caretIdx = leaves.findIndex((l) => l.node === node);
    debugLog('[LF] leaves:', leaves.length, 'caretIdx:', caretIdx,
      'nextLeaf:', leaves[caretIdx+1]?.node?.nodeValue?.slice(0,20));
    if (caretIdx < 0) return null;

    // Walk left across leaves, collecting word chars.
    let li = caretIdx, lo = offset, leftText = '';
    while (true) {
      if (lo > 0) {
        const c = leaves[li].node.nodeValue[lo - 1];
        if (wordChar.test(c)) { leftText = c + leftText; lo--; continue; }
        // Bridge spaced-hyphen gap backwards: \s*hyphen\s* then word chars
        const before = leaves[li].node.nodeValue.slice(0, lo);
        const bm = before.match(/(\s*[-‐‑–]\s*)$/);
        if (bm) {
          const bs = lo - bm[1].length;
          if (bs > 0 && wordChar.test(leaves[li].node.nodeValue[bs - 1])) {
            leftText = '-' + leftText; lo = bs; continue;
          }
          if (bs === 0) {
            const pl = li - 1;
            if (pl >= 0 && !leaves[pl].break) {
              const pv = leaves[pl].node.nodeValue;
              if (pv.length > 0 && wordChar.test(pv[pv.length - 1])) {
                leftText = '-' + leftText; li = pl; lo = pv.length; continue;
              }
            }
          }
        }
        break;
      }
      const prev = li - 1;
      if (prev < 0 || leaves[prev].break) break;
      li = prev;
      lo = leaves[li].node.nodeValue.length;
    }

    // Walk right across leaves.
    let ri = caretIdx, ro = offset, rightText = '';
    while (true) {
      const val = leaves[ri].node.nodeValue;
      if (ro < val.length) {
        const c = val[ro];
        if (wordChar.test(c)) { rightText += c; ro++; continue; }
        // Bridge spaced-hyphen gap forward: \s*hyphen\s* then word chars
        const rest = val.slice(ro);
        const bm = rest.match(/^(\s*[-‐‑–]\s*)/);
        if (bm) {
          const ae = ro + bm[1].length;
          if (ae < val.length && wordChar.test(val[ae])) {
            rightText += '-'; ro = ae; continue;
          }
          if (ae >= val.length) {
            const nl = ri + 1;
            if (nl < leaves.length && !leaves[nl].break) {
              const nv = leaves[nl].node.nodeValue;
              if (nv.length > 0 && wordChar.test(nv[0])) {
                rightText += '-'; ri = nl; ro = 0; continue;
              }
            }
          }
        }
        break;
      }
      const nxt = ri + 1;
      if (nxt >= leaves.length || leaves[nxt].break) break;
      ri = nxt;
      ro = 0;
    }

    const w = (leftText + rightText).replace(/[‐‑–]/g, '-').replace(/['']/g, "'").replace(/^[-''']+|[-''']+$/g, '');
    debugLog('[LF] word extracted:', w, 'left:', leftText, 'right:', rightText, 'leaves:', leaves.length, 'caretIdx:', caretIdx);
    if (!w) return null;
    if (!skipPrecisionGuard) {
      try {
        const range = document.createRange();
        range.setStart(leaves[li].node, lo);
        range.setEnd(leaves[ri].node, ro);
        const rects = range.getClientRects();
        const PAD = 5;
        let hit = false;
        for (const r of rects) {
          if (x >= r.left - PAD && x <= r.right + PAD &&
              y >= r.top - PAD  && y <= r.bottom + PAD) { hit = true; break; }
        }
        if (!hit) return null;
      } catch {}
    }
    return { word: w, node, offset };
  }

  // CJK variant — no whitespace to walk, so use Intl.Segmenter to find the
  // word covering the click offset within the clicked text node.
  function wordAtPointCJK(node, offset, x, y) {
    const active = activeSourceLangs();
    const segLang = CJK_LANGS.has(settings.sourceLang) ? settings.sourceLang
                    : active.find(l => CJK_LANGS.has(l));
    const seg = getWordSegmenter(segLang);
    if (!seg) return null;
    const text = node.nodeValue;
    for (const { segment, index, isWordLike } of seg.segment(text)) {
      if (!isWordLike) continue;
      const end = index + segment.length;
      if (offset < index || offset > end) continue;
      try {
        const range = document.createRange();
        range.setStart(node, index);
        range.setEnd(node, end);
        const rects = range.getClientRects();
        const PAD = 5;
        let hit = false;
        for (const r of rects) {
          if (x >= r.left - PAD && x <= r.right + PAD &&
              y >= r.top - PAD  && y <= r.bottom + PAD) { hit = true; break; }
        }
        if (!hit) return null;
      } catch {}
      return { word: segment, node };
    }
    return null;
  }

  // Single unified entry point — called by both span clicks and plain-text clicks.
  function openTooltipForWord(word, x, y, ctxEl, linkHref, rawTextNode, nodeOffset) {
    const myId = ++tooltipRequestId;
    const existing = vocabByWord.get(word.toLowerCase());
    const ctxText = existing?.context || getContext(ctxEl);
    const state = {
      word,
      lang: existing?.lang || detectLangOf(word, ctxText),
      translation: existing?.translation || '…translating…',
      pos: existing?.pos || '',
      inflection: existing?.inflection || '',
      phrase: existing?.phrase || '',
      phraseMeaning: existing?.phraseMeaning || '',
      note: existing?.note || '',
      saved: !!existing, card: existing || null,
      unknown: !existing,
      context: ctxText,
      provider: existing?.state || '',
      aiContext: !!(existing?.pos || existing?.note || existing?.phrase),
      linkHref: linkHref || null
    };
    render(state);
    showTip(x, y);
    speak(word, state.lang);

    state.paragraph = _getParagraphText(ctxEl);
    const paraHost = ctxEl?.closest?.('p, li, blockquote, td, h1, h2, h3, h4, h5, h6')
                  || ctxEl?.closest?.('div') || ctxEl?.parentElement;
    state.domSentence = _getSentenceFromDOM(paraHost, rawTextNode || ctxEl, nodeOffset);
    const sentence = getSentenceAround(ctxEl, word, rawTextNode, nodeOffset);
    state.sentence = sentence;
    const useAI = settings.aiContext !== false &&
      ['deepseek', 'openai', 'qwen', 'gemini', 'claude', 'custom'].includes(settings.translator);
    const isActive = () => myId === tooltipRequestId;

    (async () => {
      if (existing && !useAI) return;
      const tRes = await streamTranslate({
        text: word, sentence, from: state.lang,
        onUpdate: (p) => {
          if (!isActive()) return;
          if (p.translation) state.translation = p.translation;
          if (p.note) state.note = p.note;
          if (p.pos) state.pos = p.pos;
          if (p.inflection) state.inflection = p.inflection;
          if (p.phrase) state.phrase = p.phrase;
          if (p.phraseMeaning) state.phraseMeaning = p.phraseMeaning;
          state.aiContext = true;
          render(state);
        }
      });
      if (isActive()) {
        if (tRes && tRes.ok) applyTranslation(state, tRes);
        else if (!existing) state.translation = tRes?.error || 'Translation failed';
        render(state);
      }

      const saved = await localSaveCard({
        word, translation: tRes?.translation || existing?.translation || '',
        context: state.context, source: existing?.source || location.href,
        pos: tRes?.pos, inflection: tRes?.inflection,
        phrase: tRes?.phrase, phraseMeaning: tRes?.phraseMeaning, note: tRes?.note
      });
      if (saved && isActive()) {
        state.card = saved;
        state.saved = true;
        state.unknown = false;
        render(state);
      }
    })();
  }

  document.addEventListener('click', (e) => {
    if (settings.enabled === false) return;
    if (isInsideHost(e.target)) return;

    // Highlighted span — use its rect as anchor
    const span = e.target.closest && e.target.closest('.linguaflow-highlight');
    if (span) {
      e.stopPropagation(); e.preventDefault();
      const anchor = span.closest && span.closest('a[href]');
      const href = anchor ? anchor.href : null;
      const rect = span.getBoundingClientRect();
      const hit = wordAtPoint(e.clientX, e.clientY);
      const word = hit?.word || span.dataset.lfWord || span.textContent;
      if (word.toLowerCase() !== normHyphen(span.textContent.toLowerCase())) {
        span.dataset.lfWord = word;
      }
      const existing = vocabByWord.get(word.toLowerCase());
      if (existing) updateSpansForWord(word.toLowerCase());
      openTooltipForWord(word, rect.left, rect.bottom, span, href);
      return;
    }

    // Plain text click — let form fields / buttons / links work normally
    // But if click is inside a link, check for a word under cursor first
    const interEl = isInteractive(e.target);
    if (interEl) {
      const anchor = e.target.closest && e.target.closest('a[href]');
      if (!anchor) return;
      const hit = wordAtPoint(e.clientX, e.clientY);
      if (!hit || !hit.word) return;
      const wordIsCJK = /[぀-ヿ㐀-䶿一-鿿가-힯]/.test(hit.word);
      if (!wordIsCJK && hit.word.length < 2) return;
      if (!wordIsCJK && !/[A-Za-zÀ-ɏЀ-ӿ]/.test(hit.word)) return;
      if (isJunkToken(hit.word)) return;
      if (isWordIgnored(hit.word.toLowerCase())) return;
      const ctxText = getContext(hit.node.parentElement);
      if (!wordMatchesActiveScript(hit.word, ctxText)) return;
      e.stopPropagation(); e.preventDefault();
      openTooltipForWord(hit.word, e.clientX, e.clientY, hit.node.parentElement, anchor.href, hit.node, hit.offset);
      return;
    }

    debugLog('[LF] click target:', e.target.tagName, e.target.className, e.target.dataset?.caps);
    const hit = wordAtPoint(e.clientX, e.clientY);
    debugLog('[LF] wordAtPoint result:', hit);
    if (!hit || !hit.word) return;
    // Single-char tokens are valid for CJK (e.g. 目 / 水). For Latin tokens we
    // still require ≥2 chars + at least one letter.
    const wordIsCJK = /[\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uAC00-\uD7AF]/.test(hit.word);
    if (!wordIsCJK && hit.word.length < 2) return;
    if (!wordIsCJK && !/[A-Za-z\u00C0-\u024F\u0400-\u04FF]/.test(hit.word)) return;
    if (isJunkToken(hit.word)) return;
    if (isWordIgnored(hit.word.toLowerCase())) return;
    // Script gate — don't consume the click if the word's script doesn't
    // belong to any active source lang. Lets hyperlinks through on pages whose
    // language isn't in the user's learning set (e.g. a Chinese page while
    // learning en+ja). getContext reads the enclosing block for kana hints.
    const ctxText = getContext(hit.node.parentElement);
    if (!wordMatchesActiveScript(hit.word, ctxText)) return;
    e.stopPropagation(); e.preventDefault();
    openTooltipForWord(hit.word, e.clientX, e.clientY, hit.node.parentElement, null, hit.node, hit.offset);
  }, true);

  function getContext(el) {
    const node = el && el.closest ? el.closest('p, li, blockquote, td, h1, h2, h3, h4, h5, h6') : null;
    const text = (node || el?.parentElement)?.textContent?.trim() || '';
    return text.slice(0, 300);
  }

  // ---- Highlighting ----
  let highlightTimer = null;
  function scheduleHighlight() {
    clearTimeout(highlightTimer);
    // Chain Bionic after highlights in the same tick. Boot-time setTimeout
    // wouldn't work — the MutationObserver keeps resetting this debounce on
    // busy pages (React hydration, lazy loads), so a fixed-timer Bionic can
    // fire before highlights and then block the highlighter (since its walker
    // now skips Bionic-split text).
    highlightTimer = setTimeout(() => {
      highlightPage();
      if (settings.bionicReading === true && settings.enabled !== false) applyBionic();
    }, 400);
  }

  function highlightPage() {
    if (!document.body) return;
    if (settings.enabled === false) return;
    if (settings.highlightMode === 'off') return;
    if (!anyActiveLatin() && !anyActiveCJK()) return;
    // Only skip when there's genuinely nothing to do — saved-only mode with no cards.
    if (settings.highlightMode === 'saved' && vocabByWord.size === 0) return;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentNode;
        if (!p || !(p instanceof Element)) return NodeFilter.FILTER_REJECT;
        const tag = p.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA' || tag === 'INPUT'
            || tag === 'CODE' || tag === 'PRE' || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
        if (p.closest('#linguaflow-host, .linguaflow-highlight, [contenteditable="true"], nav, [role="navigation"], [role="menu"], [role="menubar"], [role="toolbar"]')) return NodeFilter.FILTER_REJECT;
        // Skip Bionic-split text. Bionic wraps the first half of each word in
        // `<b class="lf-bionic">`; re-highlighting halves as standalone words
        // (e.g. "Mich" out of "Michael") would fragment them into bad cards.
        if (tag === 'B' && p.classList && (p.classList.contains('lf-bionic') || p.classList.contains('lf-bionic-yt'))) return NodeFilter.FILTER_REJECT;
        const prev = node.previousSibling;
        if (prev && prev.nodeType === 1 && prev.tagName === 'B' && prev.classList &&
            (prev.classList.contains('lf-bionic') || prev.classList.contains('lf-bionic-yt'))) return NodeFilter.FILTER_REJECT;
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    let n, i = 0;
    while ((n = walker.nextNode()) && i++ < 5000) nodes.push(n);
    for (const node of nodes) highlightNode(node);
  }

  function highlightNode(node) {
    const text = node.nodeValue;
    const rx = /\b([A-Za-z\u00C0-\u024F][A-Za-z\u00C0-\u024F\-\u2010\u2011\u2013'\u2018\u2019]{1,})\b/g;
    const unknownMode = settings.highlightMode === 'unknown';
    const stop = activeSourceLangs().includes('en') ? STOP_WORDS_EN : null;
    let m, matches = [];

    // Cross-node word: preceding inline sibling ends with word chars that
    // continue into this text node (e.g. drop-cap <span>"O</span>ur = "Our").
    const _INLINE = new Set(['SPAN','B','STRONG','EM','I','MARK','ABBR','S','U','SUB','SUP','SMALL','CODE','FONT']);
    const _isInline = (el) => el && el.nodeType === 1 && _INLINE.has(el.tagName);
    const wc = /[A-Za-z\u00C0-\u024F\-\u2010\u2011\u2013'\u2018\u2019]/;
    let prevSib = node.previousSibling;
    if (!prevSib && _isInline(node.parentElement)) {
      prevSib = node.parentElement.previousSibling;
    }
    const _parentDisplay = prevSib ? getComputedStyle((prevSib.parentElement || node.parentElement)).display : '';
    const _isFlexGrid = _parentDisplay === 'flex' || _parentDisplay === 'inline-flex' ||
                        _parentDisplay === 'grid' || _parentDisplay === 'inline-grid';
    if (prevSib && _isInline(prevSib) && !_isFlexGrid) {
      const sibText = prevSib.textContent;
      let pi = sibText.length;
      while (pi > 0 && wc.test(sibText[pi - 1])) pi--;
      const prefix = sibText.slice(pi);
      if (prefix.length > 0) {
        let si = 0;
        while (si < text.length && wc.test(text[si])) si++;
        const contStart = 0;
        const continuation = text.slice(contStart, si);
        if (continuation.length > 0) {
          const fullWord = (prefix + continuation).replace(/^[-''']+|[-''']+$/g, '');
          const lower = normHyphen(fullWord.toLowerCase());
          const prefixClean = prefix.replace(/^[-''']+|[-''']+$/g, '').toLowerCase();
          const contClean = continuation.replace(/^[-''']+|[-''']+$/g, '').toLowerCase();
          if (fullWord.length >= 2 && !isWordIgnored(lower) &&
              !isWordIgnored(prefixClean) && !isWordIgnored(contClean)) {
            const card = vocabByWord.get(lower);
            let kind = null, matchCard = null;
            if (card && (card.level || 1) < KNOWN_LEVEL) {
              kind = 'card'; matchCard = card;
            } else if (unknownMode && !(card && (card.level || 1) >= KNOWN_LEVEL) &&
                       !knownSet.has(lower) && !(stop && stop.has(lower)) && fullWord.length >= 3) {
              kind = 'unknown';
            }
            if (kind) {
              const _findLastText = (el) => {
                for (let i = el.childNodes.length - 1; i >= 0; i--) {
                  const c = el.childNodes[i];
                  if (c.nodeType === 3 && c.nodeValue.trim()) return c;
                  if (c.nodeType === 1 && _INLINE.has(c.tagName)) { const r = _findLastText(c); if (r) return r; }
                }
                return null;
              };
              const sibLast = _findLastText(prevSib);
              if (sibLast) {
                const lv = sibLast.nodeValue;
                let lpi = lv.length;
                while (lpi > 0 && wc.test(lv[lpi - 1])) lpi--;
                const pf = document.createDocumentFragment();
                if (lpi > 0) pf.append(document.createTextNode(lv.slice(0, lpi)));
                const ps = document.createElement('span');
                if (kind === 'card') {
                  ps.className = `linguaflow-highlight linguaflow-level-${matchCard.level || 1}`;
                  ps.dataset.lfId = matchCard.id;
                } else {
                  ps.className = 'linguaflow-highlight linguaflow-unknown';
                }
                ps.dataset.lfWord = fullWord;
                ps.textContent = lv.slice(lpi);
                pf.append(ps);
                sibLast.parentNode.replaceChild(pf, sibLast);
                debugLog('[LF] drop-cap prefix highlighted:', { prefix: lv.slice(lpi), fullWord, kind, className: ps.className, parent: ps.parentElement?.tagName, parentAttrs: ps.parentElement?.outerHTML?.slice(0, 200) });
              }
              matches.push({ start: contStart, end: si, raw: continuation,
                card: matchCard, kind, fullWord });
            }
          }
        }
      }
    }

    // CJK gate: delegate to segmenter path only when text contains CJK chars.
    // Latin-only text uses the regex path which correctly handles compounds
    // like "minivan-sized" and possessives like "country's" as single tokens.
    if (anyActiveCJK() && matches.length === 0 &&
        /[぀-ヿ㐀-䶿一-鿿가-힯]/.test(text)) {
      return highlightNodeCJK(node);
    }

    while ((m = rx.exec(text)) !== null) {
      const raw = m[0];
      if (matches.length > 0 && m.index < matches[0].end) continue;
      const lower = normHyphen(raw.toLowerCase());
      if (isWordIgnored(lower)) continue;
      const card = vocabByWord.get(lower);
      if (card && (card.level || 1) < KNOWN_LEVEL) {
        matches.push({ start: m.index, end: m.index + raw.length, raw, card, kind: 'card' });
      } else if (unknownMode) {
        if (card && (card.level || 1) >= KNOWN_LEVEL) continue;
        if (knownSet.has(lower)) continue;
        if (stop && stop.has(lower)) continue;
        if (raw.length < 3) continue;
        matches.push({ start: m.index, end: m.index + raw.length, raw, kind: 'unknown' });
      }
    }
    if (!matches.length) return;
    applyMatches(node, text, matches);
  }

  // CJK highlighter — uses Intl.Segmenter('ja'|'zh'|'ko', 'word') for real
  // morphological boundaries instead of regex. Segmenter also correctly
  // tokenizes embedded Latin words in mixed text, so the multi-lang
  // (e.g. en+ja) case flows through this path whenever any CJK is active.
  function highlightNodeCJK(node) {
    const text = node.nodeValue;
    // Prefer a CJK segmenter (primary first, else first active CJK). English-
    // only pages don't hit this branch because `anyActiveCJK()` gates it.
    const active = activeSourceLangs();
    const segLang = CJK_LANGS.has(settings.sourceLang) ? settings.sourceLang
                    : active.find(l => CJK_LANGS.has(l));
    const seg = getWordSegmenter(segLang);
    if (!seg) return;
    const unknownMode = settings.highlightMode === 'unknown';
    const useEnStop = active.includes('en');
    const useJaStop = active.includes('ja');
    const zhActive  = active.includes('zh') || active.includes('zh-TW');
    const jaActive  = active.includes('ja');
    const koActive  = active.includes('ko');
    const anyLatinActive = active.some(l => LATIN_LANG_CODES.has(l));
    // Page-level signal first: html[lang] / body kana scan. If the page is
    // clearly Japanese, Han tokens are ja; if it's clearly Chinese, they're zh;
    // only fall back to local kana-adjacent heuristic in ambiguous cases.
    const pageL = pageLanguage();
    const hasKanaNearby = /[\u3040-\u309F\u30A0-\u30FF]/.test(text);
    const reKana   = /[\u3040-\u309F\u30A0-\u30FF]/;
    const reHangul = /[\uAC00-\uD7AF]/;
    const reHan    = /[\u3400-\u4DBF\u4E00-\u9FFF]/;
    const reLatin  = /^[A-Za-z\u00C0-\u024F\-\u2010\u2011\u2013'\u2018\u2019]+$/;
    const matches = [];
    for (const { segment, index, isWordLike } of seg.segment(text)) {
      if (!isWordLike) continue;
      const raw = segment;
      if (!raw.trim()) continue;
      if (isJunkToken(raw)) continue;
      const lower = normHyphen(raw.toLowerCase());
      if (isWordIgnored(lower)) continue;
      const card = vocabByWord.get(lower);
      if (card && (card.level || 1) < KNOWN_LEVEL) {
        // Saved cards always win — user explicitly curated them.
        matches.push({ start: index, end: index + raw.length, raw, card, kind: 'card' });
        continue;
      }
      if (!unknownMode) continue;
      if (card && (card.level || 1) >= KNOWN_LEVEL) continue;
      if (knownSet.has(lower)) continue;
      if (useJaStop && STOP_WORDS_JA.has(raw)) continue;
      if (useEnStop && STOP_WORDS_EN.has(lower)) continue;

      // Script gate: only flag as "unknown" when the token's script maps to
      // one of the active source languages. Prevents Chinese pages from
      // getting painted blue when the user only selected en + ja.
      const tokKana   = reKana.test(raw);
      const tokHangul = reHangul.test(raw);
      const tokHan    = reHan.test(raw) && !tokKana;  // pure Han, no kana
      const tokLatin  = reLatin.test(raw);
      let scriptActive = false;
      if (tokKana)   scriptActive = jaActive;
      else if (tokHangul) scriptActive = koActive;
      else if (tokHan) {
        if (pageL === 'ja') scriptActive = jaActive;
        else if (pageL === 'zh' || pageL === 'zh-TW') scriptActive = zhActive;
        else scriptActive = zhActive || (jaActive && hasKanaNearby);
      }
      else if (tokLatin) scriptActive = anyLatinActive;
      if (!scriptActive) continue;

      // Latin sub-length guard (only for Latin tokens). CJK tokens with
      // 1 kanji (e.g. 目 / 山 / 水) stay highlightable.
      if (tokLatin && raw.length < 3) continue;

      matches.push({ start: index, end: index + raw.length, raw, kind: 'unknown' });
    }
    if (!matches.length) return;
    applyMatches(node, text, matches);
  }

  function applyMatches(node, text, matches) {
    const frag = document.createDocumentFragment();
    let cursor = 0;
    for (const mm of matches) {
      if (mm.start > cursor) frag.append(document.createTextNode(text.slice(cursor, mm.start)));
      const span = document.createElement('span');
      if (mm.kind === 'card') {
        const lvl = mm.card.level || 1;
        span.className = `linguaflow-highlight linguaflow-level-${lvl}`;
        span.dataset.lfId = mm.card.id;
      } else {
        span.className = 'linguaflow-highlight linguaflow-unknown';
      }
      if (mm.fullWord) span.dataset.lfWord = mm.fullWord;
      span.textContent = mm.raw;
      frag.append(span);
      cursor = mm.end;
    }
    if (cursor < text.length) frag.append(document.createTextNode(text.slice(cursor)));
    node.parentNode.replaceChild(frag, node);
  }

  function removeHighlights() {
    document.querySelectorAll('.linguaflow-highlight').forEach(span => {
      const parent = span.parentNode;
      if (!parent) return;
      parent.replaceChild(document.createTextNode(span.textContent), span);
      parent.normalize();
    });
  }

  const mo = new MutationObserver(() => scheduleHighlight());

  // ============================================================
  // YouTube caption enhancement
  // Watches YouTube's native caption segments and wraps each content word
  // with the same .linguaflow-highlight machinery used on regular pages.
  // ============================================================
  function isYouTubeWatch() {
    return location.hostname.endsWith('youtube.com') && location.pathname === '/watch';
  }

  let ytCaptionObserver = null;
  let ytCaptionPollTimer = null;

  function attachCaptionObserver() {
    if (ytCaptionObserver) { ytCaptionObserver.disconnect(); ytCaptionObserver = null; }
    if (ytCaptionPollTimer) clearInterval(ytCaptionPollTimer);
    if (settings.enabled === false || settings.youtubeCaption === false) return;
    if (!isYouTubeWatch()) return;

    ytCaptionPollTimer = setInterval(() => {
      const container = document.querySelector(
        '.caption-window, #ytp-caption-window-bottom, .ytp-caption-window-container'
      );
      if (!container) return;
      clearInterval(ytCaptionPollTimer); ytCaptionPollTimer = null;

      if (settings.youtubeBionic) ensureYouTubeBionicStyle();
      const process = () => {
        const segs = container.querySelectorAll('.ytp-caption-segment');
        for (const seg of segs) renderCaptionFast(seg);
      };

      ytCaptionObserver = new MutationObserver(process);
      ytCaptionObserver.observe(container, { childList: true, subtree: true, characterData: true });
      process(); // initial pass for anything already rendered
    }, 600);
    setTimeout(() => {
      if (ytCaptionPollTimer) {
        clearInterval(ytCaptionPollTimer);
        ytCaptionPollTimer = null;
      }
    }, 30000);

    // LLM punctuation: if enabled, accumulate caption text + send to LLM periodically.
    // Replaces the newest caption segment with a punctuated version in-place.
    if (settings.youtubeCaptionFix && ['deepseek','openai','qwen','gemini','claude','custom'].includes(settings.translator)) {
      installCaptionPunctuation();
    }
  }

  const capPunctCache = new Map();
  let capPunctTimer = null;
  function installCaptionPunctuation() {
    // When a new segment arrives, debounce 3s then punctuate it.
    const punctuateOne = async (seg) => {
      if (!seg.isConnected) return;
      const text = seg.textContent.trim();
      if (!text || text.length < 25) return;
      const periods = (text.match(/[.!?,]/g) || []).length;
      if (periods >= Math.max(2, Math.floor(text.length / 40))) return; // already punctuated
      if (capPunctCache.has(text)) {
        applyPunctuated(seg, capPunctCache.get(text));
        return;
      }
      const res = await safeSendMessage({ type: 'punctuateText', text });
      if (res?.ok && res.text && res.text !== text) {
        capPunctCache.set(text, res.text);
        applyPunctuated(seg, res.text);
      }
    };
    const scheduleFor = (seg) => {
      clearTimeout(capPunctTimer);
      capPunctTimer = setTimeout(() => punctuateOne(seg), 3000);
    };
    // Hook into the existing observer by monkey-watching the caption container.
    const tick = setInterval(() => {
      const segs = document.querySelectorAll('.ytp-caption-segment[data-lf-cap]:not([data-lf-punct])');
      if (!segs.length) return;
      const latest = segs[segs.length - 1];
      latest.setAttribute('data-lf-punct', '1');
      scheduleFor(latest);
    }, 1500);
    setTimeout(() => clearInterval(tick), 60 * 60 * 1000); // stop after 1h
  }
  function applyPunctuated(seg, newText) {
    seg.textContent = newText;
    seg.__lfLastText = null;        // force re-render on the new text
    try { renderCaptionFast(seg); } catch {}
  }

  function initYouTubeSpaNav() {
    if (!location.hostname.endsWith('youtube.com')) return;
    let lastHref = location.href;
    // YouTube is a SPA — URL changes without page reload. Re-attach on every
    // route change so each new /watch video gets its own observer.
    new MutationObserver(() => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        attachCaptionObserver();
      }
    }).observe(document.documentElement, { subtree: true, childList: true });
  }

  // ============================================================
  // Due-cards banner — soft nudge to review without context switch
  // ============================================================
  async function maybeShowDueBanner() {
    if (!isAlive()) return;
    if (settings.enabled === false) return;
    if (sessionStorage.getItem('lf-due-dismissed')) return;
    try {
      const { vocabulary = {} } = await chrome.storage.local.get('vocabulary');
      const now = Date.now();
      const due = Object.values(vocabulary).filter(c =>
        c.lang === settings.sourceLang && (c.level || 1) < 5 && (c.due || 0) <= now
      ).length;
      if (due < 3) return;
      showDueBanner(due);
    } catch {}
  }
  function showDueBanner(count) {
    if (document.getElementById('linguaflow-due-banner')) return;
    const b = document.createElement('div');
    b.id = 'linguaflow-due-banner';
    Object.assign(b.style, {
      all: 'initial', position: 'fixed', bottom: '20px', right: '20px',
      zIndex: '2147483645', background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
      color: '#fff', padding: '10px 14px', borderRadius: '8px',
      font: '13px -apple-system, BlinkMacSystemFont, system-ui, sans-serif',
      boxShadow: '0 8px 24px rgba(0,0,0,.25)', cursor: 'pointer',
      display: 'flex', gap: '10px', alignItems: 'center', maxWidth: '300px'
    });
    const text = document.createElement('span');
    text.textContent = `📚 ${count} cards due · Start review`;
    text.style.flex = '1';
    const close = document.createElement('span');
    close.textContent = '✕';
    Object.assign(close.style, { opacity: '0.7', padding: '0 4px', cursor: 'pointer' });
    close.onclick = (e) => {
      e.stopPropagation();
      sessionStorage.setItem('lf-due-dismissed', '1');
      b.remove();
    };
    b.onclick = async () => {
      b.remove();
      openInlineReview();
    };
    b.append(text, close);
    (document.body || document.documentElement).appendChild(b);
    setTimeout(() => b.remove(), 25000);
  }

  // ============================================================
  // Inline review — floating FSRS review panel without leaving the page
  // ============================================================
  async function openInlineReview() {
    const res = await safeSendMessage({ type: 'reviewPickDue' });
    if (!res?.ok || !res.cards?.length) return;
    renderInlineReview(res.cards);
  }

  function renderInlineReview(queue) {
    if (document.getElementById('lf-review-host')) return;
    const host = document.createElement('div');
    host.id = 'lf-review-host';
    host.style.cssText = 'all: initial; position: fixed; top: 50%; right: 24px;'
      + ' transform: translateY(-50%); z-index: 2147483645;';
    const shadow = host.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        .panel {
          width: 360px; max-width: 92vw;
          background: #ffffff; color: #111827;
          border: 1px solid #e5e7eb; border-radius: 8px;
          box-shadow: 0 18px 50px rgba(0,0,0,.22);
          font: 14px/1.45 -apple-system, BlinkMacSystemFont, system-ui, "PingFang SC", sans-serif;
          padding: 16px 18px;
        }
        .head { display: flex; align-items: center; justify-content: space-between; font-size: 12px; color: #6b7280; margin-bottom: 6px; }
        .head button { background: transparent; border: 0; cursor: pointer; font-size: 16px; color: #6b7280; }
        .bar { height: 4px; background: #e5e7eb; border-radius: 3px; overflow: hidden; margin-bottom: 14px; }
        .bar .fill { height: 100%; background: #2563eb; transition: width .25s; }
        .word { font-size: 28px; font-weight: 700; text-align: center; padding: 28px 10px 18px; word-break: break-word; }
        .reveal { display: block; margin: 0 auto; padding: 8px 28px; border-radius: 8px;
          background: #2563eb; color: #fff; border: 0; cursor: pointer; font: inherit; font-weight: 600; }
        .trans { font-size: 18px; text-align: center; padding: 4px 0 12px; }
        .ctx { font-size: 12px; color: #6b7280; text-align: center; padding: 0 8px 14px; border-bottom: 1px dashed #e5e7eb; margin-bottom: 14px; white-space: pre-wrap; }
        .ctx:empty { display: none; }
        .ratings { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; }
        .ratings button { padding: 10px 0; border: 0; color: #fff; border-radius: 8px; font: inherit; font-weight: 600; cursor: pointer; }
        .ratings button span { display: block; font-size: 10px; opacity: .85; margin-top: 2px; font-weight: 400; }
        .ratings .r1 { background: #ef4444; }
        .ratings .r2 { background: #f59e0b; }
        .ratings .r3 { background: #10b981; }
        .ratings .r4 { background: #3b82f6; }
        .done { text-align: center; padding: 30px 0; font-size: 16px; }
        .hints { font-size: 11px; color: #9ca3af; text-align: center; margin-top: 10px; }
        .hints kbd { padding: 1px 5px; border: 1px solid #d1d5db; border-radius: 3px; background: #f3f4f6; font: 10px ui-monospace, monospace; }
        @media (prefers-color-scheme: dark) {
          .panel { background: #1f2937; color: #f9fafb; border-color: #374151; }
          .head, .hints { color: #9ca3af; }
          .bar { background: #374151; }
          .ctx { color: #9ca3af; border-bottom-color: #374151; }
        }
      </style>
      <div class="panel" id="panel"></div>
    `;
    document.documentElement.appendChild(host);

    let index = 0, revealed = false;

    const draw = () => {
      const panel = shadow.getElementById('panel');
      if (index >= queue.length) {
        panel.innerHTML = `<div class="done">🎉 All done · ${queue.length} cards reviewed<br><br><button class="reveal" id="lf-close">Close</button></div>`;
        shadow.getElementById('lf-close').onclick = close;
        setTimeout(close, 3500);
        return;
      }
      const c = queue[index];
      const ratings = ['Again','Hard','Good','Easy'];
      panel.innerHTML = `
        <div class="head">
          <span>Review · ${index+1} / ${queue.length}</span>
          <button id="lf-close" title="Close">✕</button>
        </div>
        <div class="bar"><div class="fill" style="width:${(index/queue.length*100).toFixed(0)}%"></div></div>
        <div class="word" id="lf-word"></div>
        ${revealed ? `
          <div class="trans" id="lf-trans"></div>
          <div class="ctx" id="lf-ctx"></div>
          <div class="ratings">
            ${ratings.map((lbl,i) => `<button class="r${i+1}" data-r="${i+1}">${lbl}<span>${i+1}</span></button>`).join('')}
          </div>
          <div class="hints"><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd><kbd>4</kbd> to rate · <kbd>Esc</kbd> close</div>
        ` : `
          <button class="reveal" id="lf-reveal">Show answer</button>
          <div class="hints"><kbd>Space</kbd> reveal · <kbd>Esc</kbd> close</div>
        `}
      `;
      shadow.getElementById('lf-word').textContent = c.word;
      shadow.getElementById('lf-close').onclick = close;
      if (!revealed) {
        shadow.getElementById('lf-reveal').onclick = reveal;
      } else {
        shadow.getElementById('lf-trans').textContent = c.translation || '';
        shadow.getElementById('lf-ctx').textContent = c.context || '';
        shadow.querySelectorAll('.ratings button').forEach(b => {
          b.onclick = () => rate(Number(b.dataset.r));
        });
      }
    };
    const reveal = () => { revealed = true; draw(); };
    const rate = async (r) => {
      const c = queue[index];
      safeSendMessage({ type: 'reviewRate', id: c.id, rating: r });
      index++; revealed = false;
      draw();
    };
    const close = () => { host.remove(); document.removeEventListener('keydown', onKey, true); };
    const onKey = (e) => {
      if (e.key === 'Escape') { close(); return; }
      if (!revealed && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); reveal(); return; }
      if (revealed && ['1','2','3','4'].includes(e.key)) { e.preventDefault(); rate(Number(e.key)); }
    };
    document.addEventListener('keydown', onKey, true);
    draw();
  }

  // ============================================================
  // Bionic Reading — bold the first half of each content word
  // ============================================================
  function applyBionic() {
    if (settings.bionicReading !== true) return;
    if (!document.body) return;
    // No body-wide guard — the function is idempotent via per-node checks
    // (skip text inside or adjacent to an existing <b.lf-bionic>). This lets
    // later highlight+Bionic cycles pick up content that hydrated after the
    // first pass without double-wrapping already-processed words.

    // Inject a high-specificity style so page CSS can't nullify our bolding.
    if (!document.getElementById('lf-bionic-style')) {
      const s = document.createElement('style');
      s.id = 'lf-bionic-style';
      s.textContent = `b.lf-bionic, b.lf-bionic * { font-weight: 700 !important; }`;
      (document.head || document.documentElement).appendChild(s);
    }

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentNode;
        if (!p || !(p instanceof Element)) return NodeFilter.FILTER_REJECT;
        const tag = p.tagName;
        // Hard skips: non-content / already-rewritten / interactive.
        if (['SCRIPT','STYLE','CODE','PRE','TEXTAREA','INPUT','NOSCRIPT','B','STRONG','KBD','SAMP','VAR','SVG','CANVAS','MATH'].includes(tag)) return NodeFilter.FILTER_REJECT;
        if (p.closest('#linguaflow-host, #lf-review-host, [contenteditable="true"], nav, header[role], button, [role="button"], [role="navigation"]')) return NodeFilter.FILTER_REJECT;
        // Skip tails of already-split words (prev sibling is our own <b.lf-bionic>).
        const prev = node.previousSibling;
        if (prev && prev.nodeType === 1 && prev.tagName === 'B' && prev.classList &&
            (prev.classList.contains('lf-bionic') || prev.classList.contains('lf-bionic-yt'))) return NodeFilter.FILTER_REJECT;
        const txt = node.nodeValue;
        if (!txt || !txt.trim()) return NodeFilter.FILTER_REJECT;
        // Require at least one letter (skip pure punctuation / numbers).
        if (!/[A-Za-z\u00C0-\u024F\u0400-\u04FF]/.test(txt)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = []; let n, count = 0;
    while ((n = walker.nextNode()) && count++ < 6000) nodes.push(n);
    let wrapped = 0;
    for (const node of nodes) {
      if (!node.parentNode) continue;
      const frag = document.createDocumentFragment();
      // Match Latin + Cyrillic runs only. Bionic doesn't make sense on CJK
      // (halving a 2-char kanji word = 1 char bolded) and would also get in
      // the way of Japanese segmentation/click-to-translate.
      const rx = /([A-Za-z\u00C0-\u024F\u0400-\u04FF]+)|([^A-Za-z\u00C0-\u024F\u0400-\u04FF]+)/g;
      let m;
      while ((m = rx.exec(node.nodeValue)) !== null) {
        if (m[1]) {
          const word = m[1];
          if (word.length < 2) { frag.append(document.createTextNode(word)); continue; }
          const half = Math.max(1, Math.ceil(word.length * 0.5));
          const b = document.createElement('b');
          b.className = 'lf-bionic';
          b.textContent = word.slice(0, half);
          frag.append(b, document.createTextNode(word.slice(half)));
          wrapped++;
        } else {
          frag.append(document.createTextNode(m[2]));
        }
      }
      try { node.parentNode.replaceChild(frag, node); } catch {}
    }
  }
  function removeBionic() {
    if (document.body?.dataset) delete document.body.dataset.lfBionic;
    document.getElementById('lf-bionic-style')?.remove();
    document.querySelectorAll('b.lf-bionic').forEach(b => {
      const p = b.parentNode;
      if (!p) return;
      p.replaceChild(document.createTextNode(b.textContent), b);
      p.normalize();
    });
  }

  // Apply Bionic to a single root (no body-wide guard), wrapping each word's
  // first half in `<b class="${className}">`. Used by the YouTube-caption pass
  // where we want per-segment control and a distinct (orange) style.
  function applyBionicToRoot(root, className) {
    if (!root) return 0;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentNode;
        if (!p || !(p instanceof Element)) return NodeFilter.FILTER_REJECT;
        const tag = p.tagName;
        if (['SCRIPT','STYLE','CODE','PRE','B','STRONG','NOSCRIPT'].includes(tag)) return NodeFilter.FILTER_REJECT;
        const txt = node.nodeValue;
        if (!txt || !txt.trim()) return NodeFilter.FILTER_REJECT;
        if (!/[A-Za-z\u00C0-\u024F\u0400-\u04FF]/.test(txt)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = []; let n;
    while ((n = walker.nextNode())) nodes.push(n);
    let wrapped = 0;
    for (const node of nodes) {
      if (!node.parentNode) continue;
      const frag = document.createDocumentFragment();
      const rx = /([A-Za-z\u00C0-\u024F\u0400-\u04FF]+)|([^A-Za-z\u00C0-\u024F\u0400-\u04FF]+)/g;
      let m;
      while ((m = rx.exec(node.nodeValue)) !== null) {
        if (m[1]) {
          const word = m[1];
          if (word.length < 2) { frag.append(document.createTextNode(word)); continue; }
          const half = Math.max(1, Math.ceil(word.length * 0.5));
          const b = document.createElement('b');
          b.className = className;
          b.textContent = word.slice(0, half);
          frag.append(b, document.createTextNode(word.slice(half)));
          wrapped++;
        } else {
          frag.append(document.createTextNode(m[2]));
        }
      }
      try { node.parentNode.replaceChild(frag, node); } catch {}
    }
    return wrapped;
  }

  // Inject the orange style once for YouTube caption Bionic. High specificity
  // plus !important so YouTube's own caption CSS can't override it.
  function ensureYouTubeBionicStyle() {
    if (document.getElementById('lf-bionic-yt-style')) return;
    const s = document.createElement('style');
    s.id = 'lf-bionic-yt-style';
    s.textContent = `b.lf-bionic-yt, b.lf-bionic-yt * { color: #f97316 !important; font-weight: 700 !important; }`;
    (document.head || document.documentElement).appendChild(s);
  }

  // ============================================================
  // Fast single-pass caption render — avoids the two-TreeWalker dance
  // (highlight + Bionic) that was too slow for rapid YT captions.
  // Builds one HTML string, assigns via innerHTML. Guarded by a text-
  // content signature so YouTube's in-place textContent updates (common
  // with live auto-captions) still re-trigger a redraw.
  // ============================================================
  function captionModeKey() {
    return `${settings.highlightMode || 'off'}|${settings.youtubeBionic ? 1 : 0}|${activeSourceLangs().join(',')}`;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  // Iterates tokens in `text`. Each yielded entry is { seg, isWordLike }.
  // Uses Intl.Segmenter for any-CJK-active pages; Latin regex otherwise.
  function* captionTokens(text) {
    if (anyActiveCJK()) {
      const active = activeSourceLangs();
      const segLang = CJK_LANGS.has(settings.sourceLang) ? settings.sourceLang
                      : active.find(l => CJK_LANGS.has(l));
      const seg = getWordSegmenter(segLang);
      if (!seg) { yield { seg: text, isWordLike: false }; return; }
      for (const { segment, isWordLike } of seg.segment(text)) {
        yield { seg: segment, isWordLike };
      }
      return;
    }
    const rx = /\b([A-Za-z\u00C0-\u024F][A-Za-z\u00C0-\u024F\-\u2010\u2011\u2013'\u2018\u2019]{1,})\b/g;
    let m, cursor = 0;
    while ((m = rx.exec(text)) !== null) {
      if (m.index > cursor) yield { seg: text.slice(cursor, m.index), isWordLike: false };
      yield { seg: m[0], isWordLike: true };
      cursor = m.index + m[0].length;
    }
    if (cursor < text.length) yield { seg: text.slice(cursor), isWordLike: false };
  }

  function buildCaptionHtml(text) {
    const bionic      = !!settings.youtubeBionic;
    const highlightOn = settings.highlightMode !== 'off' && settings.enabled !== false;
    const unknownMode = settings.highlightMode === 'unknown';
    const active      = activeSourceLangs();
    const useEnStop   = active.includes('en');
    const useJaStop   = active.includes('ja');
    const zhActive    = active.includes('zh') || active.includes('zh-TW');
    const jaActive    = active.includes('ja');
    const koActive    = active.includes('ko');
    const anyLatinActive = active.some(l => LATIN_LANG_CODES.has(l));
    const hasKanaNearby  = /[\u3040-\u309F\u30A0-\u30FF]/.test(text);
    const latinRx     = /^[A-Za-z\u00C0-\u024F\u0400-\u04FF]+$/;
    const latinOnlyRx = /^[A-Za-z\u00C0-\u024F\-\u2010\u2011\u2013'\u2018\u2019]+$/;
    const reKana      = /[\u3040-\u309F\u30A0-\u30FF]/;
    const reHangul    = /[\uAC00-\uD7AF]/;
    const reHan       = /[\u3400-\u4DBF\u4E00-\u9FFF]/;

    let html = '';
    for (const { seg: tok, isWordLike } of captionTokens(text)) {
      if (!isWordLike) { html += escapeHtml(tok); continue; }

      const lower = normHyphen(tok.toLowerCase());
      const card  = vocabByWord.get(lower);
      let wrapOpen = '', wrapClose = '';

      if (highlightOn) {
        if (card && (card.level || 1) < KNOWN_LEVEL) {
          const lvl = card.level || 1;
          wrapOpen  = `<span class="linguaflow-highlight linguaflow-level-${lvl}" data-lf-id="${escapeHtml(card.id)}">`;
          wrapClose = '</span>';
        } else if (unknownMode) {
          // Script-gate: same rule as highlightNodeCJK — don't flag tokens
          // whose script doesn't belong to any active source lang.
          const tokKana   = reKana.test(tok);
          const tokHangul = reHangul.test(tok);
          const tokHan    = reHan.test(tok) && !tokKana;
          const tokLatin  = latinOnlyRx.test(tok);
          const pageL     = pageLanguage();
          let scriptActive = false;
          if (tokKana) scriptActive = jaActive;
          else if (tokHangul) scriptActive = koActive;
          else if (tokHan) {
            if (pageL === 'ja') scriptActive = jaActive;
            else if (pageL === 'zh' || pageL === 'zh-TW') scriptActive = zhActive;
            else scriptActive = zhActive || (jaActive && hasKanaNearby);
          }
          else if (tokLatin)  scriptActive = anyLatinActive;
          const skip =
            !scriptActive ||
            isWordIgnored(lower) ||
            (card && (card.level || 1) >= KNOWN_LEVEL) ||
            knownSet.has(lower) ||
            (useEnStop && STOP_WORDS_EN.has(lower)) ||
            (useJaStop && STOP_WORDS_JA.has(tok)) ||
            (tokLatin && tok.length < 3);
          if (!skip) {
            wrapOpen  = `<span class="linguaflow-highlight linguaflow-unknown">`;
            wrapClose = '</span>';
          }
        }
      }

      // Bionic only for Latin/Cyrillic tokens ≥ 2 chars (skips kanji/kana).
      let body;
      if (bionic && tok.length >= 2 && latinRx.test(tok)) {
        const half = Math.max(1, Math.ceil(tok.length / 2));
        body = `<b class="lf-bionic-yt">${escapeHtml(tok.slice(0, half))}</b>${escapeHtml(tok.slice(half))}`;
      } else {
        body = escapeHtml(tok);
      }
      html += wrapOpen + body + wrapClose;
    }
    return html;
  }

  function renderCaptionFast(seg) {
    const text = seg.textContent || '';
    if (!text.trim()) return;
    const mode = captionModeKey();
    if (seg.__lfLastText === text && seg.__lfLastMode === mode) return;
    seg.innerHTML = buildCaptionHtml(text);
    seg.__lfLastText = text;
    seg.__lfLastMode = mode;
    // Keep the legacy marker for the LLM-punctuation selector below.
    seg.setAttribute('data-lf-cap', '1');
  }

  // ============================================================
  // Cloze mode — replace saved words with fill-in inputs
  // ============================================================
  let clozeOn = false;
  function toggleCloze() {
    if (clozeOn) { exitCloze(); } else { enterCloze(); }
  }
  function enterCloze() {
    if (clozeOn) return;
    clozeOn = true;
    // Inject input styles once
    if (!document.getElementById('lf-cloze-style')) {
      const s = document.createElement('style');
      s.id = 'lf-cloze-style';
      s.textContent = `
        input.lf-cloze {
          font: inherit; padding: 1px 6px; margin: 0 1px;
          border: 1px solid #6b7280; border-radius: 4px; background: #fef3c7; color: #111827;
          outline: none; min-width: 40px;
        }
        input.lf-cloze.correct { background: #d1fae5; border-color: #10b981; color: #065f46; }
        input.lf-cloze.wrong   { background: #fee2e2; border-color: #ef4444; color: #991b1b; }
        @media (prefers-color-scheme: dark) {
          input.lf-cloze { background: #44403c; color: #fef3c7; border-color: #a1a1aa; }
          input.lf-cloze.correct { background: rgba(16,185,129,.3); color: #a7f3d0; }
          input.lf-cloze.wrong   { background: rgba(239,68,68,.3);  color: #fecaca; }
        }`;
      document.head.appendChild(s);
    }
    // Only blank words at levels 1-3 (learning / familiar / recognized).
    const spans = document.querySelectorAll('.linguaflow-highlight');
    for (const span of spans) {
      if (!span.dataset.lfId) continue;
      const card = vocabById.get(span.dataset.lfId);
      if (!card) continue;
      const lvl = card.level || 1;
      if (lvl >= 4) continue;
      const word = span.textContent;
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'lf-cloze';
      input.size = Math.max(6, word.length + 1);
      input.dataset.lfWord = word;
      input.dataset.lfId = card.id;
      input.dataset.lfLevel = String(lvl);
      input.placeholder = '_'.repeat(Math.max(3, word.length));
      input.oninput = () => {
        const v = input.value.toLowerCase().trim();
        const t = word.toLowerCase();
        if (v === t) input.className = 'lf-cloze correct';
        else if (v && !t.startsWith(v)) input.className = 'lf-cloze wrong';
        else input.className = 'lf-cloze';
      };
      span.replaceWith(input);
    }
  }
  function exitCloze() {
    clozeOn = false;
    document.querySelectorAll('input.lf-cloze').forEach(i => {
      const word = i.dataset.lfWord;
      const card = i.dataset.lfId ? vocabById.get(i.dataset.lfId) : null;
      const lvl = card?.level || Number(i.dataset.lfLevel) || 1;
      const span = document.createElement('span');
      span.className = `linguaflow-highlight linguaflow-level-${lvl}`;
      if (card?.id || i.dataset.lfId) span.dataset.lfId = card?.id || i.dataset.lfId;
      span.textContent = word;
      i.replaceWith(span);
    });
  }

  // ============================================================
  // Word frequency analysis — triggered from popup via message
  // ============================================================
  function analyzePageFrequency() {
    if (!document.body) return [];
    const text = document.body.innerText || '';
    const counts = new Map();
    const isCJK = anyActiveCJK();
    if (isCJK) {
      const active = activeSourceLangs();
      const segLang = CJK_LANGS.has(settings.sourceLang) ? settings.sourceLang
                      : active.find(l => CJK_LANGS.has(l));
      const seg = getWordSegmenter(segLang);
      if (!seg) return [];
      const stop = active.includes('ja') ? STOP_WORDS_JA : null;
      for (const { segment, isWordLike } of seg.segment(text)) {
        if (!isWordLike) continue;
        const w = segment;
        if (!w.trim()) continue;
        if (stop && stop.has(w)) continue;
        if (knownSet.has(w.toLowerCase())) continue;
        const card = vocabByWord.get(w.toLowerCase());
        if (card && (card.level || 1) >= 4) continue;
        counts.set(w, (counts.get(w) || 0) + 1);
      }
    } else {
      const rx = /\b([A-Za-z\u00C0-\u024F][A-Za-z\u00C0-\u024F\-\u2010\u2011\u2013'\u2018\u2019]{1,})\b/g;
      let m;
      while ((m = rx.exec(text)) !== null) {
        const w = m[1].toLowerCase();
        if (STOP_WORDS_EN.has(w)) continue;
        if (w.length < 3) continue;
        if (knownSet.has(w)) continue;
        const card = vocabByWord.get(w);
        if (card && (card.level || 1) >= 4) continue;
        counts.set(w, (counts.get(w) || 0) + 1);
      }
    }
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 30)
      .map(([word, count]) => ({
        word, count,
        level: vocabByWord.get(word)?.level || 0
      }));
  }

  // ============================================================
  // Clipboard translation — triggered by keyboard shortcut
  // ============================================================
  async function translateClipboard() {
    let text = '';
    try { text = await navigator.clipboard.readText(); } catch { return; }
    text = (text || '').trim().slice(0, 400);
    if (!text) return;
    const existing = vocabByWord.get(text.toLowerCase());
    const state = {
      word: text,
      lang: existing?.lang || detectLangOf(text),
      translation: existing ? existing.translation : '…translating clipboard…',
      saved: !!existing, card: existing || null,
      context: '', provider: existing ? 'saved' : ''
    };
    render(state);
    // Place near top-center of viewport
    showTip(Math.round(window.innerWidth / 2 - 180), 40);
    speak(text, state.lang);
    if (existing) return;
    const sentence = text; // clipboard itself is the context
    const res = await streamTranslate({
      text, sentence, from: state.lang,
      onUpdate: (partial) => {
        if (partial.translation) state.translation = partial.translation;
        if (partial.note) state.note = partial.note;
        if (partial.pos) state.pos = partial.pos;
        if (partial.inflection) state.inflection = partial.inflection;
        if (partial.phrase) state.phrase = partial.phrase;
        if (partial.phraseMeaning) state.phraseMeaning = partial.phraseMeaning;
        state.aiContext = true;
        render(state);
      }
    });
    if (res && res.ok) applyTranslation(state, res);
    else state.translation = res?.error || 'Translation failed';
    render(state);
  }

  // Extend existing message listener (chrome.runtime.onMessage is registered
  // once elsewhere; we listen again for the new message types).
  try { chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    try {
      if (msg.type === 'translateClipboard') {
        translateClipboard().catch(() => {});
      } else if (msg.type === 'analyzePageFrequency') {
        sendResponse({ ok: true, words: analyzePageFrequency() });
      } else if (msg.type === 'quickSaveWord') {
        localSaveCard({ word: msg.word, translation: '', context: '', source: location.href })
          .then(card => sendResponse({ ok: true, card }))
          .catch(() => sendResponse({ ok: false }));
        return true;
      } else if (msg.type === 'toggleCloze') {
        toggleCloze();
        sendResponse({ ok: true, on: clozeOn });
      } else if (msg.type === 'openReviewPanel') {
        openInlineReview();
        sendResponse({ ok: true });
      }
    } catch (e) { /* content script message handler error — silent */ }
  }); } catch {}

  // ---- Boot ----
  loadState().then(() => {
    document.documentElement.appendChild(host);
    scheduleHighlight();
    if (document.body) mo.observe(document.body, { childList: true, subtree: true });
    initYouTubeSpaNav();
    attachCaptionObserver();
    setTimeout(maybeShowDueBanner, 1500);
  }).catch(() => {});
})();
