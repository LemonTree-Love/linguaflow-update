import { getSettings, getVocabulary, setCardLevel, deleteCard, newCard, saveCard, activeSourceLangs } from '../lib/storage.js';
import { LANGUAGES } from '../lib/languages.js';
import { cardsToCSV } from '../lib/anki-export.js';

const $ = (id) => document.getElementById(id);
let settings;
let vocab = {};
let filterLevel = 'all';
let langFilter = 'all';   // 'all' | one lang code. Scopes the whole list.
let sortBy = 'created-desc';
let selected = new Set();
let levelMenu = null;

const LEVEL_LABELS = {
  1: 'New',
  2: 'Familiar',
  3: 'Recog.',
  4: 'Almost',
  5: 'Mastered'
};
const LEVEL_MARKS = { 1: '①', 2: '②', 3: '③', 4: '④', 5: '⑤' };

async function boot() {
  settings = await getSettings();
  vocab = await getVocabulary();

  // Seed the language dropdown in the import dialog.
  $('import-lang').innerHTML = LANGUAGES.map(l => `<option value="${l.code}">${l.name} (${l.code})</option>`).join('');
  $('import-lang').value = settings.sourceLang;

  // Pick up initial filters from URL hash: #level=3&lang=ja
  const mLvl = location.hash.match(/level=(\d+|sentences|all)/);
  if (mLvl) filterLevel = mLvl[1];
  const mLang = location.hash.match(/lang=([\w-]+)/);
  if (mLang) langFilter = mLang[1];

  renderLangTabs();
  wireFilters();
  wireSearch();
  wireSort();
  wireBulkActions();
  wireImport();
  wireExport();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.vocabulary) {
      vocab = changes.vocabulary.newValue || {};
    }
    if (changes.settings) {
      settings = { ...settings, ...(changes.settings.newValue || {}) };
      renderLangTabs();
    }
    render();
  });

  render();
}

function languageLabel(code) {
  const lang = LANGUAGES.find(l => l.code === code);
  return lang ? lang.name : code.toUpperCase();
}

// Render language tabs row — one button per active source lang + "All". Hidden
// when only a single language is active (no need to clutter the UI).
function renderLangTabs() {
  const wrap = $('lang-tabs');
  const langs = activeSourceLangs(settings);
  if (langs.length <= 1) {
    wrap.hidden = true;
    wrap.innerHTML = '';
    langFilter = 'all';
    return;
  }
  // Drop a stale langFilter if the previously-filtered lang is no longer active.
  if (langFilter !== 'all' && !langs.includes(langFilter)) langFilter = 'all';
  wrap.hidden = false;
  const mkBtn = (code, label) => {
    const b = document.createElement('button');
    b.className = 'lang-tab' + (code === langFilter ? ' active' : '');
    b.dataset.lang = code;
    const total = Object.values(vocab).filter(c =>
      code === 'all' ? langs.includes(c.lang) : c.lang === code
    ).length;
    b.innerHTML = `${label} <span class="cnt">${total}</span>`;
    b.addEventListener('click', () => {
      langFilter = code;
      for (const x of wrap.querySelectorAll('.lang-tab')) x.classList.toggle('active', x === b);
      selected.clear();
      // When switching to a specific lang, re-default the import dialog lang too.
      if (code !== 'all') $('import-lang').value = code;
      updateHash();
      render();
    });
    return b;
  };
  wrap.innerHTML = '';
  wrap.append(mkBtn('all', 'All'));
  for (const l of langs) wrap.append(mkBtn(l, languageLabel(l)));
}

function updateHash() {
  const parts = [];
  if (filterLevel !== 'all') parts.push(`level=${filterLevel}`);
  if (langFilter !== 'all')  parts.push(`lang=${langFilter}`);
  location.hash = parts.join('&');
}

// Keep tab counts in sync after vocab mutations without re-binding handlers.
function refreshLangTabCounts() {
  const wrap = $('lang-tabs');
  if (!wrap || wrap.hidden) return;
  const langs = activeSourceLangs(settings);
  for (const btn of wrap.querySelectorAll('.lang-tab')) {
    const code = btn.dataset.lang;
    const total = Object.values(vocab).filter(c =>
      code === 'all' ? langs.includes(c.lang) : c.lang === code
    ).length;
    const cnt = btn.querySelector('.cnt');
    if (cnt) cnt.textContent = total;
  }
}

function wireFilters() {
  for (const b of document.querySelectorAll('.flt')) {
    if (b.dataset.lvl === filterLevel) b.classList.add('active');
    else b.classList.remove('active');
    b.addEventListener('click', () => {
      filterLevel = b.dataset.lvl;
      for (const x of document.querySelectorAll('.flt')) x.classList.toggle('active', x === b);
      selected.clear();
      updateHash();
      render();
    });
  }
}

function wireSearch() {
  $('search').addEventListener('input', () => render());
}

function wireSort() {
  $('sortBy').value = sortBy;
  $('sortBy').addEventListener('change', (e) => {
    sortBy = e.target.value;
    render();
  });
}

function wireBulkActions() {
  $('bulk-level').addEventListener('change', async (e) => {
    const lvl = Number(e.target.value);
    if (!lvl) return;
    const ids = [...selected];
    for (const id of ids) await setCardLevel(id, lvl);
    selected.clear();
    toast(`Updated ${ids.length} card(s)`);
    e.target.value = '';
    render();
  });
  $('bulk-delete').addEventListener('click', async () => {
    if (!selected.size) return;
    const ids = [...selected];
    if (!confirm(`Delete ${ids.length} card(s)? This cannot be undone.`)) return;
    for (const id of ids) await deleteCard(id);
    toast(`Deleted ${ids.length}`);
    selected.clear();
    render();
  });
  $('bulk-clear').addEventListener('click', () => { selected.clear(); render(); });
  $('select-all').addEventListener('change', (e) => {
    const rows = visibleCards();
    if (e.target.checked) rows.forEach(c => selected.add(c.id));
    else selected.clear();
    render();
  });
}

function wireExport() {
  $('exportCsv').addEventListener('click', () => {
    const cards = visibleCards();
    if (!cards.length) return;
    const csv = cardsToCSV(cards);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const stamp = langFilter === 'all' ? activeSourceLangs(settings).join('-') : langFilter;
    a.download = `linguaflow-${stamp}-${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
}

function wireImport() {
  $('importTxt').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', async (e) => {
    const file = e.target.files[0]; if (!file) return;
    const text = await file.text();
    e.target.value = '';
    openImportDialog(file.name, text);
  });

  $('import-sep').addEventListener('change', () => renderImportPreview());
  $('import-dialog').addEventListener('close', async (e) => {
    if ($('import-dialog').returnValue !== 'ok') return;
    await doImport();
  });
}

let _importText = '';
function openImportDialog(filename, text) {
  _importText = text;
  $('import-filename').textContent = filename + ` (${text.length} chars)`;
  renderImportPreview();
  $('import-dialog').showModal();
}

function parseImportText() {
  const sepCode = $('import-sep').value;
  const sep = sepCode === '\\n' ? /\r?\n/ : sepCode === '\\t' ? /\t/ : /,/;
  return [...new Set(_importText.split(sep).map(s => s.trim()).filter(Boolean))];
}

function renderImportPreview() {
  const words = parseImportText();
  const preview = words.slice(0, 8).join('  ·  ') + (words.length > 8 ? `  … (+${words.length - 8} more)` : '');
  $('import-preview').textContent = `${words.length} word(s) detected:\n${preview}`;
}

async function doImport() {
  const words = parseImportText();
  const lang = $('import-lang').value;
  const level = Number($('import-level').value) || 1;
  const overwrite = $('import-overwrite').checked;
  if (!words.length) { toast('No words to import'); return; }

  let added = 0, skipped = 0;
  for (const w of words) {
    const card = newCard({ word: w, translation: '', lang, level });
    if (!overwrite && vocab[card.id]) { skipped++; continue; }
    await saveCard(card);
    added++;
  }
  toast(`Imported ${added}, skipped ${skipped}`);
}

// ---- Rendering ----

function matchesFilter(c) {
  const langs = activeSourceLangs(settings);
  if (langFilter === 'all') { if (!langs.includes(c.lang)) return false; }
  else { if (c.lang !== langFilter) return false; }
  const isSentence = c.type === 'sentence';
  if (filterLevel === 'sentences') { if (!isSentence) return false; }
  else if (filterLevel === 'all') { /* keep everything */ }
  else { if (isSentence) return false; if ((c.level || 1) !== Number(filterLevel)) return false; }
  const q = $('search').value.trim().toLowerCase();
  const haystack = [c.word, c.translation, c.context, c.source].join(' ').toLowerCase();
  if (q && !haystack.includes(q)) return false;
  return true;
}

function visibleCards() {
  const collator = new Intl.Collator(undefined, { sensitivity: 'base' });
  return Object.values(vocab).filter(matchesFilter).sort((a, b) => {
    if (sortBy === 'created-asc') return (a.createdAt || 0) - (b.createdAt || 0);
    if (sortBy === 'level-asc') return (a.level || 1) - (b.level || 1) || collator.compare(a.word, b.word);
    if (sortBy === 'level-desc') return (b.level || 1) - (a.level || 1) || collator.compare(a.word, b.word);
    if (sortBy === 'word-asc') return collator.compare(a.word, b.word);
    return (b.createdAt || 0) - (a.createdAt || 0);
  });
}

function render() {
  closeLevelMenu();
  for (const id of [...selected]) {
    if (!vocab[id]) selected.delete(id);
  }
  refreshLangTabCounts();
  // Counts — scoped to the active language tab (or union of all active langs
  // when "All" is selected). Level pill counts always reflect the current tab.
  const langs = new Set(activeSourceLangs(settings));
  const inTab = (c) => langFilter === 'all' ? langs.has(c.lang) : c.lang === langFilter;
  const mine = Object.values(vocab).filter(inTab);
  $('cnt-all').textContent = mine.length;
  const words = mine.filter(c => c.type !== 'sentence');
  for (const lvl of [1, 2, 3, 4, 5]) {
    $('cnt-' + lvl).textContent = words.filter(c => (c.level || 1) === lvl).length;
  }
  $('cnt-sent').textContent = mine.filter(c => c.type === 'sentence').length;

  const rows = visibleCards();
  const tbody = $('tbody');
  tbody.innerHTML = '';

  if (!rows.length) {
    const tr = document.createElement('tr');
    tr.className = 'empty-row';
    tr.innerHTML = `<td colspan="6">No words match this filter.</td>`;
    tbody.append(tr);
  } else {
    for (const c of rows) tbody.append(rowFor(c));
  }

  // Bulk bar visibility
  const any = selected.size > 0;
  $('bulk-bar').hidden = !any;
  $('sel-count').textContent = `${selected.size} selected`;
  $('select-all').checked = rows.length > 0 && rows.every(c => selected.has(c.id));
}

function rowFor(c) {
  const tr = document.createElement('tr');
  tr.className = `row-lvl-${c.level || 1}`;

  const tdSel = document.createElement('td');
  tdSel.className = 'col-sel';
  const cb = document.createElement('input'); cb.type = 'checkbox';
  cb.checked = selected.has(c.id);
  cb.addEventListener('change', (e) => {
    if (e.target.checked) selected.add(c.id); else selected.delete(c.id);
    render();
  });
  tdSel.append(cb);

  const tdWord = document.createElement('td'); tdWord.className = 'col-word';
  tdWord.textContent = c.word;
  // Show a lang chip only on the "All" tab when multiple languages are active.
  // Inside a per-language tab every row is the same lang, so the chip would be noise.
  if (langFilter === 'all' && activeSourceLangs(settings).length > 1) {
    const chip = document.createElement('span');
    chip.className = 'lang-chip';
    chip.textContent = (c.lang || '').toUpperCase();
    tdWord.append(' ', chip);
  }
  const tdTrans = document.createElement('td'); tdTrans.className = 'col-trans'; tdTrans.textContent = c.translation || '';
  const tdCtx = document.createElement('td'); tdCtx.className = 'col-ctx';
  const ctxSpan = document.createElement('div'); ctxSpan.className = 'ctx'; ctxSpan.textContent = c.context || '';
  tdCtx.append(ctxSpan);

  const tdLvl = document.createElement('td'); tdLvl.className = 'col-lvl';
  const lvl = Math.max(1, Math.min(5, Number(c.level) || 1));
  const lvlBtn = document.createElement('button');
  lvlBtn.type = 'button';
  lvlBtn.className = `lvl-button lvl-${lvl}`;
  lvlBtn.title = 'Change level';
  lvlBtn.innerHTML = `<span>${LEVEL_MARKS[lvl]}</span><strong>${LEVEL_LABELS[lvl]}</strong>`;
  lvlBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    openLevelMenu(lvlBtn, c);
  });
  tdLvl.append(lvlBtn);

  const tdDel = document.createElement('td'); tdDel.className = 'col-del';
  const del = document.createElement('button'); del.className = 'row-del'; del.textContent = '🗑'; del.title = 'Delete';
  del.addEventListener('click', async () => {
    if (!confirm(`Delete "${c.word}"?`)) return;
    await deleteCard(c.id);
    selected.delete(c.id);
  });
  tdDel.append(del);

  tr.append(tdSel, tdWord, tdTrans, tdCtx, tdLvl, tdDel);
  return tr;
}

function closeLevelMenu() {
  if (!levelMenu) return;
  levelMenu.remove();
  levelMenu = null;
  document.removeEventListener('click', closeLevelMenu);
  document.removeEventListener('keydown', closeLevelMenuOnEscape);
  window.removeEventListener('resize', closeLevelMenu);
  window.removeEventListener('scroll', closeLevelMenu, true);
}

function closeLevelMenuOnEscape(e) {
  if (e.key === 'Escape') closeLevelMenu();
}

function openLevelMenu(anchor, card) {
  closeLevelMenu();
  const current = Math.max(1, Math.min(5, Number(card.level) || 1));
  const menu = document.createElement('div');
  menu.className = 'level-menu';
  menu.addEventListener('click', e => e.stopPropagation());

  for (const lvl of [1, 2, 3, 4, 5]) {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'level-menu-item' + (lvl === current ? ' active' : '');
    item.innerHTML = `<span>${LEVEL_MARKS[lvl]}</span><strong>${lvl} · ${LEVEL_LABELS[lvl]}</strong>`;
    item.addEventListener('click', async () => {
      const updated = await setCardLevel(card.id, lvl);
      if (updated) vocab[card.id] = updated;
      closeLevelMenu();
      toast(`Set to ${LEVEL_LABELS[lvl]}`);
      render();
    });
    menu.append(item);
  }

  document.body.append(menu);
  levelMenu = menu;
  positionLevelMenu(anchor, menu);
  setTimeout(() => {
    document.addEventListener('click', closeLevelMenu);
    document.addEventListener('keydown', closeLevelMenuOnEscape);
    window.addEventListener('resize', closeLevelMenu);
    window.addEventListener('scroll', closeLevelMenu, true);
  }, 0);
}

function positionLevelMenu(anchor, menu) {
  const rect = anchor.getBoundingClientRect();
  const gap = 6;
  const w = menu.offsetWidth;
  const h = menu.offsetHeight;
  const canOpenRight = rect.right + gap + w <= window.innerWidth - 8;
  const canOpenLeft = rect.left - gap - w >= 8;
  let left;
  if (canOpenRight) left = rect.right + gap;
  else if (canOpenLeft) left = rect.left - gap - w;
  else left = Math.min(Math.max(8, rect.left), window.innerWidth - w - 8);
  let top = rect.bottom + gap;
  if (top + h > window.innerHeight - 8) top = Math.max(8, rect.top - h - gap);
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;
}

let toastTimer;
function toast(msg) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1800);
}

boot();
