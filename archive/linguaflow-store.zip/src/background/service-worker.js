import { getSettings, saveCard, newCard, getVocabulary, setCardLevel, markKnown, unmarkKnown, migrateLevelSchema, detectLang, activeSourceLangs, applyCustomProfile } from '../lib/storage.js';
import { translate, translateWithContext, streamTranslateWithContext, llmCall, getPrompt, LLM_PROVIDERS } from '../lib/translators.js';
import { syncNow, getSyncFolderInfo } from '../lib/sync.js';
import { synthesize as ttsSynthesize } from '../lib/tts.js';
import { pickDueCards, FSRS } from '../lib/fsrs.js';

self.addEventListener('unhandledrejection', (e) => { e.preventDefault(); });

// ---- In-memory translation cache (speeds up repeat clicks on the same word) ----
const ctxCache = new Map();          // key -> { value, at }
const CACHE_TTL = 60 * 60 * 1000;    // 1 hour
const CACHE_MAX = 500;

function simpleHash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0).toString(36);
}
function cacheKey(word, sentence, from, to, provider) {
  return `${provider}|${from}|${to}|${word.toLowerCase()}|${simpleHash(sentence || '')}`;
}
function cacheGet(key) {
  const e = ctxCache.get(key);
  if (!e) return null;
  if (Date.now() - e.at > CACHE_TTL) { ctxCache.delete(key); return null; }
  return e.value;
}
function cacheSet(key, value) {
  ctxCache.set(key, { value, at: Date.now() });
  if (ctxCache.size > CACHE_MAX) {
    // Drop oldest ~20%.
    const entries = [...ctxCache.entries()].sort((a, b) => a[1].at - b[1].at);
    for (let i = 0; i < entries.length * 0.2; i++) ctxCache.delete(entries[i][0]);
  }
}

// ---- Context menu ----

chrome.runtime.onInstalled.addListener(async () => {
  migrateLevelSchema().catch(() => {});
  try {
    await chrome.contextMenus.removeAll();
    chrome.contextMenus.create({ id: 'linguaflow-translate', title: 'Translate with LinguaFlow', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'linguaflow-save', title: 'Save "%s" to vocabulary', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'linguaflow-review', title: 'Open LinguaFlow review', contexts: ['action'] });
  } catch {}
  chrome.alarms.create('lf-periodic-sync', { periodInMinutes: 30 });
  updateAnkiAlarm();
});
chrome.runtime.onStartup.addListener(async () => {
  chrome.alarms.get('lf-periodic-sync', (a) => {
    if (!a) chrome.alarms.create('lf-periodic-sync', { periodInMinutes: 30 });
  });
  // Cold-start sync check:
  //   - iCloud backend: File System Access permission may have lapsed → notify user.
  //   - WebDAV backend: try a sync silently; if auth fails the periodic loop will keep retrying.
  try {
    const settings = await getSettings();
    if (settings.syncBackend === 'icloud') {
      const info = await getSyncFolderInfo();
      if (info && info.permission !== 'granted') {
        chrome.notifications.create('lf-reconnect-sync', {
          type: 'basic',
          iconUrl: chrome.runtime.getURL('src/assets/icons/icon128.png'),
          title: 'LinguaFlow — reconnect iCloud sync',
          message: `Chrome cleared folder access for "${info.name}". Click to re-authorize.`,
          priority: 2
        });
      }
    } else if ((settings.syncBackend === 'webdav' || settings.syncBackend === 'gist') && settings.autoSync) {
      doAutoSync();
    }
  } catch (e) {
    console.warn('[LinguaFlow] startup sync check failed:', e);
  }
  updateAnkiAlarm();
});

chrome.notifications.onClicked.addListener((id) => {
  try {
    if (id === 'lf-reconnect-sync') {
      chrome.runtime.openOptionsPage();
      chrome.notifications.clear(id);
    }
  } catch {}
});

// Keyboard shortcut: translate whatever's in clipboard via active tab's tooltip.
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'translate-clipboard') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      try { await chrome.tabs.sendMessage(tab.id, { type: 'translateClipboard' }); }
      catch (e) { console.warn('[LinguaFlow] clipboard command failed:', e.message); }
    }
  }
});

// ---- Auto-sync ----
let syncing = false;
let queued  = false;
let _syncDebounce = null;

async function doAutoSync() {
  if (syncing) { queued = true; return; }
  syncing = true; queued = false;
  try {
    const settings = await getSettings();
    if (!settings.autoSync) return;
    if (settings.syncBackend === 'off') return;
    if (settings.syncBackend === 'icloud') {
      const info = await getSyncFolderInfo();
      if (!info || info.permission !== 'granted') return;
    }
    const res = await syncNow();
    if (!res.ok && res.error !== 'off') {
      console.warn('[LinguaFlow] auto-sync skipped:', res.error);
    }
  } catch (e) {
    console.warn('[LinguaFlow] auto-sync failed:', e);
  } finally {
    syncing = false;
    if (queued) setTimeout(doAutoSync, 500);
  }
}

function scheduleSyncDebounced() {
  if (_syncDebounce) clearTimeout(_syncDebounce);
  _syncDebounce = setTimeout(() => { _syncDebounce = null; doAutoSync(); }, 10000);
}

// Push whenever vocabulary or known words change (and it's not our own sync write).
// Debounced to 10s so rapid word clicks batch into one sync (saves 坚果云 quota).
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.lastSyncAt) return;
  if (!changes.vocabulary && !changes.knownWords && !changes.settings) return;
  scheduleSyncDebounced();
  if (changes.vocabulary) checkAnkiExport('count');
  if (changes.settings) updateAnkiAlarm();
});

// Periodic pull to receive changes pushed by other devices.
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'lf-periodic-sync') doAutoSync();
  if (alarm.name === 'lf-anki-export') checkAnkiExport('timer');
});

// ---- AnkiConnect auto-export ----

async function updateAnkiAlarm() {
  try {
    const { settings = {} } = await chrome.storage.local.get('settings');
    const anki = settings.anki || {};
    if (anki.enabled && anki.triggerMinutes > 0) {
      chrome.alarms.create('lf-anki-export', { periodInMinutes: Math.max(1, anki.triggerMinutes) });
    } else {
      chrome.alarms.clear('lf-anki-export');
    }
  } catch (_) {}
}

async function checkAnkiExport(reason) {
  try {
    const { vocabulary = {}, settings = {} } =
      await chrome.storage.local.get(['vocabulary', 'settings']);
    const anki = settings.anki || {};
    if (!anki.enabled) return;

    const { countPending, exportPending } = await import('../lib/anki.js');
    const pending = countPending(vocabulary, anki);
    if (!pending) return;
    if (reason === 'count' && anki.triggerCount > 0 && pending < anki.triggerCount) return;

    const res = await exportPending();
    if (res.ok && res.exported > 0) {
      console.log(`[LinguaFlow] Anki ${reason}-export: ${res.exported} cards`);
    }
  } catch (e) {
    console.warn('[LinguaFlow] Anki export failed:', e.message);
  }
}

// ---- Streaming translate port ----
// Content script opens a long-lived connection; SW pipes LLM SSE chunks back.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'lf-translate-stream') return;
  port.onMessage.addListener(async (msg) => {
    if (msg.type !== 'translate') return;
    try {
      const settings = await getSettings();
      applyCustomProfile(settings, { rotate: true });  // round-robin if rotation on
      const from = msg.from || settings.sourceLang;
      const to   = msg.to   || settings.nativeLang;
      const useContext = msg.sentence
        && settings.aiContext !== false
        && LLM_PROVIDERS.has(settings.translator);

      if (!useContext) {
        const result = await translate(msg.text, from, to, settings);
        try { port.postMessage({ type: 'complete', result }); } catch {}
        return;
      }

      // Cache hit → return immediately, no streaming needed.
      const key = cacheKey(msg.text, msg.sentence, from, to, settings.translator);
      const hit = cacheGet(key);
      if (hit) {
        try { port.postMessage({ type: 'complete', result: hit, cached: true }); } catch {}
        return;
      }

      await streamTranslateWithContext({
        word: msg.text, sentence: msg.sentence, from, to, settings,
        onChunk: (buffer) => { try { port.postMessage({ type: 'chunk', buffer }); } catch {} },
        onComplete: (result) => {
          cacheSet(key, result);
          try { port.postMessage({ type: 'complete', result }); } catch {}
        },
        onError: (err) => {
          try { port.postMessage({ type: 'error', message: String(err.message || err) }); } catch {}
        }
      });
    } catch (e) {
      try { port.postMessage({ type: 'error', message: String(e.message || e) }); } catch {}
    }
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    if (info.menuItemId === 'linguaflow-translate' && info.selectionText && tab?.id) {
      await chrome.tabs.sendMessage(tab.id, { type: 'showTranslation', text: info.selectionText.trim() }).catch(() => {});
    } else if (info.menuItemId === 'linguaflow-save' && info.selectionText) {
      await handleSaveCard({ word: info.selectionText.trim(), source: info.pageUrl });
    } else if (info.menuItemId === 'linguaflow-review') {
      await openReview();
    }
  } catch (e) {
    console.warn('[LinguaFlow] context menu action failed:', e.message);
  }
});

// ---- Message routing ----

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const reply = (data) => { try { sendResponse(data); } catch {} };
  (async () => {
    try {
      if (msg.type === 'translate') {
        const settings = await getSettings();
        applyCustomProfile(settings, { rotate: true });
        const from = msg.from || settings.sourceLang;
        const to   = msg.to   || settings.nativeLang;
        const useContext = msg.sentence
          && settings.aiContext !== false
          && LLM_PROVIDERS.has(settings.translator);
        if (useContext) {
          const key = cacheKey(msg.text, msg.sentence, from, to, settings.translator);
          const hit = cacheGet(key);
          if (hit) { reply({ ok: true, ...hit, cached: true }); return; }
          const result = await translateWithContext(msg.text, msg.sentence, from, to, settings);
          if (result && !result.aiContextError) cacheSet(key, result);
          reply({ ok: true, ...result });
        } else {
          const result = await translate(msg.text, from, to, settings);
          reply({ ok: true, ...result });
        }
      } else if (msg.type === 'saveCard') {
        const card = await handleSaveCard({
          word: msg.word,
          translation: msg.translation,
          context: msg.context,
          source: sender.tab?.url || msg.source
        });
        reply({ ok: true, card });
      } else if (msg.type === 'getSettings') {
        reply({ ok: true, settings: await getSettings() });
      } else if (msg.type === 'getVocabulary') {
        reply({ ok: true, vocabulary: await getVocabulary() });
      } else if (msg.type === 'openReview') {
        await openReview();
        reply({ ok: true });
      } else if (msg.type === 'setLevel') {
        const card = await setCardLevel(msg.id, msg.level);
        reply({ ok: true, card });
      } else if (msg.type === 'markKnown') {
        const settings = await getSettings();
        await markKnown(msg.word, msg.lang || detectLang(msg.word, settings));
        reply({ ok: true });
      } else if (msg.type === 'unmarkKnown') {
        const settings = await getSettings();
        await unmarkKnown(msg.word, msg.lang || detectLang(msg.word, settings));
        reply({ ok: true });
      } else if (msg.type === 'etymology') {
        const settings = await getSettings();
        applyCustomProfile(settings, { rotate: true, llmOnly: true });
        const etymology = await fetchEtymology(msg.word, settings, msg.from);
        reply(etymology);
      } else if (msg.type === 'explainAlt') {
        const settings = await getSettings();
        applyCustomProfile(settings, { rotate: true, llmOnly: true });
        const res = await fetchAltExplanation(msg.word, msg.sentence || '', settings, msg.from);
        reply(res);
      } else if (msg.type === 'sentenceTranslate') {
        const settings = await getSettings();
        applyCustomProfile(settings, { rotate: true, llmOnly: true });
        const res = await fetchSentenceTranslation(msg.sentence, settings, msg.from, msg.paragraph, msg.terms);
        reply(res);
      } else if (msg.type === 'punctuateText') {
        const settings = await getSettings();
        applyCustomProfile(settings, { rotate: true, llmOnly: true });
        const res = await fetchPunctuation(msg.text, settings);
        reply(res);
      } else if (msg.type === 'ttsSynthesize') {
        const s = await getSettings();
        try {
          const result = await ttsSynthesize({ text: msg.text, lang: msg.lang, settings: s });
          reply({ ok: true, ...result });
        } catch (e) {
          reply({ ok: false, error: e.message });
        }
      } else if (msg.type === 'reviewPickDue') {
        const { vocabulary = {} } = await chrome.storage.local.get('vocabulary');
        const s = await getSettings();
        const langs = new Set(activeSourceLangs(s));
        const mine = Object.values(vocabulary).filter(
          c => langs.has(c.lang) && (c.level || 1) < 5
        );
        const due = pickDueCards(Object.fromEntries(mine.map(c => [c.id, c])));
        reply({ ok: true, cards: due.slice(0, 25) });
      } else if (msg.type === 'reviewRate') {
        const s = await getSettings();
        const vocab = await getVocabulary();
        const card = vocab[msg.id];
        if (!card) { reply({ ok: false, error: 'card not found' }); return; }
        const fsrs = new FSRS({
          weights: s.fsrs.weights,
          requestRetention: s.fsrs.requestRetention,
          maximumInterval: s.fsrs.maximumInterval
        });
        const updated = fsrs.review(card, Number(msg.rating));
        await saveCard(updated);
        reply({ ok: true, card: updated });
      } else {
        reply({ ok: false, error: `Unknown message: ${msg.type}` });
      }
    } catch (err) {
      reply({ ok: false, error: err.message });
    }
  })();
  return true; // keep channel open for async response
});

async function handleSaveCard({ word, translation, context, source }) {
  const settings = await getSettings();
  const lang = detectLang(word, settings);
  let t = translation;
  if (!t) {
    const r = await translate(word, lang, settings.nativeLang, settings);
    t = r.translation;
  }
  const card = newCard({
    word, translation: t, lang,
    context: context || '', source: source || ''
  });
  await saveCard(card);
  return card;
}

async function openReview() {
  const url = chrome.runtime.getURL('src/review/review.html');
  await chrome.tabs.create({ url });
}

async function fetchEtymology(word, settings, overrideFrom) {
  const provider = settings.translator;
  if (!LLM_PROVIDERS.has(provider)) {
    return { ok: false, error: 'Etymology requires an LLM provider.' };
  }
  const from = overrideFrom || detectLang(word, settings);
  const to = settings.nativeLang;
  const system = getPrompt('etymology', settings, { from, to });
  try {
    const text = await llmCall(system, word, settings);
    return { ok: true, etymology: text || '(no notable etymology)' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function fetchPunctuation(text, settings) {
  if (!LLM_PROVIDERS.has(settings.translator)) {
    return { ok: false, error: 'LLM provider required.' };
  }
  // Captions can be in any active source language — detect by script so the
  // prompt reflects the actual caption language rather than always primary.
  const from = detectLang(text, settings);
  const to = settings.nativeLang;
  const system = getPrompt('youtubeCaption', settings, { from, to, text: '' });
  try {
    const punctuated = await llmCall(system, text, settings);
    return { ok: true, text: (punctuated || text).trim() };
  } catch (e) { return { ok: false, error: e.message }; }
}

async function fetchAltExplanation(word, sentence, settings, overrideFrom) {
  const provider = settings.translator;
  if (!LLM_PROVIDERS.has(provider)) {
    return { ok: false, error: 'Alternate analysis requires an LLM provider.' };
  }
  const from = overrideFrom || detectLang(word, settings);
  const to = settings.nativeLang;
  const system = getPrompt('wordExplain2', settings, { from, to });
  const user = `WORD: ${word}\nSENTENCE: ${sentence || word}`;
  try {
    const text = await llmCall(system, user, settings);
    return { ok: true, text: text || '(no additional insight)' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function fetchSentenceTranslation(sentence, settings, overrideFrom, paragraph, terms) {
  const provider = settings.translator;
  if (!LLM_PROVIDERS.has(provider)) {
    return { ok: false, error: 'Sentence translation requires an LLM provider.' };
  }
  const from = overrideFrom || detectLang(paragraph || sentence, settings);
  const to = settings.nativeLang;
  const termSuffix = terms ? '\n\nUse these known translations for vocabulary consistency: ' + terms : '';
  if (paragraph && settings.sentenceContext !== false) {
    const system = getPrompt('sentenceTranslationContext', settings, { from, to }) + termSuffix;
    const marked = paragraph.replace(sentence, '【' + sentence + '】');
    try {
      const text = await llmCall(system, marked, settings);
      return { ok: true, translation: (text || '').trim() };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }
  const system = getPrompt('sentenceTranslation', settings, { from, to }) + termSuffix;
  try {
    const text = await llmCall(system, sentence, settings);
    return { ok: true, translation: (text || '').trim() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}
