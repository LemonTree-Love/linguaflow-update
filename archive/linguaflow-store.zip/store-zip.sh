#!/bin/bash
# Build a clean ZIP for Chrome Web Store submission.
# Strips `key` and `update_url` from manifest.json (store assigns its own).

set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
VERSION=$(grep '"version"' "$DIR/manifest.json" | head -1 | sed 's/.*: *"\([^"]*\)".*/\1/')
OUT="$DIR/../linguaflow-store-v${VERSION}.zip"
TMP=$(mktemp -d)

echo "==> Building store ZIP for v$VERSION"

cp -R "$DIR/"* "$TMP/"

# Strip key and update_url from manifest
node -e "
const fs = require('fs');
const m = JSON.parse(fs.readFileSync('$TMP/manifest.json','utf8'));
delete m.key;
delete m.update_url;
fs.writeFileSync('$TMP/manifest.json', JSON.stringify(m, null, 2) + '\n');
"

# Remove dev-only files from zip
rm -f "$TMP/release.sh" "$TMP/store-zip.sh" "$TMP/updates.xml"

cd "$TMP"
find . -name '.DS_Store' -delete
zip -r "$OUT" . -x '.*' '__MACOSX/*' '*/.DS_Store'
rm -rf "$TMP"

echo "==> Done: $OUT"
echo "    Upload at: https://chrome.google.com/webstore/devconsole"
